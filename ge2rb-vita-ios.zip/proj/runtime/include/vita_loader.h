#ifndef VITA_LOADER_H
#define VITA_LOADER_H
#include "vita_rt.h"
#ifdef __cplusplus
extern "C" {
#endif
#define VRT_MAX_SEG 4
typedef struct {
    uint32_t base[VRT_MAX_SEG];     /* runtime guest base of each LOAD segment (index = program header index) */
    uint32_t memsz[VRT_MAX_SEG];
    uint32_t link[VRT_MAX_SEG];     /* link-time vaddr of each segment */
    int      nseg;
    uint32_t entry_seg, entry_off;  /* SceModuleInfo location (e_entry encodes segment + offset) */
    uint32_t relocs_applied;
} vrt_module;

/* Load an already-decrypted, uncompressed Vita SELF into guest memory and apply its relocations.
   Returns 0 on success, negative on error (message on stderr). */
int vrt_load_self(const char *path, vrt_module *out);
#ifdef __cplusplus
}
#endif
#endif
