#ifndef VITA_RT_H
#define VITA_RT_H
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

/* Guest = 32-bit ARM address space. Host keeps one 4 GiB reservation; guest addr is an offset into it. */
extern uint8_t *vrt_mem;
#define VRT_G2H(a) ((void *)(vrt_mem + (uint32_t)(a)))
#define VRT_H2G(p) ((uint32_t)((uint8_t *)(p) - vrt_mem))

typedef struct vrt_ctx {
    uint32_t r[16];                 /* r13=sp r14=lr r15=pc */
    uint8_t  n, z, c, v, q;         /* APSR flags */
    uint32_t ge;
    union { float f[64]; double d[32]; uint64_t u64[32]; } s;   /* s0-s31 alias d0-d15 (little-endian), d0-d31 */
    uint32_t fpscr;
    uint32_t tls;                   /* guest TLS base */
    uint32_t ex_addr;               /* exclusive monitor (0 = open) */
    uint64_t ex_val;
    uint32_t last_call;             /* guest address passed to the most recent vrt_call (import stub / function) */
} vrt_ctx;

typedef void (*vrt_fn)(vrt_ctx *);

int      vrt_init(size_t commit_bytes);            /* reserve 4 GiB, commit first commit_bytes. 0 = ok */
void     vrt_shutdown(void);
int      vrt_commit(uint32_t guest_addr, size_t len);   /* make a guest range RW */
uint32_t vrt_alloc(size_t len, size_t align);      /* simple bump allocator in guest space */

/* Lifted code registers each function by its guest (thumb bit included) address. */
void     vrt_register(uint32_t guest_addr, vrt_fn fn);
vrt_fn   vrt_lookup(uint32_t guest_addr);
/* Indirect call / bx: resolves via table; unresolved -> vrt_fatal. */
void     vrt_call(vrt_ctx *c, uint32_t guest_addr);
int      vrt_recent_calls(uint32_t *out, int max);              /* last calls made by this thread (resolved targets), oldest first */
int      vrt_cs_get(void);                                       /* shadow call-stack depth (restore it after a longjmp out of guest code) */
void     vrt_cs_set(int n);
int      vrt_backtrace(uint32_t *out, int max);                /* guest call chain of the calling thread, outermost first */
void     vrt_redirect(uint32_t from_addr, uint32_t to_addr);   /* import stub -> exported function of another module */
int      vrt_bind_redirects(void);                              /* after all lifted code is registered: make redirects direct; returns #unbound */

/* HLE: system library function keyed by NID. */
void     vrt_register_hle(uint32_t nid, vrt_fn fn, const char *name);
vrt_fn   vrt_lookup_hle(uint32_t nid);

/* ---- Input (written by the iOS UI / game controllers, read by the SceCtrl/SceTouch HLE) ---- */
enum {  /* SceCtrlButtons */
    VRT_SELECT = 0x1, VRT_L3 = 0x2, VRT_R3 = 0x4, VRT_START = 0x8,
    VRT_UP = 0x10, VRT_RIGHT = 0x20, VRT_DOWN = 0x40, VRT_LEFT = 0x80,
    VRT_L2 = 0x100, VRT_R2 = 0x200, VRT_L1 = 0x400, VRT_R1 = 0x800,
    VRT_TRIANGLE = 0x1000, VRT_CIRCLE = 0x2000, VRT_CROSS = 0x4000, VRT_SQUARE = 0x8000,
    VRT_PS = 0x10000
};
#define VRT_MAX_TOUCH 6
void     vrt_input_set_buttons(uint32_t mask);
uint32_t vrt_input_get_buttons(void);
void     vrt_input_set_sticks(uint8_t lx, uint8_t ly, uint8_t rx, uint8_t ry);  /* 0..255, 128 = center */
void     vrt_input_get_sticks(uint8_t out[4]);
/* port 0 = front (960x544 space), 1 = rear. down=0 removes the point. */
void     vrt_input_touch(int port, int id, int down, uint16_t x, uint16_t y);
int      vrt_input_get_touches(int port, uint8_t *ids, uint16_t *xs, uint16_t *ys, int max);

void     vrt_fatal(const char *fmt, ...);
#ifdef __cplusplus
}
#endif
#endif
