/* HLE of the PS Vita kernel API used by the game: threads, semaphores, event flags, lightweight mutex/cond, TLS, time,
   memory blocks, process info and file I/O. Everything is built on pthreads; one global lock + per-object condvars. */
#include "vita_link.h"
#include "nid_defs.h"
#include "hle_common.h"
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>

#define HLE(name) static void hle_##name(vrt_ctx *x); \
    __attribute__((constructor)) static void reg_##name(void) { vrt_register_hle(NID_##name, hle_##name, #name); } \
    static void hle_##name(vrt_ctx *x)

#define ERR_WAIT_TIMEOUT   0x80028005u
#define ERR_INVALID_UID    0x80028001u    /* generic "bad uid" */
#define ERR_NOENT          0x80010002u
#define ERR_BADF           0x80010009u
#define ERR_FAIL           0x80010016u    /* EINVAL */
#define RET(v) do { x->r[0] = (uint32_t)(v); } while (0)

static pthread_mutex_t K = PTHREAD_MUTEX_INITIALIZER;     /* the one kernel lock */

/* ------------------------------------------------------------------------------------------------ handles */
enum { H_FREE = 0, H_THREAD, H_SEMA, H_EVFLAG, H_MEMBLK, H_FILE, H_DIR };
typedef struct { int type; void *obj; } Handle;
static Handle handles[8192];
#define UID_BASE 0x40000100u
static uint32_t h_new(int type, void *obj) {
    pthread_mutex_lock(&K);
    for (int i = 0; i < 8192; i++) if (!handles[i].type) { handles[i].type = type; handles[i].obj = obj; pthread_mutex_unlock(&K); return UID_BASE + (uint32_t)i; }
    pthread_mutex_unlock(&K); return 0;
}
static void *h_get(uint32_t uid, int type) {
    if (uid < UID_BASE || uid >= UID_BASE + 8192) return NULL;
    Handle *h = &handles[uid - UID_BASE];
    return h->type == type ? h->obj : NULL;
}
static void h_free(uint32_t uid) { if (uid >= UID_BASE && uid < UID_BASE + 8192) handles[uid - UID_BASE].type = H_FREE; }

/* timeouts: guest passes `SceUInt *timeout` (microseconds) or NULL */
static int wait_cv(pthread_cond_t *cv, uint32_t timeout_ptr) {     /* caller holds K; returns 0 woken, 1 timed out */
    if (!timeout_ptr) { pthread_cond_wait(cv, &K); return 0; }
    uint32_t us; memcpy(&us, VRT_G2H(timeout_ptr), 4);
    struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
    ts.tv_sec += us / 1000000; ts.tv_nsec += (long)(us % 1000000) * 1000;
    if (ts.tv_nsec >= 1000000000L) { ts.tv_sec++; ts.tv_nsec -= 1000000000L; }
    return pthread_cond_timedwait(cv, &K, &ts) == ETIMEDOUT;
}

/* ------------------------------------------------------------------------------------------------ threads */
typedef struct Thread {
    pthread_t th; vrt_ctx *ctx; uint32_t entry, stack, stack_size, argsz, argp; int started, done, status, id, prio;
    pthread_cond_t cv_done; char name[32]; uint32_t uid; uint32_t tls;
} Thread;
__thread jmp_buf *hle_exit_jb;
static __thread Thread *cur_thread;
static int next_thread_id = 2;

static uint32_t new_tls(void) { uint32_t t = vrt_alloc(0x1000, 0x1000); return t; }
static Thread *self(vrt_ctx *x) {
    if (!cur_thread) {                                      /* main thread: adopt */
        Thread *t = calloc(1, sizeof *t);
        t->ctx = x; t->id = 1; t->started = 1; strcpy(t->name, "main"); pthread_cond_init(&t->cv_done, NULL);
        t->uid = h_new(H_THREAD, t); t->tls = x->tls ? x->tls : new_tls(); x->tls = t->tls;
        cur_thread = t;
    }
    return cur_thread;
}
static void *thread_main(void *a) {
    Thread *t = a; cur_thread = t;
    vrt_ctx *x = t->ctx;
    x->r[0] = t->argsz; x->r[1] = t->argp; x->r[14] = 0;
    jmp_buf jb; hle_exit_jb = &jb;
    if (setjmp(jb) == 0) vrt_call(x, t->entry);                 /* ExitThread longjmps here with the status in r0 */
    pthread_mutex_lock(&K); t->status = (int)x->r[0]; t->done = 1; pthread_cond_broadcast(&t->cv_done); pthread_mutex_unlock(&K);
    return NULL;
}
/* SceUID sceKernelCreateThread(const char *name, SceKernelThreadEntry entry, int prio, SceSize stackSize, SceUInt attr, int cpu, opt) */
HLE(sceKernelCreateThread) {
    (void)self(x);
    Thread *t = calloc(1, sizeof *t);
    t->ctx = calloc(1, sizeof(vrt_ctx)); t->entry = x->r[1]; t->prio = (int)x->r[2];
    t->stack_size = x->r[3] ? ((x->r[3] + 0xfffu) & ~0xfffu) : 0x40000; t->stack = vrt_alloc(t->stack_size, 0x1000);
    strncpy(t->name, (const char *)VRT_G2H(x->r[0]), 31); pthread_cond_init(&t->cv_done, NULL);
    t->id = __sync_fetch_and_add(&next_thread_id, 1);
    t->tls = new_tls(); t->ctx->tls = t->tls;
    t->uid = h_new(H_THREAD, t);
    RET(t->uid);
}
/* int sceKernelStartThread(SceUID thid, SceSize arglen, void *argp) */
HLE(sceKernelStartThread) {
    Thread *t = h_get(x->r[0], H_THREAD);
    if (!t) { RET(ERR_INVALID_UID); return; }
    uint32_t top = t->stack + t->stack_size - 64, arglen = x->r[1], argp = x->r[2], dst = 0;
    if (arglen && argp) { top -= (arglen + 15) & ~15u; dst = top; memcpy(VRT_G2H(dst), VRT_G2H(argp), arglen); }
    t->ctx->r[13] = top; t->argsz = arglen; t->argp = dst; t->started = 1;
    pthread_attr_t at; pthread_attr_init(&at); pthread_attr_setstacksize(&at, 256u << 20);
    int rc = pthread_create(&t->th, &at, thread_main, t);
    RET(rc ? ERR_FAIL : 0);
}
HLE(sceKernelWaitThreadEnd) {
    Thread *t = h_get(x->r[0], H_THREAD);
    if (!t) { RET(ERR_INVALID_UID); return; }
    pthread_mutex_lock(&K);
    int to = 0;
    while (!t->done && !to) to = wait_cv(&t->cv_done, x->r[2]);
    pthread_mutex_unlock(&K);
    if (to) { RET(ERR_WAIT_TIMEOUT); return; }
    if (x->r[1]) memcpy(VRT_G2H(x->r[1]), &t->status, 4);
    RET(t->status);
}
HLE(sceKernelDeleteThread) { h_free(x->r[0]); RET(0); }
static void exit_thread(vrt_ctx *x) {
    if (hle_exit_jb) longjmp(*hle_exit_jb, 1);
    Thread *t = self(x);
    pthread_mutex_lock(&K); t->status = (int)x->r[0]; t->done = 1; pthread_cond_broadcast(&t->cv_done); pthread_mutex_unlock(&K);
    pthread_exit(NULL);
}
HLE(sceKernelExitDeleteThread) { exit_thread(x); }
HLE(sceKernelExitThread) { exit_thread(x); }
HLE(sceKernelGetThreadId) { RET(self(x)->uid); }
HLE(sceKernelGetThreadCurrentPriority) { RET(self(x)->prio ? self(x)->prio : 0x40); }
HLE(sceKernelGetThreadExitStatus) { Thread *t = h_get(x->r[0], H_THREAD); if (!t) { RET(ERR_INVALID_UID); return; } if (x->r[1]) memcpy(VRT_G2H(x->r[1]), &t->status, 4); RET(0); }
HLE(sceKernelGetThreadInfo) { if (x->r[1]) { uint32_t sz; memcpy(&sz, VRT_G2H(x->r[1]), 4); if (sz > 0 && sz < 512) memset((char *)VRT_G2H(x->r[1]) + 4, 0, sz - 4); } RET(0); }
HLE(sceKernelChangeThreadPriority) { RET(0); }
HLE(sceKernelChangeThreadPriority2) { RET(0); }
HLE(sceKernelChangeThreadCpuAffinityMask) { RET(0); }
HLE(sceKernelChangeThreadVfpException) { RET(0); }
HLE(sceKernelGetThreadCpuAffinityMask2) { RET(0x7); }
HLE(sceKernelRegisterThreadEventHandler) { RET(h_new(H_FREE + 99, NULL) ? 0x40000001u : 0); }
HLE(sceKernelUnregisterThreadEventHandler) { RET(0); }
HLE(sceKernelDelayThread) { usleep(x->r[0]); RET(0); }
HLE(sceKernelDelayThreadCB) { usleep(x->r[0]); RET(0); }
HLE(sceKernelGetProcessId) { RET(0x10001); }
HLE(sceKernelSendSignal) { RET(0); }
HLE(sceKernelWaitSignal) { usleep(1000); RET(0); }

/* TLS: per-thread block, 4 bytes per key; also reachable through CP15 c13 (x->tls) */
HLE(sceKernelGetTLSAddr) {
    Thread *t = self(x);
    uint32_t key = x->r[0];
    RET(key < 1024 ? t->tls + 4 * key : 0);
}

/* ------------------------------------------------------------------------------------------------ time */
static uint64_t now_us(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return (uint64_t)ts.tv_sec * 1000000ull + ts.tv_nsec / 1000; }
static uint64_t t0_us;
static void ret64(vrt_ctx *x, uint64_t v) { x->r[0] = (uint32_t)v; x->r[1] = (uint32_t)(v >> 32); }
HLE(sceKernelGetSystemTimeWide) { ret64(x, now_us()); }
HLE(sceKernelGetProcessTimeWide) { if (!t0_us) t0_us = now_us(); ret64(x, now_us() - t0_us); }
HLE(sceKernelGetProcessTimeLow) { if (!t0_us) t0_us = now_us(); RET((uint32_t)(now_us() - t0_us)); }
HLE(sceKernelPowerTick) { RET(0); }

/* ------------------------------------------------------------------------------------------------ semaphores */
typedef struct { pthread_cond_t cv; int count, max; } Sema;
/* SceUID sceKernelCreateSema(const char *name, SceUInt attr, int initCount, int maxCount, opt) */
HLE(sceKernelCreateSema) { Sema *s = calloc(1, sizeof *s); pthread_cond_init(&s->cv, NULL); s->count = (int)x->r[2]; s->max = (int)x->r[3]; RET(h_new(H_SEMA, s)); }
HLE(sceKernelDeleteSema) { h_free(x->r[0]); RET(0); }
static void sema_wait(vrt_ctx *x) {
    Sema *s = h_get(x->r[0], H_SEMA); int need = (int)x->r[1];
    if (!s) { RET(ERR_INVALID_UID); return; }
    pthread_mutex_lock(&K);
    int to = 0;
    while (s->count < need && !to) to = wait_cv(&s->cv, x->r[2]);
    if (!to) s->count -= need;
    pthread_mutex_unlock(&K);
    RET(to ? ERR_WAIT_TIMEOUT : 0);
}
HLE(sceKernelWaitSema) { sema_wait(x); }
HLE(sceKernelWaitSemaCB) { sema_wait(x); }
HLE(sceKernelPollSema) {
    Sema *s = h_get(x->r[0], H_SEMA); int need = (int)x->r[1];
    if (!s) { RET(ERR_INVALID_UID); return; }
    pthread_mutex_lock(&K); int ok = s->count >= need; if (ok) s->count -= need; pthread_mutex_unlock(&K);
    RET(ok ? 0 : 0x80028003u);
}
HLE(sceKernelSignalSema) {
    Sema *s = h_get(x->r[0], H_SEMA);
    if (!s) { RET(ERR_INVALID_UID); return; }
    pthread_mutex_lock(&K); s->count += (int)x->r[1]; if (s->max && s->count > s->max) s->count = s->max; pthread_cond_broadcast(&s->cv); pthread_mutex_unlock(&K);
    RET(0);
}
HLE(sceKernelCancelSema) {
    Sema *s = h_get(x->r[0], H_SEMA);
    if (!s) { RET(ERR_INVALID_UID); return; }
    pthread_mutex_lock(&K); s->count = (int)x->r[1]; pthread_cond_broadcast(&s->cv); pthread_mutex_unlock(&K); RET(0);
}

/* ------------------------------------------------------------------------------------------------ event flags */
typedef struct { pthread_cond_t cv; uint32_t pat; } EvFlag;
HLE(sceKernelCreateEventFlag) { EvFlag *e = calloc(1, sizeof *e); pthread_cond_init(&e->cv, NULL); e->pat = x->r[2]; RET(h_new(H_EVFLAG, e)); }
HLE(sceKernelDeleteEventFlag) { h_free(x->r[0]); RET(0); }
HLE(sceKernelSetEventFlag) { EvFlag *e = h_get(x->r[0], H_EVFLAG); if (!e) { RET(ERR_INVALID_UID); return; } pthread_mutex_lock(&K); e->pat |= x->r[1]; pthread_cond_broadcast(&e->cv); pthread_mutex_unlock(&K); RET(0); }
HLE(sceKernelClearEventFlag) { EvFlag *e = h_get(x->r[0], H_EVFLAG); if (!e) { RET(ERR_INVALID_UID); return; } pthread_mutex_lock(&K); e->pat &= x->r[1]; pthread_mutex_unlock(&K); RET(0); }
#define EV_AND 0x00u
#define EV_OR 0x01u
#define EV_CLEAR_ALL 0x10u
#define EV_CLEAR_PAT 0x20u
static int ev_match(EvFlag *e, uint32_t bits, uint32_t mode) { return (mode & EV_OR) ? (e->pat & bits) != 0 : (e->pat & bits) == bits; }
/* int sceKernelWaitEventFlag(SceUID evid, unsigned bits, unsigned waitMode, unsigned *pResultPat, SceUInt *timeout) */
static void ev_wait(vrt_ctx *x, int poll) {
    EvFlag *e = h_get(x->r[0], H_EVFLAG); uint32_t bits = x->r[1], mode = x->r[2], resp = x->r[3], tmo;
    memcpy(&tmo, (uint8_t *)VRT_G2H(x->r[13]), 4);                      /* 5th argument is on the stack */
    if (!e) { RET(ERR_INVALID_UID); return; }
    pthread_mutex_lock(&K);
    int to = 0;
    while (!ev_match(e, bits, mode) && !to) { if (poll) { to = 2; break; } to = wait_cv(&e->cv, tmo); }
    if (!to) { if (resp) memcpy(VRT_G2H(resp), &e->pat, 4); if (mode & EV_CLEAR_ALL) e->pat = 0; else if (mode & EV_CLEAR_PAT) e->pat &= ~bits; }
    pthread_mutex_unlock(&K);
    RET(to == 2 ? 0x80028003u : to ? ERR_WAIT_TIMEOUT : 0);
}
HLE(sceKernelWaitEventFlag) { ev_wait(x, 0); }
HLE(sceKernelWaitEventFlagCB) { ev_wait(x, 0); }
HLE(sceKernelPollEventFlag) { ev_wait(x, 1); }

/* ------------------------------------------------------------------------------------------------ lightweight mutex / cond (keyed by the guest work area address) */
typedef struct { uint32_t key; int kind; pthread_cond_t cv; Thread *owner; int count, recursive; uint32_t mutex_key; } Lw;
static Lw *lws; static int nlw, caplw;
static Lw *lw_find(uint32_t key, int kind, int create) {
    pthread_mutex_lock(&K);
    for (int i = 0; i < nlw; i++) if (lws[i].key == key && lws[i].kind == kind) { pthread_mutex_unlock(&K); return &lws[i]; }
    Lw *r = NULL;
    if (create) {
        if (nlw == caplw) { caplw = caplw ? caplw * 2 : 256; Lw *n = realloc(lws, caplw * sizeof *lws); if (n != lws) { /* pointers move: handed out only under K */ } lws = n; }
        r = &lws[nlw++]; memset(r, 0, sizeof *r); r->key = key; r->kind = kind; pthread_cond_init(&r->cv, NULL);
    }
    pthread_mutex_unlock(&K); return r;
}
/* sceKernelCreateLwMutex(work, name, attr, initCount, opt): attr bit 0x2 = recursive */
HLE(sceKernelCreateLwMutex) { Lw *m = lw_find(x->r[0], 1, 1); pthread_mutex_lock(&K); m->recursive = (x->r[2] & 2) != 0; m->count = 0; m->owner = NULL; if ((int)x->r[3] > 0) { m->owner = self(x); m->count = (int)x->r[3]; } pthread_mutex_unlock(&K); RET(0); }
HLE(sceKernelDeleteLwMutex) { RET(0); }
static int lw_lock(vrt_ctx *x, int try_, int use_to) {
    Lw *m = lw_find(x->r[0], 1, 1); Thread *me = self(x); int n = (int)x->r[1];
    if (n <= 0) n = 1;
    pthread_mutex_lock(&K);
    int rc = 0;
    if (m->owner == me) { if (m->recursive) m->count += n; else rc = 0x800200fau; }
    else {
        while (m->owner && !rc) { if (try_) { rc = 0x800200fbu; break; } if (wait_cv(&m->cv, use_to ? x->r[2] : 0)) rc = ERR_WAIT_TIMEOUT; }
        if (!rc) { m->owner = me; m->count = n; }
    }
    pthread_mutex_unlock(&K);
    return rc;
}
HLE(sceKernelLockLwMutex) { RET(lw_lock(x, 0, 1)); }
HLE(sceKernelLockLwMutexCB) { RET(lw_lock(x, 0, 1)); }
HLE(sceKernelTryLockLwMutex) { RET(lw_lock(x, 1, 0)); }
HLE(sceKernelUnlockLwMutex) {
    Lw *m = lw_find(x->r[0], 1, 1); Thread *me = self(x); int n = (int)x->r[1]; if (n <= 0) n = 1;
    pthread_mutex_lock(&K);
    int rc = 0;
    if (m->owner != me) rc = 0x800200fcu;
    else { m->count -= n; if (m->count <= 0) { m->owner = NULL; m->count = 0; pthread_cond_signal(&m->cv); } }
    pthread_mutex_unlock(&K);
    RET(rc);
}
/* sceKernelCreateLwCond(cond_work, name, attr, mutex_work, opt) */
HLE(sceKernelCreateLwCond) { Lw *c = lw_find(x->r[0], 2, 1); pthread_mutex_lock(&K); c->mutex_key = x->r[3]; pthread_mutex_unlock(&K); RET(0); }
HLE(sceKernelDeleteLwCond) { RET(0); }
/* sceKernelWaitLwCond(cond_work, SceUInt *timeout): atomically release the mutex, wait, re-acquire it */
HLE(sceKernelWaitLwCond) {
    Lw *c = lw_find(x->r[0], 2, 1); Thread *me = self(x); uint32_t tmo = x->r[1];
    Lw *m = lw_find(c->mutex_key, 1, 1);
    pthread_mutex_lock(&K);
    int saved = m->count; m->owner = NULL; m->count = 0; pthread_cond_signal(&m->cv);
    int to = wait_cv(&c->cv, tmo);
    while (m->owner) pthread_cond_wait(&m->cv, &K);
    m->owner = me; m->count = saved ? saved : 1;
    pthread_mutex_unlock(&K);
    RET(to ? ERR_WAIT_TIMEOUT : 0);
}
HLE(sceKernelSignalLwCond) { Lw *c = lw_find(x->r[0], 2, 1); pthread_mutex_lock(&K); pthread_cond_signal(&c->cv); pthread_mutex_unlock(&K); RET(0); }
HLE(sceKernelSignalLwCondAll) { Lw *c = lw_find(x->r[0], 2, 1); pthread_mutex_lock(&K); pthread_cond_broadcast(&c->cv); pthread_mutex_unlock(&K); RET(0); }

/* ------------------------------------------------------------------------------------------------ memory blocks */
typedef struct { uint32_t base, size; } MemBlk;
HLE(sceKernelAllocMemBlock) {
    uint32_t size = (x->r[2] + 0xfffu) & ~0xfffu;
    MemBlk *b = calloc(1, sizeof *b); b->size = size ? size : 0x1000; b->base = vrt_alloc(b->size, 0x1000);
    RET(h_new(H_MEMBLK, b));
}
HLE(sceKernelGetMemBlockBase) { MemBlk *b = h_get(x->r[0], H_MEMBLK); if (!b) { RET(ERR_INVALID_UID); return; } memcpy(VRT_G2H(x->r[1]), &b->base, 4); RET(0); }
HLE(sceKernelFreeMemBlock) { h_free(x->r[0]); RET(0); }
HLE(sceKernelFindMemBlockByAddr) {
    for (int i = 0; i < 8192; i++) if (handles[i].type == H_MEMBLK) { MemBlk *b = handles[i].obj; if (x->r[0] >= b->base && x->r[0] < b->base + b->size) { RET(UID_BASE + i); return; } }
    RET(ERR_INVALID_UID);
}
HLE(sceKernelGetFreeMemorySize) { RET(0); }

/* ------------------------------------------------------------------------------------------------ process / stdio / misc */
/* the main module's `module_proc_param` export (NID 0x70FBA1E7): struct starting {size=0x34, 'PSP2', ...}.  (0x936C8A78 is module_sdk_version.) */
HLE(sceKernelGetProcessParam) { RET(vrt_link_module_export_var(0, 0x70FBA1E7u)); }
HLE(sceKernelGetStdin) { RET(0x1000); }
HLE(sceKernelGetStdout) { RET(0x1001); }
HLE(sceKernelGetStderr) { RET(0x1002); }
HLE(sceKernelExitProcess) { fprintf(stderr, "[hle] sceKernelExitProcess(%d)\n", (int)x->r[0]); fflush(stderr); _exit((int)x->r[0]); }
HLE(sceKernelCallAbortHandler) { vrt_fatal("sceKernelCallAbortHandler"); }
HLE(__stack_chk_fail) { vrt_fatal("stack smashing detected (__stack_chk_fail) lr=0x%08x", x->r[14]); }
HLE(__sce_aeabi_idiv0) { RET(0); }
HLE(__sce_aeabi_ldiv0) { x->r[0] = 0; x->r[1] = 0; }
HLE(sceKernelCallModuleExit) { RET(0); }
HLE(sceKernelStopUnloadModule) { RET(0); }
/* SceKernelModuleInfo (0x1B8): size, modid, modattr, modver[2], pad[2], name[28], start, stop, exidxTop/Btm, extabTop/Btm,
   tlsInit, tlsInitSize, tlsAreaSize, path[256], SceKernelSegmentInfo segments[4] {size=0x18, perms, vaddr, memsz, flags, res}, type */
static void fill_module_info(vrt_ctx *x, int idx, uint32_t gp) {
    uint8_t *d = VRT_G2H(gp); uint32_t sz; memcpy(&sz, d, 4);
    memset(d, 0, 0x1B8); sz = 0x1B8; memcpy(d, &sz, 4);
    const vrt_module *m = vrt_link_module(idx);
    uint32_t v;
    v = 0x1000u + (uint32_t)idx; memcpy(d + 4, &v, 4);                                   /* modid */
    uint32_t mi = m->base[m->entry_seg] + m->entry_off;
    memcpy(d + 0x0c, VRT_G2H(mi + 2), 2);                                                /* modver */
    memcpy(d + 0x10, VRT_G2H(mi + 4), 27);                                               /* module name */
    v = vrt_link_module_export(idx, 0x935CD196u); memcpy(d + 0x30, &v, 4);               /* start entry */
    v = vrt_link_module_export(idx, 0x79F8E492u); memcpy(d + 0x34, &v, 4);               /* stop entry */
    uint32_t b0 = m->base[m->entry_seg];
    uint32_t w;
    for (int i = 0; i < 4; i++) { w = vrt_link_module_info_word(idx, 0x4c + 4 * i); w += b0; memcpy(d + 0x38 + 4 * i, &w, 4); }   /* exidx/extab are segment offsets */
    w = vrt_link_module_info_word(idx, 0x38); if (w) w += b0; memcpy(d + 0x48, &w, 4);   /* tlsInit: segment offset -> runtime address */
    w = vrt_link_module_info_word(idx, 0x3c); memcpy(d + 0x4c, &w, 4);                   /* tlsInitSize */
    w = vrt_link_module_info_word(idx, 0x40); memcpy(d + 0x50, &w, 4);                   /* tlsAreaSize */
    snprintf((char *)d + 0x54, 255, "app0:%s", vrt_link_module_name(idx));
    for (int k = 0; k < m->nseg && k < 4; k++) {
        uint8_t *sg = d + 0x154 + 0x18 * k; uint32_t s24 = 0x18, perms = k == 0 ? 5u : 6u;
        memcpy(sg, &s24, 4); memcpy(sg + 4, &perms, 4); memcpy(sg + 8, &m->base[k], 4); memcpy(sg + 12, &m->memsz[k], 4);
    }
    (void)x;
}
HLE(sceKernelGetModuleInfoByAddr) {
    int idx = vrt_link_module_find_addr(x->r[0]);
    if (idx < 0 || !x->r[1]) { RET(0x8002d002u); return; }                                /* SCE_KERNEL_ERROR_MODULEMGR_NO_MOD */
    fill_module_info(x, idx, x->r[1]);
    RET(0);
}

HLE(sceKernelGetOpenPsId) { memset(VRT_G2H(x->r[0]), 0x11, 16); RET(0); }
HLE(sceKernelLibcClock) { RET((uint32_t)(clock() * 1000000ull / CLOCKS_PER_SEC)); }
HLE(sceKernelLibcTime) { time_t t = time(NULL); if (x->r[0]) memcpy(VRT_G2H(x->r[0]), &t, 4); RET((uint32_t)t); }
HLE(sceKernelLibcGettimeofday) { struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts); uint32_t tv[2] = {(uint32_t)ts.tv_sec, (uint32_t)(ts.tv_nsec / 1000)}; if (x->r[0]) memcpy(VRT_G2H(x->r[0]), tv, 8); RET(0); }

/* ------------------------------------------------------------------------------------------------ libc helpers (sceClib*) with a small guest-varargs printf */
HLE(sceClibMemcpy_safe) { memmove(VRT_G2H(x->r[0]), VRT_G2H(x->r[1]), x->r[2]); RET(x->r[0]); }
HLE(sceClibMemset) { memset(VRT_G2H(x->r[0]), (int)x->r[1], x->r[2]); RET(x->r[0]); }
HLE(sceClibStrncpy) { strncpy(VRT_G2H(x->r[0]), VRT_G2H(x->r[1]), x->r[2]); RET(x->r[0]); }

typedef struct { vrt_ctx *x; int ncrn; uint32_t sp_off; } VA;           /* AAPCS variadic argument reader */
static uint32_t va32(VA *v) {
    if (v->ncrn < 4) return v->x->r[v->ncrn++];
    uint32_t w; memcpy(&w, (uint8_t *)VRT_G2H(v->x->r[13]) + v->sp_off, 4); v->sp_off += 4; return w;
}
static uint64_t va64(VA *v) {
    if (v->ncrn < 4) { if (v->ncrn & 1) v->ncrn++; }
    if (v->ncrn < 4) { uint64_t lo = v->x->r[v->ncrn], hi = v->x->r[v->ncrn + 1]; v->ncrn += 2; return lo | (hi << 32); }
    v->sp_off = (v->sp_off + 7) & ~7u;
    uint64_t w; memcpy(&w, (uint8_t *)VRT_G2H(v->x->r[13]) + v->sp_off, 8); v->sp_off += 8; return w;
}
static int guest_format(char *out, size_t cap, const char *fmt, VA *v) {
    size_t n = 0; char tmp[512];
#define EMIT(s) do { const char *s_ = (s); size_t l_ = strlen(s_); for (size_t i_ = 0; i_ < l_; i_++) { if (n + 1 < cap) out[n] = s_[i_]; n++; } } while (0)
    for (const char *p = fmt; *p; p++) {
        if (*p != '%') { if (n + 1 < cap) out[n] = *p; n++; continue; }
        char spec[32]; int k = 0; spec[k++] = *p++;
        while (*p && strchr("-+ #0123456789.", *p) && k < 24) spec[k++] = *p++;
        int ll = 0, hh = 0;
        while (*p == 'l' || *p == 'h' || *p == 'z' || *p == 't' || *p == 'j') { if (*p == 'l') ll++; if (*p == 'h') hh++; p++; }
        char c = *p; if (!c) break;
        if (c == '%') { if (n + 1 < cap) out[n] = '%'; n++; continue; }
        if (c == 's') { spec[k++] = 's'; spec[k] = 0; uint32_t a = va32(v); snprintf(tmp, sizeof tmp, spec, a ? (const char *)VRT_G2H(a) : "(null)"); EMIT(tmp); }
        else if (c == 'c') { spec[k++] = 'c'; spec[k] = 0; snprintf(tmp, sizeof tmp, spec, (int)va32(v)); EMIT(tmp); }
        else if (c == 'p') { snprintf(tmp, sizeof tmp, "0x%x", va32(v)); EMIT(tmp); }
        else if (strchr("diouxX", c)) {
            if (ll >= 2) { spec[k++] = 'l'; spec[k++] = 'l'; spec[k++] = c; spec[k] = 0; snprintf(tmp, sizeof tmp, spec, (long long)va64(v)); }
            else { spec[k++] = c; spec[k] = 0; uint32_t a = va32(v); if (hh == 1) a &= 0xffff; if (hh == 2) a &= 0xff;
                   if (c == 'd' || c == 'i') snprintf(tmp, sizeof tmp, spec, (int)(hh == 1 ? (int16_t)a : hh == 2 ? (int8_t)a : (int32_t)a)); else snprintf(tmp, sizeof tmp, spec, a); }
            EMIT(tmp);
        } else if (strchr("fFeEgG", c)) { spec[k++] = c; spec[k] = 0; uint64_t b = va64(v); double d; memcpy(&d, &b, 8); snprintf(tmp, sizeof tmp, spec, d); EMIT(tmp); }
        else { tmp[0] = '%'; tmp[1] = c; tmp[2] = 0; EMIT(tmp); }
    }
    if (cap) out[n < cap ? n : cap - 1] = 0;
    return (int)n;
}
/* int sceClibSnprintf(char *buf, size_t size, const char *fmt, ...) */
HLE(sceClibSnprintf) { VA v = {x, 3, 0}; RET(guest_format(VRT_G2H(x->r[0]), x->r[1], VRT_G2H(x->r[2]), &v)); }
HLE(sceClibPrintf) { char buf[4096]; VA v = {x, 1, 0}; int n = guest_format(buf, sizeof buf, VRT_G2H(x->r[0]), &v); fprintf(stderr, "[game printf] %s", buf); RET(n); }

/* ------------------------------------------------------------------------------------------------ file I/O */
typedef struct { int fd; DIR *dir; } FileObj;
static const char *root_for(const char *dev) {
    if (!strcmp(dev, "app0:")) return getenv("VRT_APP0") ? getenv("VRT_APP0") : "game/app/PCSE00789";
    if (!strcmp(dev, "patch0:")) return getenv("VRT_PATCH0") ? getenv("VRT_PATCH0") : "game/patch/PCSE00789";
    return NULL;
}
/* translate a Vita path to a host path; `try_patch` lets app0: paths be overridden by patch0: files */
static int host_path(const char *vp, char *out, size_t cap, int for_write) {
    const char *colon = strchr(vp, ':'); char dev[32] = "";
    if (!colon || colon - vp > 12) { snprintf(out, cap, "vita_data/%s", vp); return 0; }
    snprintf(dev, sizeof dev, "%.*s:", (int)(colon - vp), vp);
    const char *rest = colon + 1; while (*rest == '/') rest++;
    const char *root = root_for(dev);
    if (!root) { snprintf(out, cap, "vita_data/%.*s/%s", (int)(colon - vp), vp, rest); return 0; }
    if (!for_write && !strcmp(dev, "app0:")) {                       /* patch overlay */
        char p[1100]; snprintf(p, sizeof p, "%s/%s", root_for("patch0:"), rest);
        if (access(p, F_OK) == 0) { snprintf(out, cap, "%s", p); return 0; }
    }
    snprintf(out, cap, "%s/%s", root, rest); return 0;
}
static int map_open_flags(uint32_t f) {
    int h = 0;
    if ((f & 3) == 3) h = O_RDWR; else if (f & 2) h = O_WRONLY; else h = O_RDONLY;
    if (f & 0x100) h |= O_APPEND; if (f & 0x200) h |= O_CREAT; if (f & 0x400) h |= O_TRUNC; if (f & 0x800) h |= O_EXCL;
    return h;
}
static uint32_t errno_to_sce(void) { return 0x80010000u | (uint32_t)errno; }
/* SceUID sceIoOpen(const char *file, int flags, SceMode mode) */
HLE(sceIoOpen) {
    char p[1200]; host_path((const char *)VRT_G2H(x->r[0]), p, sizeof p, (x->r[1] & 0x2) != 0);
    int fd = open(p, map_open_flags(x->r[1]), 0644);
    if (fd < 0) { if (getenv("VRT_IOLOG")) fprintf(stderr, "[io] open FAIL %s -> %s\n", (const char *)VRT_G2H(x->r[0]), p); RET(errno_to_sce()); return; }
    FileObj *f = calloc(1, sizeof *f); f->fd = fd;
    if (getenv("VRT_IOLOG")) fprintf(stderr, "[io] open %s -> %s fd=%d\n", (const char *)VRT_G2H(x->r[0]), p, fd);
    RET(h_new(H_FILE, f));
}
HLE(sceIoClose) { FileObj *f = h_get(x->r[0], H_FILE); if (!f) { RET(ERR_BADF); return; } close(f->fd); free(f); h_free(x->r[0]); RET(0); }
static int std_fd(uint32_t uid) { return uid == 0x1001 ? 1 : uid == 0x1002 ? 2 : -1; }
HLE(sceIoRead) { FileObj *f = h_get(x->r[0], H_FILE); if (!f) { RET(ERR_BADF); return; } ssize_t n = read(f->fd, VRT_G2H(x->r[1]), x->r[2]); RET(n < 0 ? errno_to_sce() : (uint32_t)n); }
HLE(sceIoWrite) {
    int sfd = std_fd(x->r[0]);
    if (sfd > 0) { fprintf(stderr, "[game stdout] "); fwrite(VRT_G2H(x->r[1]), 1, x->r[2], stderr); RET(x->r[2]); return; }
    FileObj *f = h_get(x->r[0], H_FILE); if (!f) { RET(ERR_BADF); return; }
    ssize_t n = write(f->fd, VRT_G2H(x->r[1]), x->r[2]); RET(n < 0 ? errno_to_sce() : (uint32_t)n);
}
HLE(sceIoPread) { FileObj *f = h_get(x->r[0], H_FILE); if (!f) { RET(ERR_BADF); return; }
    uint64_t off = (uint64_t)x->r[4] | 0; memcpy(&off, (uint8_t *)VRT_G2H(x->r[13]), 8);                /* SceOff is 64-bit, passed on the stack (8-aligned) */
    ssize_t n = pread(f->fd, VRT_G2H(x->r[1]), x->r[2], (off_t)off); RET(n < 0 ? errno_to_sce() : (uint32_t)n); }
HLE(sceIoPwrite) { FileObj *f = h_get(x->r[0], H_FILE); if (!f) { RET(ERR_BADF); return; }
    uint64_t off; memcpy(&off, (uint8_t *)VRT_G2H(x->r[13]), 8);
    ssize_t n = pwrite(f->fd, VRT_G2H(x->r[1]), x->r[2], (off_t)off); RET(n < 0 ? errno_to_sce() : (uint32_t)n); }
/* SceOff sceIoLseek(SceUID fd, SceOff offset, int whence): offset in r2:r3 (aligned pair), whence on the stack */
HLE(sceIoLseek) { FileObj *f = h_get(x->r[0], H_FILE); if (!f) { ret64(x, (uint64_t)(int64_t)-1); return; }
    int64_t off = (int64_t)((uint64_t)x->r[2] | ((uint64_t)x->r[3] << 32)); uint32_t wh; memcpy(&wh, (uint8_t *)VRT_G2H(x->r[13]), 4);
    off_t r = lseek(f->fd, (off_t)off, wh == 1 ? SEEK_CUR : wh == 2 ? SEEK_END : SEEK_SET); ret64(x, (uint64_t)(int64_t)r); }
HLE(sceIoLseek32) { FileObj *f = h_get(x->r[0], H_FILE); if (!f) { RET(ERR_BADF); return; }
    off_t r = lseek(f->fd, (int32_t)x->r[1], x->r[2] == 1 ? SEEK_CUR : x->r[2] == 2 ? SEEK_END : SEEK_SET); RET((uint32_t)r); }
HLE(sceIoSync) { RET(0); }
HLE(sceIoSyncByFd) { RET(0); }
HLE(sceIoDevctl) { RET(ERR_FAIL); }
HLE(sceIoIoctl) { RET(ERR_FAIL); }
HLE(sceIoChstat) { RET(0); }
HLE(sceIoMkdir) { char p[1200]; host_path((const char *)VRT_G2H(x->r[0]), p, sizeof p, 1); RET(mkdir(p, 0755) ? errno_to_sce() : 0); }
HLE(sceIoRmdir) { char p[1200]; host_path((const char *)VRT_G2H(x->r[0]), p, sizeof p, 1); RET(rmdir(p) ? errno_to_sce() : 0); }
HLE(sceIoRemove) { char p[1200]; host_path((const char *)VRT_G2H(x->r[0]), p, sizeof p, 1); RET(unlink(p) ? errno_to_sce() : 0); }
HLE(sceIoRename) { char a[1200], b[1200]; host_path((const char *)VRT_G2H(x->r[0]), a, sizeof a, 1); host_path((const char *)VRT_G2H(x->r[1]), b, sizeof b, 1); RET(rename(a, b) ? errno_to_sce() : 0); }
/* SceIoStat (vita-headers): u32 mode; u32 attr; s64 size; 3 x SceDateTime(16B) ... we fill mode, attr, size */
static void fill_stat(uint32_t gp, struct stat *st) {
    uint8_t *d = VRT_G2H(gp); memset(d, 0, 88);
    uint32_t mode = S_ISDIR(st->st_mode) ? 0x1000u | 0x1ffu : 0x2000u | 0x1ffu, attr = S_ISDIR(st->st_mode) ? 0x1000u : 0x2000u; int64_t size = st->st_size;
    memcpy(d, &mode, 4); memcpy(d + 4, &attr, 4); memcpy(d + 8, &size, 8);
}
HLE(sceIoGetstat) { char p[1200]; struct stat st; host_path((const char *)VRT_G2H(x->r[0]), p, sizeof p, 0); if (stat(p, &st)) { RET(errno_to_sce()); return; } fill_stat(x->r[1], &st); RET(0); }
HLE(sceIoGetstatByFd) { FileObj *f = h_get(x->r[0], H_FILE); struct stat st; if (!f || fstat(f->fd, &st)) { RET(ERR_BADF); return; } fill_stat(x->r[1], &st); RET(0); }
HLE(sceIoDopen) {
    char p[1200]; host_path((const char *)VRT_G2H(x->r[0]), p, sizeof p, 0); DIR *d = opendir(p);
    if (!d) { RET(errno_to_sce()); return; }
    FileObj *f = calloc(1, sizeof *f); f->dir = d; RET(h_new(H_DIR, f));
}
HLE(sceIoDclose) { FileObj *f = h_get(x->r[0], H_DIR); if (!f) { RET(ERR_BADF); return; } closedir(f->dir); free(f); h_free(x->r[0]); RET(0); }
/* SceIoDirent: SceIoStat (88 bytes) followed by char d_name[256] */
HLE(sceIoDread) {
    FileObj *f = h_get(x->r[0], H_DIR); if (!f) { RET(ERR_BADF); return; }
    struct dirent *e = readdir(f->dir); if (!e) { RET(0); return; }
    uint8_t *d = VRT_G2H(x->r[1]); memset(d, 0, 88 + 256);
    struct stat st; memset(&st, 0, sizeof st); st.st_mode = e->d_type == DT_DIR ? S_IFDIR : S_IFREG; fill_stat(x->r[1], &st);
    strncpy((char *)d + 88, e->d_name, 255); RET(1);
}
