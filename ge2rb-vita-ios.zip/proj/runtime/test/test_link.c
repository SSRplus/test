/* usage: test_link APPDIR PATCHDIR   (patch files override app files with the same relative path, like on the Vita)
   Loads every module, resolves all imports and prints a summary + the system imports that have no HLE. */
#include "vita_link.h"
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

static int cmp(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }
static int exists(const char *p) { struct stat st; return stat(p, &st) == 0; }
static int is_mod(const char *n) { size_t l = strlen(n); return (l > 5 && !strcmp(n + l - 5, ".self")) || (l > 6 && !strcmp(n + l - 6, ".suprx")); }

static int add(const char *appdir, const char *patchdir, const char *rel) {
    char p[1100]; snprintf(p, sizeof p, "%s/%s", patchdir, rel);
    if (!exists(p)) snprintf(p, sizeof p, "%s/%s", appdir, rel);
    vrt_module m;
    int rc = vrt_load_self(p, &m);
    if (rc) { printf("FAIL load %s rc=%d\n", rel, rc); return 1; }
    vrt_link_add_module(&m, rel);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 3) return 2;
    const char *app = argv[1], *patch = argv[2];
    if (vrt_init(0)) return 3;
    int bad = add(app, patch, "eboot.bin");
    const char *dirs[] = {"bin", "sce_module", "modules_psvita"};
    for (int d = 0; d < 3; d++) {
        char *names[512]; int n = 0;
        for (int side = 0; side < 2; side++) {                         /* union of app and patch listings */
            char p[1100]; snprintf(p, sizeof p, "%s/%s", side ? patch : app, dirs[d]);
            DIR *dh = opendir(p); if (!dh) continue;
            struct dirent *e;
            while ((e = readdir(dh)) && n < 512) {
                if (!is_mod(e->d_name)) continue;
                int dup = 0; for (int i = 0; i < n; i++) if (!strcmp(names[i], e->d_name)) dup = 1;
                if (!dup) names[n++] = strdup(e->d_name);
            }
            closedir(dh);
        }
        qsort(names, n, sizeof *names, cmp);
        for (int i = 0; i < n; i++) { char rel[300]; snprintf(rel, sizeof rel, "%s/%s", dirs[d], names[i]); bad += add(app, patch, rel); }
    }
    vrt_link_stats st; vrt_link_resolve(&st);
    printf("modules=%d exports_func=%d exports_var=%d game_func=%d game_var=%d hle_func_bound=%d hle_func_missing=%d hle_var=%d load_failures=%d exports=%d\n",
           st.modules, st.exports_func, st.exports_var, st.game_func, st.game_var, st.hle_func_bound, st.hle_func_missing, st.hle_var, bad, st.exports_func + st.exports_var);
    vrt_link_report_missing(stdout);
    return bad ? 1 : 0;
}
