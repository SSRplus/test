#include "vita_ops.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    uint8_t c, v;
    assert(vrt_adc(0xffffffffu, 1, 0, &c, &v) == 0 && c == 1 && v == 0);
    assert(vrt_adc(0x7fffffffu, 1, 0, &c, &v) == 0x80000000u && c == 0 && v == 1);
    assert(vrt_adc(0x80000000u, 0x80000000u, 0, &c, &v) == 0 && c == 1 && v == 1);
    /* SUB a-b == a + ~b + 1 : 5-5 -> 0 with C=1 (no borrow) */
    assert(vrt_adc(5, ~5u, 1, &c, &v) == 0 && c == 1 && v == 0);
    assert(vrt_adc(3, ~5u, 1, &c, &v) == 0xfffffffeu && c == 0 && v == 0);   /* 3-5: borrow -> C=0 */
    c = 0; assert(vrt_lsl(0x80000001u, 1, &c) == 2 && c == 1);
    c = 1; assert(vrt_lsl(0x12345678u, 0, &c) == 0x12345678u && c == 1);       /* amount 0: C unchanged */
    c = 0; assert(vrt_lsl(1, 32, &c) == 0 && c == 1);
    c = 1; assert(vrt_lsl(1, 33, &c) == 0 && c == 0);
    c = 0; assert(vrt_lsr(3, 1, &c) == 1 && c == 1);
    c = 0; assert(vrt_lsr(0x80000000u, 32, &c) == 0 && c == 1);
    c = 0; assert(vrt_asr(0x80000000u, 31, &c) == 0xffffffffu && c == 0);
    c = 0; assert(vrt_asr(0x80000000u, 40, &c) == 0xffffffffu && c == 1);
    c = 0; assert(vrt_ror(0x00000003u, 1, &c) == 0x80000001u && c == 1);
    c = 0; assert(vrt_ror(0x80000000u, 32, &c) == 0x80000000u && c == 1);
    c = 1; assert(vrt_rrx(2, 0, &c) == 0x80000001u && c == 0);
    assert(vrt_rev(0x11223344u) == 0x44332211u && vrt_rev16(0x11223344u) == 0x22114433u);
    assert(vrt_revsh(0x00000180u) == 0xffff8001u);
    assert(vrt_rbit(1) == 0x80000000u && vrt_clz(0) == 32 && vrt_clz(1) == 31);
    assert(vrt_sx8(0xff) == 0xffffffffu && vrt_sx16(0x8000) == 0xffff8000u);
    assert(vrt_init(0) == 0); vrt_alloc(4096, 4096);
    uint32_t g = 0x90000001u;                                                    /* unaligned access */
    vrt_st32(g, 0xa1b2c3d4u); assert(vrt_ld32(g) == 0xa1b2c3d4u && vrt_ld8(g) == 0xd4 && vrt_ld16(g + 1) == 0xb2c3);
    /* VFP helpers */
    assert(vrt_f2s(1.9f) == 1 && vrt_f2s(-1.9f) == 0xffffffffu && vrt_f2s(3e9f) == 0x7fffffffu && vrt_f2s(-3e9f) == 0x80000000u && vrt_f2s(__builtin_nanf("")) == 0);
    assert(vrt_f2u(-5.0f) == 0 && vrt_f2u(5e9f) == 0xffffffffu && vrt_f2u(7.9f) == 7);
    assert(vrt_d2s(-2147483648.5) == 0x80000000u && vrt_d2s(2147483647.9) == 0x7fffffffu && vrt_d2u(4294967295.5) == 0xffffffffu && vrt_d2u(-0.5) == 0);
    vrt_ctx cx; memset(&cx, 0, sizeof cx);
    vrt_fcmp32(&cx, 1.0f, 2.0f); assert((cx.fpscr >> 28) == 0x8);
    vrt_fcmp32(&cx, 2.0f, 2.0f); assert((cx.fpscr >> 28) == 0x6);
    vrt_fcmp32(&cx, 3.0f, 2.0f); assert((cx.fpscr >> 28) == 0x2);
    vrt_fcmp64(&cx, __builtin_nan(""), 2.0); assert((cx.fpscr >> 28) == 0x3);
    /* exclusives */
    uint32_t e = 0x90000100u; vrt_st32(e, 5);
    assert(vrt_strex32(&cx, e, 9) == 1 && vrt_ld32(e) == 5);          /* no monitor: fails, no write */
    assert(vrt_ldrex32(&cx, e) == 5 && vrt_strex32(&cx, e, 9) == 0 && vrt_ld32(e) == 9);
    assert(vrt_ldrex32(&cx, e) == 9); vrt_st32(e, 1); assert(vrt_strex32(&cx, e, 2) == 1 && vrt_ld32(e) == 1);   /* value changed */
    uint32_t e8 = 0x90000200u; vrt_st64(e8, 0x1122334455667788ull);
    assert(vrt_ldrex64(&cx, e8) == 0x1122334455667788ull && vrt_strex64(&cx, e8, 7) == 0 && vrt_ld64(e8) == 7);
    vrt_st16(e8, 0xabcd); assert(vrt_ldrex16(&cx, e8) == 0xabcd && vrt_strex16(&cx, e8, 0x1234) == 0 && vrt_ld16(e8) == 0x1234);
    assert(vrt_vadd(0xffffffff00000001ull, 0x0000000100000001ull, 32) == 0x0000000000000002ull);
    assert(vrt_vadd(0x00ff00ff00ff00ffull, 0x0001000100010001ull, 16) == 0x0100010001000100ull);
    assert(vrt_vsub(0x0000000000000000ull, 0x0000000100000001ull, 32) == 0xffffffffffffffffull);
    assert(vrt_vsub(0x0100010001000100ull, 0x0001000100010001ull, 16) == 0x00ff00ff00ff00ffull);
    assert(vrt_vmul(0x0000000300000004ull, 0x0000000200000005ull, 32) == 0x0000000600000014ull);
    assert(vrt_vadd(0xffffffffffffffffull, 2, 64) == 1);
    /* NEON helpers (hand-checked) */
    { vrt_u128 r = vrt_vmull128(0x0004000300020001ull, 0x000a000a000a000aull, 16, 1);
      assert((uint64_t)r == 0x000000140000000aull && (uint64_t)(r >> 64) == 0x000000280000001eull);
      r = vrt_vmull128(0x000000000000ffffull, 0x0000000000000005ull, 16, 1); assert((uint32_t)r == 0xfffffffbu);        /* -1 * 5 */
      r = vrt_vmull128(0x000000000000ffffull, 0x0000000000000005ull, 16, 0); assert((uint32_t)r == 0x4fffbu);           /* 65535 * 5 */
      assert((uint32_t)vrt_widen(0x80ffull, 8, 1, 0) == 0xff80ffffu && (uint32_t)vrt_widen(0x80ffull, 8, 0, 0) == 0x008000ffu);
      assert((uint32_t)vrt_widen(0x80ffull, 8, 0, 4) == 0x08000ff0u);
      assert(vrt_shr_imm(0x0000000080008000ull, 16, 3, 1) == 0x00000000f000f000ull && vrt_shr_imm(0x0000000080008000ull, 16, 3, 0) == 0x0000000010001000ull);
      assert(vrt_shl_imm(0x0101010101010101ull, 8, 3) == 0x0808080808080808ull);
      assert(vrt_sli(~0ull, 1ull, 8, 4) == 0x0f0f0f0f0f0f0f1full);
      assert(vrt_shrn(vrt_q128(0x9abcdef012345678ull, 0), 32, 16) == 0x000000009abc1234ull);
      assert(vrt_vpadd(0x0807060504030201ull, 0x0101010101010101ull, 8) == 0x020202020f0b0703ull);
      assert(vrt_vpaddl(0x808001ffull, 8, 1) == 0x00000000ff000000ull);
      uint64_t d = 0x0706050403020100ull, m = 0x0f0e0d0c0b0a0908ull; vrt_vuzp(&d, &m, 8);
      assert(d == 0x0e0c0a0806040200ull && m == 0x0f0d0b0907050301ull);
      assert(vrt_vrev(0x0807060504030201ull, 8, 32) == 0x0506070801020304ull);
      assert(vrt_vcmp_i(0x0004000300020001ull, 0x0002000200020002ull, 16, VRT_GE, 0) == 0xffffffffffff0000ull);
      assert(vrt_vcmp_i(0x00000000ffffffffull, 0ull, 32, VRT_LT, 1) == 0x00000000ffffffffull);              /* -1 < 0 signed */
      assert(vrt_vmaxmin_i(0x0000000000000003ull | (0xffull << 8), 0x0000000000000005ull, 8, 1, 1) == 0x0000000000000005ull);
      assert(vrt_dup_el(0x1122334455667788ull, 2, 16) == 0x3344334433443344ull);
    }
    /* estimates: values known from the ARM ARM / QEMU */
    assert(vrt_recpe_f32(0x3f800000u) == 0x3f7f8000u);          /* 1/1.0   -> 0.99609375 */
    assert(vrt_recpe_f32(0x40000000u) == 0x3eff8000u);          /* 1/2.0 -> 0.49804688 */
    assert(vrt_recpe_f32(0) == 0x7f800000u && vrt_recpe_f32(0x80000000u) == 0xff800000u && vrt_recpe_f32(0x7f800000u) == 0);
    assert(vrt_rsqrte_f32(0x3f800000u) == 0x3f7f8000u);          /* rsqrt(1.0) -> 0.99609375 */
    assert(vrt_rsqrte_f32(0xbf800000u) == 0x7fc00000u && vrt_rsqrte_f32(0) == 0x7f800000u && vrt_rsqrte_f32(0x7f800000u) == 0);
    { float r = vrt_bits2f(vrt_rsqrte_f32(vrt_f2bits(4.0f))); assert(r > 0.49f && r < 0.51f); r = vrt_bits2f(vrt_recpe_f32(vrt_f2bits(4.0f))); assert(r > 0.24f && r < 0.26f); }
    assert(vrt_recps_f32(vrt_f2bits(2.0f), vrt_f2bits(0.25f)) == vrt_f2bits(1.5f));        /* 2 - 2*0.25 */
    assert(vrt_rsqrts_f32(vrt_f2bits(1.0f), vrt_f2bits(1.0f)) == vrt_f2bits(1.0f));        /* (3-1)/2 */
    assert(vrt_rsqrts_f32(0x7f800000u, 0) == 0x3fc00000u && vrt_recps_f32(0, 0x7f800000u) == 0x40000000u);
    assert((uint64_t)vrt_vmull_p8(0x03, 0x03) == 0x5 && (uint64_t)vrt_vmull_p8(0x80, 0x80) == 0x4000);   /* (x+1)^2 = x^2+1 ; x^7*x^7 = x^14 */
    assert(vrt_h2f(0x3c00) == 1.0f && vrt_h2f(0xc000) == -2.0f && vrt_h2f(0x7c00) == __builtin_inff() && vrt_h2f(0x0001) > 5.9e-8f && vrt_h2f(0x0001) < 6.0e-8f);
    assert(vrt_f2h(1.0f) == 0x3c00 && vrt_f2h(-2.0f) == 0xc000 && vrt_f2h(65520.0f) == 0x7c00 && vrt_f2h(1.0f/3.0f) == 0x3555 && vrt_f2h(5.96046448e-8f) == 0x0001);
    puts("ops ok"); return 0;
}
