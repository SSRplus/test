/* usage: test_loader GAMEDIR  (GAMEDIR holds eboot.bin and bin/NAME.self) -> one line per module, checked by converter/check_loader.py */
#include "vita_loader.h"
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint64_t fnv(const uint8_t *p, size_t n) { uint64_t h = 1469598103934665603ull; for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ull; } return h; }
static int cmp(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }

static int one(const char *path, const char *rel) {
    vrt_module m;
    int rc = vrt_load_self(path, &m);
    if (rc) { printf("FAIL %s rc=%d\n", rel, rc); return 1; }
    printf("MOD %s nseg=%d relocs=%u", rel, m.nseg, m.relocs_applied);
    for (int i = 0; i < m.nseg; i++)
        printf(" b%d=%x m%d=%x h%d=%016llx", i, m.base[i], i, m.memsz[i], i, (unsigned long long)fnv((uint8_t *)VRT_G2H(m.base[i]), m.memsz[i]));
    printf("\n");
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    if (vrt_init(0)) return 3;
    char p[1024]; int bad = 0;
    snprintf(p, sizeof p, "%s/eboot.bin", argv[1]); bad += one(p, "eboot.bin");
    snprintf(p, sizeof p, "%s/bin", argv[1]);
    DIR *d = opendir(p); if (!d) return 4;
    char *names[256]; int n = 0; struct dirent *e;
    while ((e = readdir(d)) && n < 256) if (strstr(e->d_name, ".self")) names[n++] = strdup(e->d_name);
    closedir(d); qsort(names, n, sizeof *names, cmp);
    for (int i = 0; i < n; i++) { char rel[300]; snprintf(rel, sizeof rel, "bin/%s", names[i]); snprintf(p, sizeof p, "%s/%s", argv[1], rel); bad += one(p, rel); }
    return bad ? 1 : 0;
}
