#!/usr/bin/env python3
"""Differential test: lifted C vs Unicorn, on REAL instruction encodings taken from the game.

For every supported mnemonic: pick up to --per distinct encodings found in the game (outside IT blocks),
run each from --states random register/flag/memory states in Unicorn and in the lifted C, compare r0-r14, NZCV, memory.
Needs: pip install capstone unicorn ; gcc.
"""
import argparse, collections, ctypes, os, random, struct, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from unicorn import Uc, UcError, UC_ARCH_ARM, UC_MODE_THUMB
from unicorn import arm_const as U
import lift
from lift import INSNAME, cond_c
from vita_self import VitaModule

CODE, DATA, DSIZE = 0x10000000, 0x20000000, 0x10000
MEMLIKE = ('LD', 'ST', 'PUSH', 'POP', 'VLD', 'VST', 'VPUSH', 'VPOP')
CONTROL = {'MRC', 'PLD', 'PLDW', 'PLI', 'B', 'BL', 'BLX', 'BX', 'CBZ', 'CBNZ', 'TBB', 'TBH', 'IT', 'NOP', 'DMB', 'DSB', 'ISB'}
INC = os.path.join(HERE, '..', 'runtime', 'include')
SRC = os.path.join(HERE, '..', 'runtime', 'src')
HAR = os.path.join(HERE, '..', 'runtime', 'test', 'harness.c')


class Ctx(ctypes.Structure):
    _fields_ = [('r', ctypes.c_uint32 * 16), ('n', ctypes.c_uint8), ('z', ctypes.c_uint8), ('c', ctypes.c_uint8),
                ('v', ctypes.c_uint8), ('q', ctypes.c_uint8), ('ge', ctypes.c_uint32), ('s', ctypes.c_uint64 * 32),
                ('fpscr', ctypes.c_uint32), ('tls', ctypes.c_uint32), ('ex_addr', ctypes.c_uint32), ('ex_val', ctypes.c_uint64), ('last_call', ctypes.c_uint32)]


def _nan32(u): return (u & 0x7f800000) == 0x7f800000 and (u & 0x007fffff) != 0
def _nan64(u): return ((u >> 52) & 0x7ff) == 0x7ff and (u & 0xfffffffffffff) != 0

def d_equiv(a, b):
    """Equal, or NaN-vs-NaN. x86 (the CI machine) makes a NEGATIVE default NaN, ARM/arm64 a positive one: ignore NaN sign/payload."""
    if a == b:
        return True
    if all(((a >> sh) & 0xffffffff) == ((b >> sh) & 0xffffffff) or (_nan32((a >> sh) & 0xffffffff) and _nan32((b >> sh) & 0xffffffff)) for sh in (0, 32)):
        return True
    return _nan64(a) and _nan64(b)

def collect_samples(app, patch, mods, per):
    from prep import collect
    files = collect(app, 'app')
    if patch:
        files.update(collect(patch, 'patch'))
    seen = collections.defaultdict(collections.Counter)
    text = {}
    for rel, (p, _) in sorted(files.items()):
        if not any(k in rel for k in mods):
            continue
        m = VitaModule(p)
        code, fns = lift._functions(m)
        lf = lift.Lifter(code.ph['vaddr'], m.read)
        for s, e in fns:
            dec, _ = lf.decode(s & ~1, e)
            for insn in dec.values():
                name = INSNAME.get(insn.id, insn.mnemonic)
                if name in CONTROL or cond_c(insn.cc):
                    continue
                if name in ('POP', 'LDM', 'LDMIA', 'LDMDB') and any(o.type == lift.OP_REG and o.reg == lift.K.ARM_REG_PC for o in insn.operands):
                    continue
                scratch = lift.Lifter(code.ph['vaddr'], m.read)
                scratch.emit(insn)
                if scratch.stats['bad']:
                    continue
                b = bytes(insn.bytes)
                seen[name][b] += 1
                text[b] = f"{insn.mnemonic} {insn.op_str}"
    rng = random.Random(1)
    picked = {}
    for name, cnt in seen.items():
        enc = [b for b, _ in cnt.most_common()]
        pick = enc[:per // 2] + rng.sample(enc[per // 2:], min(len(enc[per // 2:]), per - per // 2))
        picked[name] = [(b, text[b]) for b in pick]
    return picked


def rand_val(rng):
    if rng.random() < 0.4:
        return rng.choice([0, 1, 2, 3, 0x7fffffff, 0x80000000, 0xffffffff, 0xfffffffe, 0xffff, 0xffff0000, 0x80, 0xff, 0x100, 31, 32, 33])
    return rng.getrandbits(32)


FP32 = [0x00000000, 0x80000000, 0x3f800000, 0xbf800000, 0x3fc00000, 0x40490fdb, 0x7f7fffff, 0x00000001, 0x7f800000,
        0xff800000, 0x4f000000, 0xcf000000, 0x4f800000, 0x3f000000, 0x41200000, 0xc2c80000]
FP64 = [struct.unpack('<Q', struct.pack('<d', v))[0] for v in (0.0, -0.0, 1.0, -1.0, 1.5, 3.14159, 1e300, 5e-324, float('inf'),
        float('-inf'), 2147483648.0, -2147483649.0, 4294967296.0, 0.5, 10.0, 123456.789)]

def rand_d(rng):
    r = rng.random()
    if r < 0.35:
        return rng.choice(FP64)
    if r < 0.7:
        return (rng.choice(FP32) << 32) | rng.choice(FP32)
    if r < 0.85:
        return struct.unpack('<Q', struct.pack('<ff', rng.uniform(-1e6, 1e6), rng.uniform(-100, 100)))[0]
    return rng.getrandbits(64)

def rand_state(rng, memlike=False):
    regs = []
    for i in range(13):
        if rng.random() < (0.6 if memlike else 0.3):
            regs.append(DATA + 0x2000 + rng.randrange(0, 0x2000) * (4 if rng.random() < 0.9 else 1))
        else:
            regs.append(rand_val(rng))
    sp = DATA + 0x8000 + rng.randrange(0, 0x400) * 4
    lr = rand_val(rng)
    return regs, sp, lr, rng.getrandbits(4), [rand_d(rng) for _ in range(32)], rng.getrandbits(4)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--app', required=True); ap.add_argument('--patch'); ap.add_argument('--out', default='difftest.txt')
    ap.add_argument('--modules', default='eboot,god.self,god_g000_Field,net.self,enemy.self')
    ap.add_argument('--per', type=int, default=12); ap.add_argument('--states', type=int, default=24)
    a = ap.parse_args()
    picked = collect_samples(a.app, a.patch, a.modules.split(','), a.per)
    tests = [(n, b, t) for n, lst in sorted(picked.items()) for b, t in lst]
    print(f"{len(picked)} mnemonics, {len(tests)} encodings", flush=True)

    body = ['#include "vita_ops.h"', 'uint32_t MOD_B;', 'uint32_t MOD_SEG[4];']
    for i, (n, b, t) in enumerate(tests):
        lf = lift.Lifter(CODE, lambda addr, k, b=b: b[addr - CODE:addr - CODE + k])
        body.append(lf.lift_function(CODE | 1, CODE + len(b), f"t{i}", single=True))
    d = tempfile.mkdtemp()
    cpath, so = os.path.join(d, 'tests.c'), os.path.join(d, 'tests.so')
    open(cpath, 'w').write("\n".join(body))
    srcs = [os.path.join(SRC, f) for f in os.listdir(SRC) if f.endswith('.c')]
    r = subprocess.run(['gcc', '-shared', '-fPIC', '-O1', '-w', '-ffp-contract=off', '-fno-math-errno', '-I', INC, *srcs, HAR, cpath, '-o', so, '-lpthread', '-lm'],
                       capture_output=True, text=True)
    if r.returncode:
        print(r.stderr[:4000]); sys.exit('generated C failed to compile')
    lib = ctypes.CDLL(so)
    lib.vrt_commit.argtypes = [ctypes.c_uint32, ctypes.c_size_t]
    lib.vrt_harness_run.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    assert lib.vrt_init(0) == 0 and lib.vrt_commit(CODE, 0x1000) == 0 and lib.vrt_commit(DATA, DSIZE) == 0
    mem = ctypes.c_void_p.in_dll(lib, 'vrt_mem').value
    mod_b = ctypes.c_uint32.in_dll(lib, 'MOD_B'); mod_b.value = CODE

    mu = Uc(UC_ARCH_ARM, UC_MODE_THUMB)
    mu.mem_map(CODE, 0x1000); mu.mem_map(DATA, DSIZE)
    UR = [getattr(U, f'UC_ARM_REG_R{i}') for i in range(13)]
    UD = [getattr(U, f'UC_ARM_REG_D{i}') for i in range(32)]
    try:
        mu.reg_write(U.UC_ARM_REG_C1_C0_2, 0xf00000)        # CPACR: allow cp10/cp11
        mu.reg_write(U.UC_ARM_REG_FPEXC, 0x40000000)        # FPEXC.EN
    except Exception as e:
        print('could not enable VFP in Unicorn:', e)
    rng = random.Random(7)
    res = collections.defaultdict(lambda: dict(tests=0, ok=0, fail=0, skip=0, enc=set(), ex=[]))
    for i, (name, b, text) in enumerate(tests):
        fn = ctypes.cast(getattr(lib, f"t{i}"), ctypes.c_void_p)
        R = res[name]; R['enc'].add(b)
        fp = name in lift.VFP_NAMES
        for _ in range(a.states):
            regs, sp, lr, fl, dregs, fpfl = rand_state(rng, name.startswith(MEMLIKE))
            page = b + bytes(rng.getrandbits(8) for _ in range(0x1000 - len(b)))
            data = bytes(rng.getrandbits(8) for _ in range(DSIZE))
            mu.mem_write(CODE, page); mu.mem_write(DATA, data)
            mu.reg_write(U.UC_ARM_REG_CPSR, 0x30 | (fl << 28))      # CPSR first: a previous fault may have left another mode
            for k in range(13): mu.reg_write(UR[k], regs[k])
            mu.reg_write(U.UC_ARM_REG_SP, sp); mu.reg_write(U.UC_ARM_REG_LR, lr)
            if fp:
                for k in range(32): mu.reg_write(UD[k], dregs[k])
                mu.reg_write(U.UC_ARM_REG_FPSCR, fpfl << 28)
            try:
                mu.emu_start(CODE | 1, CODE + len(b), count=1)
            except UcError:
                R['skip'] += 1; continue
            exp = [mu.reg_read(UR[k]) for k in range(13)] + [mu.reg_read(U.UC_ARM_REG_SP), mu.reg_read(U.UC_ARM_REG_LR)]
            cp = mu.reg_read(U.UC_ARM_REG_CPSR)
            exp_f = ((cp >> 31) & 1, (cp >> 30) & 1, (cp >> 29) & 1, (cp >> 28) & 1)
            exp_mem = bytes(mu.mem_read(DATA, DSIZE))
            exp_d = [mu.reg_read(UD[k]) for k in range(32)] if fp else None
            exp_fpscr = (mu.reg_read(U.UC_ARM_REG_FPSCR) >> 28) & 0xf if fp else None
            ctypes.memmove(mem + CODE, page, 0x1000); ctypes.memmove(mem + DATA, data, DSIZE)
            c = Ctx()
            for k in range(13): c.r[k] = regs[k]
            c.r[13], c.r[14] = sp, lr
            c.n, c.z, c.c, c.v = (fl >> 3) & 1, (fl >> 2) & 1, (fl >> 1) & 1, fl & 1
            if fp:
                for k in range(32): c.s[k] = dregs[k]
                c.fpscr = fpfl << 28
            rc = lib.vrt_harness_run(fn, ctypes.byref(c))
            got = [c.r[k] for k in range(15)]
            got_f = (c.n, c.z, c.c, c.v)
            got_mem = ctypes.string_at(mem + DATA, DSIZE)
            got_d = [c.s[k] for k in range(32)] if fp else None
            got_fpscr = (c.fpscr >> 28) & 0xf if fp else None
            R['tests'] += 1
            if rc == 0 and got == exp and got_f == exp_f and got_mem == exp_mem and (not fp or all(d_equiv(x_, y_) for x_, y_ in zip(got_d, exp_d))) and got_fpscr == exp_fpscr:
                R['ok'] += 1; continue
            R['fail'] += 1
            if len(R['ex']) < 3:
                if rc != 0: why = 'C code crashed/aborted'
                else:
                    diffs = [f"r{k}: want {exp[k]:#x} got {got[k]:#x}" for k in range(15) if exp[k] != got[k]]
                    if exp_f != got_f: diffs.append(f"NZCV want {exp_f} got {got_f}")
                    if exp_mem != got_mem: diffs.append("memory differs")
                    if fp:
                        diffs += [f"d{k}: want {exp_d[k]:#018x} got {got_d[k]:#018x} (in {dregs[k]:#018x})" for k in range(32) if not d_equiv(got_d[k], exp_d[k])][:3]
                        if exp_fpscr != got_fpscr: diffs.append(f"FPSCR nzcv want {exp_fpscr:04b} got {got_fpscr:04b}")
                    why = "; ".join(diffs[:5])
                R['ex'].append(f"    {b.hex()}  {text}  in(NZCV={fl:04b}) -> {why}")
    lines = []
    tot_ok = sum(r['ok'] for r in res.values()); tot = sum(r['tests'] for r in res.values())
    lines.append(f"TOTAL {tot_ok}/{tot} passed ({100 * tot_ok / max(1, tot):.2f}%)   mnemonics fully passing: "
                 f"{sum(1 for r in res.values() if r['fail'] == 0 and r['tests'])}/{len(res)}")
    for name, r in sorted(res.items(), key=lambda kv: (-kv[1]['fail'], kv[0])):
        lines.append(f"{name:8} encodings={len(r['enc']):3} tests={r['tests']:5} ok={r['ok']:5} FAIL={r['fail']:4} skipped={r['skip']:4}")
        lines += r['ex']
    open(a.out, 'w').write("\n".join(lines) + "\n")
    print("\n".join(lines[:200]))


if __name__ == '__main__':
    main()
