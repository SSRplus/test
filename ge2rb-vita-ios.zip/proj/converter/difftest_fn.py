#!/usr/bin/env python3
"""Whole-FUNCTION differential test (Thumb and ARM): control flow, IT blocks, loops, calls-free leaf code, jump tables, literal pools.
Each chosen function runs in Unicorn (the module's real bytes at their link addresses) and as lifted C with the same random inputs;
r0-r12, sp and memory (stack area + the module's data segment) must match. Functions that call other code (vrt_call) or contain
unsupported instructions are skipped; states where Unicorn faults or does not return are skipped too."""
import argparse, collections, ctypes, hashlib, os, random, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lift
from vita_self import VitaModule
from prep import collect
from relocs import text_movwt_relocs

SENT, DATA, DSIZE = 0x10000000, 0x20000000, 0x10000
INC = os.path.join(HERE, '..', 'runtime', 'include'); SRC = os.path.join(HERE, '..', 'runtime', 'src'); HAR = os.path.join(HERE, '..', 'runtime', 'test', 'harness.c')


class Ctx(ctypes.Structure):
    _fields_ = [('r', ctypes.c_uint32 * 16), ('n', ctypes.c_uint8), ('z', ctypes.c_uint8), ('c', ctypes.c_uint8), ('v', ctypes.c_uint8),
                ('q', ctypes.c_uint8), ('ge', ctypes.c_uint32), ('s', ctypes.c_uint64 * 32), ('fpscr', ctypes.c_uint32), ('tls', ctypes.c_uint32),
                ('ex_addr', ctypes.c_uint32), ('ex_val', ctypes.c_uint64), ('last_call', ctypes.c_uint32)]


def rand_val(rng):
    if rng.random() < 0.4:
        return rng.choice([0, 1, 2, 3, 4, 7, 8, 0xff, 0x100, 0xffff, 0x7fffffff, 0x80000000, 0xffffffff, 0xfffffffe, 31, 32, 33, 1000])
    return rng.getrandbits(32)


def gather(app, patch, mods, max_thumb, max_size):
    files = collect(app, 'app')
    if patch:
        files.update(collect(patch, 'patch'))
    out = []
    for rel, (p, _) in sorted(files.items()):
        if not any(k in rel for k in mods):
            continue
        m = VitaModule(p)
        code, fns = lift._functions(m)
        rl = text_movwt_relocs(m)
        lf = lift.Lifter(code.ph['vaddr'], m.read, relocs=rl)
        lifted, _, _ = lift._lift_all(m, lf, code, fns, lambda s: 'f')
        allst = sorted({s & ~1 for s in m.function_starts()} | {s & ~1 for s, _ in lifted} | {code.ph['vaddr'] + len(code.data)})
        seen = set(); cand = []
        for s, e in fns:
            if (e - (s & ~1)) <= max_size:
                body = m.read(s & ~1, e - (s & ~1)); h = hashlib.md5(body).hexdigest()
                if h not in seen:
                    seen.add(h); cand.append((h, s, e, 'thumb'))
        cand.sort(); chosen = cand[:max_thumb]
        for s, _ in lifted:
            if not s & 1:
                e = min(min(x for x in allst if x > s), s + 0x2000)
                h = hashlib.md5(m.read(s, e - s)).hexdigest()
                if h not in seen:
                    seen.add(h); chosen.append((h, s, e, 'arm'))
        out += [(rel, m, code, rl, s, e, mode) for _, s, e, mode in chosen]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--app', required=True); ap.add_argument('--patch'); ap.add_argument('--out', default='difftest_fn.txt')
    ap.add_argument('--modules', default='eboot,god.self,net.self,enemy.self,libc,libdeflt')
    ap.add_argument('--max-thumb', type=int, default=250); ap.add_argument('--max-size', type=int, default=700)
    ap.add_argument('--states', type=int, default=24)
    a = ap.parse_args()
    funcs = gather(a.app, a.patch, a.modules.split(','), a.max_thumb, a.max_size)
    body = ['#include "vita_ops.h"', 'uint32_t MOD_B;', 'uint32_t MOD_SEG[4];']
    tests = []; skipped_calls = 0
    for rel, m, code, rl, s, e, mode in funcs:
        lf = lift.Lifter(code.ph['vaddr'], m.read, relocs=rl if mode == 'thumb' else {}, arm=(mode == 'arm'))
        i = len(tests)
        text = lf.lift_function(s, e, f"f{i}", storage='static ')
        if 'vrt_call(' in text or 'vrt_fatal(' in text:
            skipped_calls += 1; continue
        body.append(text); body.append(f"void T{i}(vrt_ctx *x) {{ f{i}(x); }}")
        tests.append((rel, m, code, s, e, mode))
    print(f"{len(funcs)} functions picked, {skipped_calls} skipped (calls/unsupported), {len(tests)} to run", flush=True)
    if not tests:
        open(a.out, 'w').write("no testable functions\n"); return
    d = tempfile.mkdtemp(); cpath, so = os.path.join(d, 't.c'), os.path.join(d, 't.so')
    open(cpath, 'w').write("\n".join(body))
    srcs = [os.path.join(SRC, f) for f in os.listdir(SRC) if f.endswith('.c')]
    r = subprocess.run(['gcc', '-shared', '-fPIC', '-O1', '-w', '-ffp-contract=off', '-I', INC, *srcs, HAR, cpath, '-o', so, '-lpthread', '-lm'], capture_output=True, text=True)
    if r.returncode:
        print(r.stderr[:3000]); sys.exit('generated C failed to compile')
    from unicorn import Uc, UcError, UC_ARCH_ARM, UC_MODE_ARM, UC_MODE_THUMB
    from unicorn import arm_const as U
    lib = ctypes.CDLL(so)
    lib.vrt_commit.argtypes = [ctypes.c_uint32, ctypes.c_size_t]; lib.vrt_harness_run.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    assert lib.vrt_init(0) == 0 and lib.vrt_commit(DATA, DSIZE) == 0
    mem = ctypes.c_void_p.in_dll(lib, 'vrt_mem').value
    mod_b = ctypes.c_uint32.in_dll(lib, 'MOD_B'); mod_seg = (ctypes.c_uint32 * 4).in_dll(lib, 'MOD_SEG')
    rng = random.Random(23); lines = []; tot = bad = fully_skipped = 0
    order = sorted(range(len(tests)), key=lambda i: tests[i][0])
    cur = None; mu = {}
    for i in order:
        rel, m, code, s, e, mode = tests[i]
        if cur != rel:                                              # (re)load this module's segments into both worlds
            cur = rel; segs = []
            for sg in m.loads:
                b = sg.ph['vaddr'] & ~0xfff; sz = ((sg.ph['vaddr'] + sg.ph['memsz'] - b) + 0xfff) & ~0xfff
                img = bytearray(sz); img[sg.ph['vaddr'] - b: sg.ph['vaddr'] - b + len(sg.data)] = sg.data
                assert lib.vrt_commit(b, sz) == 0; ctypes.memmove(mem + b, bytes(img), sz); segs.append((b, bytes(img)))
            for k, sg in enumerate(m.loads[:4]): mod_seg[k] = sg.ph['vaddr']
            mod_b.value = code.ph['vaddr']; saved = [bytes(ctypes.string_at(mem + b, len(img))) for b, img in segs]
        thumb = mode == 'thumb'
        ok = fail = skip = 0; ex = []
        u = Uc(UC_ARCH_ARM, UC_MODE_THUMB if thumb else UC_MODE_ARM)
        for b, img in segs: u.mem_map(b, len(img)); u.mem_write(b, img)
        u.mem_map(DATA, DSIZE)
        fn = ctypes.cast(getattr(lib, f"T{i}"), ctypes.c_void_p)
        for _ in range(a.states):
            regs = []
            for k in range(13):
                regs.append(DATA + 0x2000 + rng.randrange(0, 0x2000) * 4 if (k < 4 and rng.random() < 0.45) else rand_val(rng))
            sp = DATA + 0x8000 + rng.randrange(0, 0x400) * 4
            data = bytes(rng.getrandbits(8) for _ in range(DSIZE)); fl = rng.getrandbits(4)
            u.mem_write(DATA, data)
            for b, img in segs: u.mem_write(b, img)
            u.reg_write(U.UC_ARM_REG_CPSR, (0x30 if thumb else 0x10) | (fl << 28))
            for k in range(13): u.reg_write(getattr(U, f'UC_ARM_REG_R{k}'), regs[k])
            u.reg_write(U.UC_ARM_REG_SP, sp); u.reg_write(U.UC_ARM_REG_LR, SENT | (1 if thumb else 0))
            try:
                u.emu_start(s | (1 if thumb else 0), SENT, count=200000)
                if (u.reg_read(U.UC_ARM_REG_PC) & ~1) != SENT:
                    skip += 1; continue
            except UcError:
                skip += 1; continue
            exp = [u.reg_read(getattr(U, f'UC_ARM_REG_R{k}')) for k in range(13)] + [u.reg_read(U.UC_ARM_REG_SP)]
            exp_mem = bytes(u.mem_read(DATA, DSIZE)); exp_seg = [bytes(u.mem_read(b, len(img))) for b, img in segs]
            ctypes.memmove(mem + DATA, data, DSIZE)
            for (b, img), sv in zip(segs, saved): ctypes.memmove(mem + b, img, len(img))
            c = Ctx()
            for k in range(13): c.r[k] = regs[k]
            c.r[13] = sp; c.r[14] = SENT | (1 if thumb else 0)
            c.n, c.z, c.c, c.v = (fl >> 3) & 1, (fl >> 2) & 1, (fl >> 1) & 1, fl & 1
            rc = lib.vrt_harness_run(fn, ctypes.byref(c))
            got = [c.r[k] for k in range(14)]
            got_mem = ctypes.string_at(mem + DATA, DSIZE); got_seg = [ctypes.string_at(mem + b, len(img)) for b, img in segs]
            tot += 1
            if rc == 0 and got == exp and got_mem == exp_mem and got_seg == exp_seg:
                ok += 1
            else:
                fail += 1; bad += 1
                if len(ex) < 2:
                    diffs = [f"r{k}: want {exp[k]:#x} got {got[k]:#x}" for k in range(14) if exp[k] != got[k]][:4]
                    if exp_mem != got_mem: diffs.append("stack/data area differs")
                    if exp_seg != got_seg: diffs.append("module data segment differs")
                    ex.append(f"    in r0={regs[0]:#x} r1={regs[1]:#x} r2={regs[2]:#x} r3={regs[3]:#x} -> " + ("C crashed/aborted" if rc else "; ".join(diffs)))
        if ok == 0 and fail == 0: fully_skipped += 1
        if fail or ok == 0:
            lines.append(f"{mode:5} {rel:34} +0x{(s & ~1) - code.ph['vaddr']:06x} size={e - (s & ~1):5} ok={ok:3} FAIL={fail:3} skipped={skip:3}")
            lines += ex
        for gp in range(0): pass
        u = None
    lines.insert(0, f"TOTAL {tot - bad}/{tot} state runs passed over {len(tests) - fully_skipped} functions that ran ({fully_skipped} functions: every state skipped; {skipped_calls} not testable: calls/unsupported)")
    open(a.out, 'w').write("\n".join(lines) + "\n")
    print("\n".join(lines[:80]))


if __name__ == '__main__':
    main()
