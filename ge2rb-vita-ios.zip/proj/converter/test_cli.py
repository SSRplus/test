import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import test_lift_mock            # installs the fake capstone
import lift

def test_workflow_command_lines_parse():
    P = lift.build_parser()
    P.parse_args(['coverage', '--app', 'game/app', '--patch', 'game/patch', '--jobs', '4'])
    P.parse_args(['module', '--app', 'a', '--patch', 'p', '--module', 'god_m000_Boot', '--out', 'out/gen'])
    a = P.parse_args(['all', '--app', 'a', '--patch', 'p', '--out', 'out/genall', '--jobs', '4'])
    assert a.out == 'out/genall' and a.jobs == 4

if __name__ == '__main__':
    test_workflow_command_lines_parse(); print('cli ok')
