#!/usr/bin/env python3
"""Stage 3b analysis: resolve every import (lib_nid, nid) of every module against the exports of the other modules.
usage: link_check.py --app A [--patch P] [--out out/link.json]"""
import argparse, collections, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vita_self import VitaModule
from prep import collect

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--app', required=True); ap.add_argument('--patch'); ap.add_argument('--out')
    a = ap.parse_args()
    compute(a.app, a.patch, a.out, verbose=True)

def compute(app, patch, out=None, verbose=False):
    class a: pass
    a.app, a.patch, a.out = app, patch, out
    files = collect(a.app, 'app')
    if a.patch:
        files.update(collect(a.patch, 'patch'))
    mods = {rel: VitaModule(p) for rel, (p, _) in sorted(files.items())}
    provider = {}                                  # (lib_nid, nid) -> (module rel, addr, kind)
    dup = collections.Counter()
    for rel, m in mods.items():
        for lib in m.exports():
            for kind, lst in (('func', lib['funcs']), ('var', lib['vars'])):
                for nid, addr in lst:
                    k = (lib['lib_nid'], nid)
                    if k in provider and provider[k][0] != rel:
                        dup[(lib['lib'], hex(nid))] += 1
                    provider.setdefault(k, (rel, addr, kind))
    stats = collections.Counter(); unresolved = collections.defaultdict(set); deps = collections.defaultdict(set)
    sys_libs = collections.defaultdict(lambda: [set(), set()])      # lib -> [func nids, var nids]
    export_libs = {lib['lib_nid'] for m in mods.values() for lib in m.exports()}
    for rel, m in mods.items():
        for imp in m.imports():
            for kind, lst in (('func', imp['funcs']), ('var', imp['vars'])):
                for nid, stub in lst:
                    hit = provider.get((imp['lib_nid'], nid))
                    if hit:
                        stats[('game', kind)] += 1; deps[rel].add(hit[0])
                        if hit[2] != kind: stats['kind-mismatch'] += 1
                    elif imp['lib_nid'] in export_libs:
                        stats[('MISSING-in-game-lib', kind)] += 1; unresolved[imp['lib']].add(hex(nid))
                    else:
                        stats[('system', kind)] += 1; sys_libs[imp['lib']][0 if kind == 'func' else 1].add(nid)
    res = dict(modules=len(mods), game_func=stats[('game', 'func')], game_var=stats[('game', 'var')], system_func=stats[('system', 'func')],
               system_var=stats[('system', 'var')], missing=sum(v for k, v in stats.items() if isinstance(k, tuple) and k[0] == 'MISSING-in-game-lib'),
               exports=len(provider) + sum(dup.values()), unique_system_funcs=sum(len(v[0]) for v in sys_libs.values()))
    if not verbose:
        return res
    print(f"modules {len(mods)}, exported symbols {len(provider)}, duplicate exports across modules {sum(dup.values())}")
    for k, v in sorted(stats.items(), key=str): print(f"  {str(k):34} {v}")
    print("system libs (unique func NIDs, var NIDs):", sum(len(v[0]) for v in sys_libs.values()), sum(len(v[1]) for v in sys_libs.values()))
    vars_ = {l: len(v[1]) for l, v in sys_libs.items() if v[1]}
    print("system libs that import VARIABLES:", vars_)
    if unresolved:
        print("UNRESOLVED imports of game libs:", {k: sorted(v)[:5] for k, v in unresolved.items()})
    if dup:
        print("duplicate exports:", list(dup.items())[:8])
    print("module dependency counts (top 6):", sorted(((len(v), k) for k, v in deps.items()), reverse=True)[:6])
    if a.out:
        json.dump(dict(deps={k: sorted(v) for k, v in deps.items()}), open(a.out, 'w'), indent=1)
    return res

if __name__ == '__main__':
    main()
