#!/usr/bin/env python3
"""hle_worklist.json -> nid_names.c  (so unimplemented system calls are reported by NAME at run time)"""
import json, sys
h = json.load(open(sys.argv[1])); out = sys.argv[2]
rows = []
for lib, lst in h.items():
    for x in lst:
        nid, name = x.split(' ', 1)
        rows.append((int(nid, 16), name if name != '?' else 'unknown'))
extra = {}
if len(sys.argv) > 3:
    extra = {int(k, 16): v for k, v in json.load(open(sys.argv[3])).items()}
have = {n for n, _ in rows}
rows += [(n, nm) for n, nm in extra.items() if n not in have]
rows = sorted(set(rows))
with open(out, 'w') as f:
    f.write('#include <stdint.h>\ntypedef struct { uint32_t nid; const char *name; } vrt_nid_name_rec;\n')
    f.write('static const vrt_nid_name_rec tbl[] = {\n' + ''.join(f'  {{0x{n:08x}, "{nm}"}},\n' for n, nm in rows) + '};\n')
    f.write(f'const vrt_nid_name_rec *vrt_nid_names_get(int *n) {{ *n = {len(rows)}; return tbl; }}\n')
import os
hdr = os.path.join(os.path.dirname(os.path.abspath(out)), 'nid_defs.h')
seen = {}
with open(hdr, 'w') as f:
    f.write('/* generated from hle_worklist.json (names come from vita-headers) */\n')
    for n, nm in rows:
        if nm != 'unknown' and nm not in seen and nm.replace('_', 'a').isalnum():
            seen[nm] = n
            f.write(f'#define NID_{nm} 0x{n:08x}u\n')
print(f"{len(rows)} NID names -> {out}, {len(seen)} NID_ defines -> {hdr}")
