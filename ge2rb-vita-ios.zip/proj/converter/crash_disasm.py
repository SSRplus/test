#!/usr/bin/env python3
"""Disassemble the functions named in a runner crash backtrace.
usage: crash_disasm.py BOOT_RUN.txt APPDIR PATCHDIR > crash_disasm.txt     (needs Capstone)
reads lines like:  [bt] #3 sce_module/libc.suprx+0x1a2c4"""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB
from vita_self import VitaModule
from prep import collect
import lift

def main():
    log, app, patch = sys.argv[1:4]
    files = collect(app, 'app'); files.update(collect(patch, 'patch'))
    seen = set(); md = Cs(CS_ARCH_ARM, CS_MODE_THUMB)
    req = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'disasm_request.txt')      # functions I want to read: "module+0xOFFSET"
    extra = [f"[call] #R {l.strip()}" for l in open(req) if re.match(r'\s*\S+\+0x[0-9a-f]+', l)] if os.path.exists(req) else []
    for line in list(open(log)) + extra:
        m = re.match(r'\[(?:bt|call)\] #(\d+) (\S+)\+0x([0-9a-f]+)', line)
        if not m or (m.group(2), m.group(3)) in seen:
            continue
        seen.add((m.group(2), m.group(3)))
        rel, off = m.group(2), int(m.group(3), 16)
        if rel not in files:
            continue
        mod = VitaModule(files[rel][0]); code, fns = lift._functions(mod)
        addr = code.ph['vaddr'] + off
        hit = [(s, e) for s, e in fns if (s & ~1) <= addr < e]
        print(f"=== #{m.group(1)} {rel}+0x{off:x}  (link address 0x{addr:08x})")
        if not hit:
            print("    (not inside a known thumb function)"); continue
        s, e = hit[0]; lo = s & ~1
        print(f"    function 0x{lo:08x} .. 0x{e:08x}")
        for ins in md.disasm(mod.read(lo, e - lo), lo):
            print(f"    {ins.address:08x}: {ins.mnemonic:10} {ins.op_str}")

if __name__ == '__main__':
    main()
