#!/usr/bin/env python3
"""Cross-check the C loader (runtime/test/test_loader) against the Python reference relocator.
usage: check_loader.py LOADER_OUTPUT.txt GAMEDIR   (GAMEDIR holds eboot.bin and bin/*.self)"""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vita_self import VitaModule
from relocs import apply_relocs

def fnv(b):
    h = 1469598103934665603
    for c in b:
        h = ((h ^ c) * 1099511628211) & 0xffffffffffffffff
    return h

def main():
    out, root = sys.argv[1], sys.argv[2]
    ok = bad = 0
    for line in open(out):
        if line.startswith('FAIL'):
            print(line.strip()); bad += 1; continue
        if not line.startswith('MOD'):
            continue
        t = line.split()
        rel, nseg, relocs = t[1], int(t[2].split('=')[1]), int(t[3].split('=')[1])
        kv = dict(x.split('=') for x in t[4:])
        bases = [int(kv[f'b{i}'], 16) for i in range(nseg)]
        m = VitaModule(os.path.join(root, rel))
        img, n = apply_relocs(m, bases)
        good = (n == relocs)
        for i in range(nseg):
            good &= (fnv(img[i]) == int(kv[f'h{i}'], 16)) and (len(img[i]) == int(kv[f'm{i}'], 16))
        if good: ok += 1
        else:
            bad += 1; print(f"MISMATCH {rel}: python relocs={n} c relocs={relocs}")
    print(f"loader cross-check: {ok} modules identical (C loader == Python reference), {bad} mismatches")
    sys.exit(1 if bad else 0)

if __name__ == '__main__':
    main()
