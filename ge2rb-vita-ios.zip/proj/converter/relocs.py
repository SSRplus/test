import struct
def parse_relocs(m):
    """yield dicts: sym, code, datseg, offset, addend  (long entries may carry a paired code2/dist2)"""
    for s in m.segs:
        if s.ph['type'] != 0x60000000: continue
        d = s.data; o = 0
        while o < len(d):
            w0 = struct.unpack('<I', d[o:o+4])[0]
            if w0 & 0xf == 0:
                w1, w2 = struct.unpack('<II', d[o+4:o+12]); o += 12
                yield dict(fmt=0, sym=(w0>>4)&0xf, code=(w0>>8)&0xff, datseg=(w0>>16)&0xf, code2=(w0>>20)&0xff, dist2=(w0>>28)&0xf, addend=w1, offset=w2)
            else:
                w1 = struct.unpack('<I', d[o+4:o+8])[0]; o += 8
                yield dict(fmt=1, sym=(w0>>4)&0xf, code=(w0>>8)&0xff, datseg=(w0>>16)&0xf, offset=(w0>>20)|((w1&0x3ff)<<12), addend=w1>>10, code2=0, dist2=0)
def imm16_thumb(hw1, hw2):
    return ((hw1 & 0xf) << 12) | (((hw1 >> 10) & 1) << 11) | (((hw2 >> 12) & 7) << 8) | (hw2 & 0xff)

# ---------------------------------------------------------------------------------------------
# Relocation format of PS Vita SELF modules (decoded and verified against 610k entries of the game):
#   segments of type 0x60000000 hold entries. first nibble = format.
#   format 0 (LONG, 12 bytes): w0 = fmt:4 sym:4 code:8 datseg:4 code2:8 dist2:4 | w1 = addend | w2 = offset
#   format 1 (SHORT, 8 bytes): w0 = fmt:4 sym:4 code:8 datseg:4 offset_lo:12 | w1 = offset_hi:10 addend:22(<<10)
#   codes seen: 2 = ABS32, 47 = THM_MOVW_ABS_NC, 48 = THM_MOVT_ABS. value = base[sym] + addend (addend is link-relative)
#   a LONG entry may carry a second relocation (code2) at offset + dist2*2 with the same sym/addend.
# ---------------------------------------------------------------------------------------------
def text_movwt_relocs(m):
    """{text_offset: (code, sym, addend)} for MOVW/MOVT instructions in segment 0 that the loader patches."""
    out = {}
    for e in parse_relocs(m):
        if e['datseg'] != 0:
            continue
        if e['code'] in (47, 48):
            out[e['offset']] = (e['code'], e['sym'], e['addend'])
        if e['fmt'] == 0 and e['code2'] in (47, 48):
            out[e['offset'] + e['dist2'] * 2] = (e['code2'], e['sym'], e['addend'])
    return out

def _patch_thumb_imm16(buf, off, imm):
    hw1, hw2 = struct.unpack_from('<HH', buf, off)
    hw1 = (hw1 & 0xFBF0) | ((imm >> 12) & 0xf) | (((imm >> 11) & 1) << 10)
    hw2 = (hw2 & 0x8F00) | (((imm >> 8) & 7) << 12) | (imm & 0xff)
    struct.pack_into('<HH', buf, off, hw1, hw2)

def apply_relocs(m, bases):
    """Reference implementation: returns {seg: bytearray(memsz)} after relocation with the given runtime bases."""
    img = {s.idx: bytearray(s.data) + bytearray(s.ph['memsz'] - len(s.data)) for s in m.loads}
    n = 0
    for e in parse_relocs(m):
        sv = (bases[e['sym']] if e['sym'] != 15 else 0) + e['addend']
        sv &= 0xffffffff
        for code, off in ((e['code'], e['offset']), (e['code2'], e['offset'] + e['dist2'] * 2)):
            if not code:
                continue
            b = img[e['datseg']]
            if code == 2:
                struct.pack_into('<I', b, off, sv)
            elif code == 47:
                _patch_thumb_imm16(b, off, sv & 0xffff)
            elif code == 48:
                _patch_thumb_imm16(b, off, (sv >> 16) & 0xffff)
            else:
                raise ValueError(f'reloc code {code}')
            n += 1
    return img, n
