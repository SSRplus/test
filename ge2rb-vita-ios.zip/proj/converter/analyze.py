#!/usr/bin/env python3
"""Stage 2a: how big is the lifting job? Function counts + instruction histogram per mode.

usage: analyze.py --app DIR [--patch DIR] --out DIR [--no-disasm]
Needs `pip install capstone` unless --no-disasm.
"""
import argparse, collections, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vita_self import VitaModule
from prep import collect

def families(mn):
    b = mn.split('.')[0]
    f = []
    if b.startswith('v'): f.append('vfp_neon')
    if re.match(r'^(ldrex|strex|ldaex|stlex|clrex)', b): f.append('exclusive')
    if b in ('svc', 'swi', 'udf', 'bkpt'): f.append('system')
    if re.match(r'^(mrc|mcr|mrrc|mcrr|cdp|ldc|stc)', b): f.append('coproc')
    if b in ('tbb', 'tbh'): f.append('jumptable')
    if re.match(r'^(bx|blx)', b) and not b.endswith('lx') or b.startswith('blx'): f.append('branch_reg_or_blx')
    return f

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--app', required=True); ap.add_argument('--patch')
    ap.add_argument('--out', required=True); ap.add_argument('--no-disasm', action='store_true')
    a = ap.parse_args()
    files = collect(a.app, 'app')
    if a.patch: files.update(collect(a.patch, 'patch'))
    cs = None
    if not a.no_disasm:
        import capstone as cs
        md = {True: cs.Cs(cs.CS_ARCH_ARM, cs.CS_MODE_THUMB), False: cs.Cs(cs.CS_ARCH_ARM, cs.CS_MODE_ARM)}
        for m_ in md.values(): m_.skipdata = True; m_.detail = False

    hist = {'thumb': collections.Counter(), 'arm': collections.Counter()}
    fam = collections.Counter(); undecoded = collections.Counter()
    per_mod = {}; tot_f = tot_t = tot_a = tot_bytes = 0
    for rel, (p, tag) in sorted(files.items()):
        m = VitaModule(p)
        starts = m.function_starts()
        code = next(s for s in m.loads if s.ph['flags'] & 1)
        cb = code.ph['vaddr']; ce = cb + len(code.data)
        nt = sum(1 for s in starts if s & 1); na = len(starts) - nt
        per_mod[rel] = dict(functions=len(starts), thumb=nt, arm=na, code_bytes=len(code.data))
        tot_f += len(starts); tot_t += nt; tot_a += na; tot_bytes += len(code.data)
        if a.no_disasm: continue
        bounds = [s & ~1 for s in starts] + [ce]
        for i, s in enumerate(starts):
            lo, hi = s & ~1, min(bounds[i + 1], ce)
            if not (cb <= lo < ce) or hi <= lo: continue
            thumb = bool(s & 1); key = 'thumb' if thumb else 'arm'
            for ins in md[thumb].disasm(code.data[lo - cb:hi - cb], lo):
                if ins.mnemonic == '.byte' or ins.mnemonic == '.word':
                    undecoded[key] += 1; continue          # literal pools / data / undefined
                hist[key][ins.mnemonic] += 1
                for f in families(ins.mnemonic): fam[(key, f)] += 1

    os.makedirs(a.out, exist_ok=True)
    rep = [f"modules {len(per_mod)}  functions {tot_f} (thumb {tot_t}, arm {tot_a})  code {tot_bytes/1e6:.1f} MB"]
    if not a.no_disasm:
        for key in ('thumb', 'arm'):
            tot = sum(hist[key].values())
            rep.append(f"\\n== {key}: {tot} instructions, {len(hist[key])} distinct mnemonics, skipped(data/undecoded) {undecoded[key]}")
            rep.append("top 60: " + ", ".join(f"{k}:{v}" for k, v in hist[key].most_common(60)))
        rep.append("\\n== families (mode, family): " + ", ".join(f"{k[0]}/{k[1]}={v}" for k, v in sorted(fam.items())))
        json.dump({k: dict(v) for k, v in hist.items()}, open(os.path.join(a.out, 'insn_hist.json'), 'w'), indent=1)
    json.dump(per_mod, open(os.path.join(a.out, 'functions.json'), 'w'), indent=1)
    open(os.path.join(a.out, 'ANALYSIS.txt'), 'w').write("\n".join(rep) + "\n")
    print("\n".join(rep))

if __name__ == '__main__':
    main()
