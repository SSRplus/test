import SwiftUI
import UIKit

// MARK: - on-screen buttons

struct HoldButton: View {
    let label: String
    let bit: UInt32
    var w: CGFloat = 58
    var h: CGFloat = 58
    @State private var down = false

    var body: some View {
        Text(label).font(.system(size: 20, weight: .semibold))
            .frame(width: w, height: h)
            .background(RoundedRectangle(cornerRadius: min(w, h) / 2).fill(Color.white.opacity(down ? 0.55 : 0.18)))
            .overlay(RoundedRectangle(cornerRadius: min(w, h) / 2).stroke(Color.white.opacity(0.6)))
            .foregroundColor(.white)
            .contentShape(Rectangle())
            .onLongPressGesture(minimumDuration: .infinity, maximumDistance: .infinity, pressing: { p in
                down = p
                InputHub.shared.setTouch(bit: bit, down: p)
            }, perform: {})
    }
}

struct StickPad: View {
    let left: Bool
    private let radius: CGFloat = 62
    @State private var offset: CGSize = .zero

    var body: some View {
        ZStack {
            Circle().fill(Color.white.opacity(0.12))
            Circle().stroke(Color.white.opacity(0.5))
            Circle().fill(Color.white.opacity(0.45)).frame(width: 54, height: 54).offset(offset)
        }
        .frame(width: radius * 2, height: radius * 2)
        .contentShape(Circle())
        .gesture(DragGesture(minimumDistance: 0)
            .onChanged { v in
                let dx = v.location.x - radius, dy = v.location.y - radius
                let d = hypot(dx, dy), k = d > radius ? radius / d : 1
                offset = CGSize(width: dx * k, height: dy * k)
                InputHub.shared.setTouchStick(left: left, x: Double(dx * k / radius), y: Double(dy * k / radius))
            }
            .onEnded { _ in
                offset = .zero
                InputHub.shared.setTouchStick(left: left, x: 0, y: 0)
            })
    }
}

struct TouchControlsOverlay: View {
    var body: some View {
        VStack {
            HStack {
                HoldButton(label: "L", bit: UInt32(VRT_L1), w: 96, h: 40)
                Spacer()
                HoldButton(label: "R", bit: UInt32(VRT_R1), w: 96, h: 40)
            }
            Spacer()
            HStack(alignment: .bottom) {
                VStack(spacing: 14) {
                    dpad
                    StickPad(left: true)
                }
                Spacer()
                VStack(spacing: 8) {
                    HStack(spacing: 10) {
                        HoldButton(label: "SELECT", bit: UInt32(VRT_SELECT), w: 82, h: 34)
                        HoldButton(label: "START", bit: UInt32(VRT_START), w: 82, h: 34)
                    }
                }
                Spacer()
                VStack(spacing: 14) {
                    face
                    StickPad(left: false)
                }
            }
        }
        .padding(14)
    }

    private var dpad: some View {
        VStack(spacing: 2) {
            HoldButton(label: "▲", bit: UInt32(VRT_UP), w: 50, h: 50)
            HStack(spacing: 50) {
                HoldButton(label: "◀", bit: UInt32(VRT_LEFT), w: 50, h: 50)
                HoldButton(label: "▶", bit: UInt32(VRT_RIGHT), w: 50, h: 50)
            }
            HoldButton(label: "▼", bit: UInt32(VRT_DOWN), w: 50, h: 50)
        }
    }

    private var face: some View {
        VStack(spacing: 2) {
            HoldButton(label: "△", bit: UInt32(VRT_TRIANGLE), w: 50, h: 50)
            HStack(spacing: 50) {
                HoldButton(label: "□", bit: UInt32(VRT_SQUARE), w: 50, h: 50)
                HoldButton(label: "○", bit: UInt32(VRT_CIRCLE), w: 50, h: 50)
            }
            HoldButton(label: "✕", bit: UInt32(VRT_CROSS), w: 50, h: 50)
        }
    }
}

// MARK: - front touch surface (maps to the Vita's 960x544 touch space)

final class TouchView: UIView {
    private var ids: [UITouch: Int] = [:]

    override init(frame: CGRect) {
        super.init(frame: frame)
        isMultipleTouchEnabled = true
        backgroundColor = .clear
    }
    required init?(coder: NSCoder) { fatalError() }

    private func vita(_ t: UITouch) -> (UInt16, UInt16) {
        let p = t.location(in: self)
        let x = max(0, min(959, p.x / max(bounds.width, 1) * 960))
        let y = max(0, min(543, p.y / max(bounds.height, 1) * 544))
        return (UInt16(x), UInt16(y))
    }
    private func freeID() -> Int {
        let used = Set(ids.values)
        return (0..<Int(VRT_MAX_TOUCH)).first { !used.contains($0) } ?? 0
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let id = freeID(); ids[t] = id
            let (x, y) = vita(t); vrt_input_touch(0, Int32(id), 1, x, y)
        }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { if let id = ids[t] { let (x, y) = vita(t); vrt_input_touch(0, Int32(id), 1, x, y) } }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { release(touches) }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { release(touches) }
    private func release(_ touches: Set<UITouch>) {
        for t in touches { if let id = ids.removeValue(forKey: t) { vrt_input_touch(0, Int32(id), 0, 0, 0) } }
    }
}

struct TouchSurface: UIViewRepresentable {
    func makeUIView(context: Context) -> TouchView { TouchView() }
    func updateUIView(_ uiView: TouchView, context: Context) {}
}

// MARK: - test screen

struct ControlsTestView: View {
    @Environment(\.presentationMode) private var presentation

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            TouchSurface().ignoresSafeArea()
            TouchControlsOverlay()
            VStack {
                HStack {
                    Button("Close") { presentation.wrappedValue.dismiss() }
                        .padding(8).background(Color.white.opacity(0.2)).cornerRadius(8).foregroundColor(.white)
                    Spacer()
                }
                TimelineView(.periodic(from: Date(), by: 0.1)) { _ in
                    Text(readout()).font(.system(.footnote, design: .monospaced)).foregroundColor(.green)
                }
                Spacer()
            }.padding(14)
        }
        .statusBarHidden(true)
    }

    private func readout() -> String {
        var st = [UInt8](repeating: 0, count: 4)
        vrt_input_get_sticks(&st)
        var ids = [UInt8](repeating: 0, count: 6), xs = [UInt16](repeating: 0, count: 6), ys = [UInt16](repeating: 0, count: 6)
        let n = Int(vrt_input_get_touches(0, &ids, &xs, &ys, 6))
        let t = (0..<n).map { "#\(ids[$0])(\(xs[$0]),\(ys[$0]))" }.joined(separator: " ")
        return String(format: "buttons 0x%05X  L(%3d,%3d) R(%3d,%3d)  touch[%d] %@",
                      vrt_input_get_buttons(), st[0], st[1], st[2], st[3], n, t)
    }
}
