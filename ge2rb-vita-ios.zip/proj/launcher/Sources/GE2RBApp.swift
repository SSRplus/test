import SwiftUI

@main
struct GE2RBApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
