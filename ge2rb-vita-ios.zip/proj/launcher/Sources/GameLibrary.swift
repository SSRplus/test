import Foundation
import UIKit
import CryptoKit
import ZIPFoundation

struct Check: Identifiable {
    let id = UUID()
    let title: String
    let ok: Bool
    let detail: String
}

enum ImportError: LocalizedError {
    case noGame, cancelled
    case noSpace(need: Int64, have: Int64)
    var errorDescription: String? {
        switch self {
        case .noGame: return "No \(GameLibrary.titleID) files found in this zip. Expected app/\(GameLibrary.titleID) (and patch/\(GameLibrary.titleID))."
        case .cancelled: return "Import cancelled."
        case .noSpace(let need, let have):
            let f = ByteCountFormatter()
            return "Not enough free space: need \(f.string(fromByteCount: need)), have \(f.string(fromByteCount: have))."
        }
    }
}

final class CancelFlag: @unchecked Sendable {
    private let lock = NSLock(); private var v = false
    var value: Bool { get { lock.lock(); defer { lock.unlock() }; return v }
                      set { lock.lock(); v = newValue; lock.unlock() } }
}

/// Extracts the user's own game zip into the app sandbox (Documents/Game/{app,patch}/PCSE00789).
enum GameImporter {
    /// Map a zip path to a canonical path, or nil to skip. Accepts wrapper folders, `ux0/app/...`, or a bare `PCSE00789/...`.
    static func map(_ path: String, title: String) -> [String]? {
        let comps = path.split(separator: "/").map(String.init).filter { $0 != "." && $0 != ".." && !$0.isEmpty }
        if comps.count >= 2 {
            for i in 0..<(comps.count - 1) where (comps[i] == "app" || comps[i] == "patch") && comps[i + 1] == title {
                return Array(comps[i...])
            }
        }
        if let i = comps.firstIndex(of: title) { return ["app"] + Array(comps[i...]) }
        return nil
    }

    static func extract(zip: URL, to destination: URL, cancel: CancelFlag,
                        progress: @escaping (Double, String) -> Void) throws -> Int {
        let archive = try Archive(url: zip, accessMode: .read)
        var entries: [(Entry, [String])] = []
        var total: Int64 = 0
        for e in archive where e.type == .file {
            if let m = map(e.path, title: GameLibrary.titleID) {
                entries.append((e, m)); total += Int64(e.uncompressedSize)
            }
        }
        guard !entries.isEmpty else { throw ImportError.noGame }

        let fm = FileManager.default
        let parent = destination.deletingLastPathComponent()
        let free = (try? parent.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]))?
            .volumeAvailableCapacityForImportantUsage ?? 0
        if free < total + 200_000_000 { throw ImportError.noSpace(need: total + 200_000_000, have: free) }

        try? fm.removeItem(at: destination)                      // replaces a previous install
        try fm.createDirectory(at: destination, withIntermediateDirectories: true)
        var dest = destination
        var rv = URLResourceValues(); rv.isExcludedFromBackup = true
        try? dest.setResourceValues(rv)                          // don't back 3.8 GB up to iCloud

        var done: Int64 = 0
        for (e, comps) in entries {
            if cancel.value { try? fm.removeItem(at: destination); throw ImportError.cancelled }
            let out = comps.reduce(destination) { $0.appendingPathComponent($1) }
            try fm.createDirectory(at: out.deletingLastPathComponent(), withIntermediateDirectories: true)
            _ = try archive.extract(e, to: out, bufferSize: 1 << 20)
            done += Int64(e.uncompressedSize)
            progress(Double(done) / Double(max(total, 1)), comps.joined(separator: "/"))
        }
        return entries.count
    }
}

@MainActor
final class GameLibrary: ObservableObject {
    nonisolated static let titleID = "PCSE00789"

    @Published var installed = false
    @Published var checks: [Check] = []
    @Published var importing = false
    @Published var progress = 0.0
    @Published var message = ""
    @Published var rtStatus = "not tested"
    private var cancel = CancelFlag()

    var root: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Game", isDirectory: true)
    }

    init() { refresh() }

    func refresh() {
        installed = FileManager.default.fileExists(atPath: root.path)
        checks = installed ? validate(root: root) : []
    }

    // MARK: import / delete
    func importZip(_ url: URL) {
        guard !importing else { return }
        importing = true; progress = 0; message = "Opening zip…"
        UIApplication.shared.isIdleTimerDisabled = true
        let flag = CancelFlag(); cancel = flag
        let dest = root
        Task {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            do {
                let n = try await Task.detached(priority: .userInitiated) { () throws -> Int in
                    try GameImporter.extract(zip: url, to: dest, cancel: flag) { frac, name in
                        Task { @MainActor in self.progress = frac; self.message = name }
                    }
                }.value
                message = "Imported \(n) files."
            } catch {
                message = error.localizedDescription
            }
            importing = false
            UIApplication.shared.isIdleTimerDisabled = false
            refresh()
        }
    }

    func cancelImport() { cancel.value = true }

    func deleteGame() {
        try? FileManager.default.removeItem(at: root)
        message = "Game data deleted."
        refresh()
    }

    // MARK: validation
    private func validate(root: URL) -> [Check] {
        let fm = FileManager.default
        let app = root.appendingPathComponent("app/\(Self.titleID)")
        let patch = root.appendingPathComponent("patch/\(Self.titleID)")
        func has(_ u: URL) -> Bool { fm.fileExists(atPath: u.path) }
        func count(_ u: URL, ext: String) -> Int {
            ((try? fm.contentsOfDirectory(atPath: u.path)) ?? []).filter { $0.hasSuffix(ext) }.count
        }
        var out: [Check] = []
        out.append(Check(title: "app/\(Self.titleID)", ok: has(app), detail: has(app) ? "found" : "missing"))
        out.append(Check(title: "app/system.res", ok: has(app.appendingPathComponent("system.res")), detail: "base game data"))
        out.append(Check(title: "patch/\(Self.titleID)", ok: has(patch), detail: has(patch) ? "found" : "missing (game needs the update)"))
        for f in ["patch.rdp", "system_update.res", "eboot.bin"] {
            let ok = has(patch.appendingPathComponent(f))
            out.append(Check(title: "patch/\(f)", ok: ok, detail: ok ? "found" : "missing"))
        }
        let nm = count(patch.appendingPathComponent("bin"), ext: ".self")
        out.append(Check(title: "patch/bin modules", ok: nm == 52, detail: "\(nm) of 52 .self files"))
        out.append(contentsOf: verifyBuild(patchEboot: patch.appendingPathComponent("eboot.bin")))
        return out
    }

    /// Compare the imported eboot.bin with the one the converter built the game library from.
    private func verifyBuild(patchEboot: URL) -> [Check] {
        guard let mURL = Bundle.main.url(forResource: "manifest", withExtension: "json"),
              let mData = try? Data(contentsOf: mURL),
              let json = try? JSONSerialization.jsonObject(with: mData) as? [String: Any],
              let mods = json["modules"] as? [String: Any],
              let eboot = mods["eboot.bin"] as? [String: Any],
              let want = eboot["sha256"] as? String else {
            return [Check(title: "game library", ok: false, detail: "this build has no converted game code yet")]
        }
        guard let data = try? Data(contentsOf: patchEboot, options: .mappedIfSafe) else {
            return [Check(title: "game version", ok: false, detail: "cannot read patch eboot.bin")]
        }
        let got = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        return [Check(title: "game version", ok: got == want,
                      detail: got == want ? "matches converted build" : "different version than the one converted")]
    }

    // MARK: runtime probe
    func probeRuntime() {
        if vrt_init(0) == 0 {
            let g = vrt_alloc(16 * 1024 * 1024, 4096)
            rtStatus = String(format: "OK: 4 GiB reserved, 16 MiB guest alloc @0x%08x", g)
            vrt_shutdown()
        } else {
            rtStatus = "FAILED: could not reserve 4 GiB address space"
        }
    }
}
