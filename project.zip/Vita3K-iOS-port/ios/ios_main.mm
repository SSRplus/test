// Vita3K iOS frontend.
// Mirrors the Android frontend (vita3k/android/jni/*): same AppSessionController / FrameHost architecture,
// but with a native UIKit launcher + on-screen virtual controller instead of the Java UI.

#define SDL_MAIN_HANDLED
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3/SDL_metal.h>

// Apple's MacTypes.h (pulled in by Foundation/UIKit) has `typedef char *Ptr;`, which clashes with Vita3K's `class Ptr<T>` (mem/ptr.h).
// Rename Apple's typedef while the Apple headers are parsed, then restore the name for Vita3K code.
#define Ptr MacTypesPtr
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#undef Ptr
#include <dlfcn.h>
#include <sys/mman.h>
#include <execinfo.h>
#include <signal.h>
#include <exception>
#include <mach/mach.h>
#include <mach/vm_map.h>
#include <mach/vm_region.h>
#include <mach/vm_statistics.h>
#include <algorithm>
#include <atomic>
#include <deque>
#include <map>
#include <string>
#include <thread>
#import <Metal/Metal.h>
#include <os/proc.h>
#include <fcntl.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#if __has_include(<spdlog/spdlog.h>)
#include <spdlog/spdlog.h>
#define V3K_HAVE_SPDLOG 1
#endif

#include "archive.h"
#include "interface.h"
#include "ios_jit.h"

#include <app/functions.h>
#include <app/session_controller.h>
#include <audio/state.h>
#include <compat/functions.h>
#include <compat/state.h>
#include <config/functions.h>
#include <config/settings.h>
#include <config/version.h>
#include <ctrl/functions.h>
#include <emuenv/state.h>
#include <ime/functions.h>
#include <ime/keyboard.h>
#include <io/state.h>
#include <modules/module_parent.h>
#include <motion/event_handler.h>
#include <motion/functions.h>
#include <packages/functions.h>
#include <packages/license.h>
#include <packages/pkg.h>
#include <renderer/frame_host.h>
#include <renderer/functions.h>
#include <renderer/state.h>
#include <touch/functions.h>
#include <util/fs.h>
#include <util/log.h>
#include <dialog/state.h>
#include <dialog/types.h>
#include <ime/state.h>
#include <ime/text.h>
#include <util/string_utils.h>
#include <cctype>
#include <mutex>
#include <miniz.h>
#include <algorithm>
#include <vector>

#include <algorithm>
#include <atomic>
#include <memory>
#include <optional>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------------------------
// Globals
// ---------------------------------------------------------------------------------------------
static std::unique_ptr<EmuEnvState> g_emuenv;
static std::unique_ptr<app::AppSessionController> g_controller;
static Root g_root;

static NSString *g_launch_title = nil; // set by launcher, consumed by main loop
static bool g_launch_failed = false; // set when a game could not be started, shown to the user after the session ends

// ---------------------------------------------------------------------------------------------
// Diagnostics: a short, line-based, always-flushed trail of what the app is doing.
//   <Files app> > Vita3K > Vita3K > diagnostics.txt        (this run)
//   <Files app> > Vita3K > Vita3K > diagnostics.prev.txt   (previous run, kept so a crash trail survives a restart)
// Unlike Vita3K.log (asynchronous, buffered: its last lines are lost when the app is killed or crashes) every line here is
// written and fsync'ed immediately, so the LAST line shows exactly how far the app got.
// Line format:  [+seconds since start] LEVEL step | message      LEVEL = INFO | OK | WARN | FAIL
// ---------------------------------------------------------------------------------------------
static int g_diag_fd = -1;
static CFAbsoluteTime g_diag_t0 = 0;
static NSString *g_launch_fail_msg = nil; // optional text for the "Could not start game" alert

static void diag_raw(const char *s) {
    if (g_diag_fd >= 0) {
        (void)!write(g_diag_fd, s, strlen(s));
        fsync(g_diag_fd);
    }
}

static void diag(const char *level, const char *step, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
static void diag(const char *level, const char *step, const char *fmt, ...) {
    char msg[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    char line[1280];
    snprintf(line, sizeof(line), "[+%8.3f] %-4s %-20s | %s\n", CFAbsoluteTimeGetCurrent() - g_diag_t0, level, step, msg);
    diag_raw(line);
}


// ---------------------------------------------------------------------------------------------
// Crash report: built at startup from the previous run's trail when it died during a game session
// ---------------------------------------------------------------------------------------------
static NSString *g_crash_path = nil;    // crash_report.txt (non-nil only if the previous run crashed)
static NSString *g_crash_title = nil;   // "PCSE00789  GOD EATER 2 RAGE BURST"
static NSString *g_crash_summary = nil; // last diagnostic line, shown in the alert

static NSString *diag_field(NSString *text, NSString *step, NSString *prefix) {
    // newest match wins: a diagnostics file can hold several launches, the crash belongs to the LAST one
    for (NSString *ln in [[text componentsSeparatedByString:@"\n"] reverseObjectEnumerator]) {
        if ([ln containsString:step]) {
            NSRange r = [ln rangeOfString:prefix];
            if (r.location != NSNotFound) {
                NSString *v = [ln substringFromIndex:NSMaxRange(r)];
                NSRange sp = [v rangeOfString:@" ("];
                if ([prefix isEqual:@"title_id="] || sp.location == NSNotFound) return v;
                return [v substringToIndex:sp.location];
            }
        }
    }
    return nil;
}
static void build_crash_report(NSString *dir, NSString *old, NSString *last) {
    NSString *tid = diag_field(old, @"launch.begin", @"title_id=") ?: @"unknown";
    NSString *name = diag_field(old, @"launch.running", @"game started: ");
    g_crash_title = name ? [NSString stringWithFormat:@"%@  %@", tid, name] : tid;
    g_crash_summary = last;
    NSMutableString *r = [NSMutableString string];
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    NSString *verdict = [old containsString:@"[CRASH] signal="] ? @"EMULATOR CRASH (signal caught, see backtrace in the diagnostics below)"
        : [old containsString:@"terminate"] ? @"EMULATOR CRASH (uncaught C++ exception)"
        : @"KILLED BY iOS with no signal (jetsam / memory or watchdog / user swipe-up) - nothing in the emulator crashed";
    g_crash_summary = [NSString stringWithFormat:@"%@\n%@", verdict, last];
    [r appendFormat:@"Vita3K iOS crash report\nGame: %@\nApp version: %@\nTime: %@\nVerdict: %@\nLast line: %@\n\n", g_crash_title,
        info[@"CFBundleShortVersionString"], [NSDate date], verdict, last];
    [r appendFormat:@"==== diagnostics (crashed run) ====\n%@\n", old];
    // tail of the emulator log (Vita3K.log, written before the crash)
    NSString *logText = nil;
    for (NSString *cand in @[ @"Vita3K.log", @"vita3k.log", @"log/Vita3K.log", @"logs/Vita3K.log" ]) {
        logText = [NSString stringWithContentsOfFile:[dir stringByAppendingPathComponent:cand] encoding:NSUTF8StringEncoding error:nil];
        if (logText.length) break;
    }
    if (logText.length) {
        NSArray *lines = [logText componentsSeparatedByString:@"\n"];
        NSUInteger from = lines.count > 250 ? lines.count - 250 : 0;
        [r appendFormat:@"==== Vita3K.log (last %lu lines) ====\n%@\n", (unsigned long)(lines.count - from),
            [[lines subarrayWithRange:NSMakeRange(from, lines.count - from)] componentsJoinedByString:@"\n"]];
    } else {
        [r appendString:@"==== Vita3K.log not found ====\n"];
    }
    g_crash_path = [dir stringByAppendingPathComponent:@"crash_report.txt"];
    [r writeToFile:g_crash_path atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

static void diag_init(NSString *dir) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *cur = [dir stringByAppendingPathComponent:@"diagnostics.txt"];
    NSString *prev = [dir stringByAppendingPathComponent:@"diagnostics.prev.txt"];
    NSString *old = [NSString stringWithContentsOfFile:cur encoding:NSUTF8StringEncoding error:nil];
    if (old.length) {
        [fm removeItemAtPath:prev error:nil];
        [fm moveItemAtPath:cur toPath:prev error:nil];
    }
    g_diag_t0 = CFAbsoluteTimeGetCurrent();
    g_diag_fd = open(cur.fileSystemRepresentation, O_WRONLY | O_CREAT | O_TRUNC, 0644);

    diag_raw("# Vita3K iOS diagnostics - newest run. Read from the bottom: the LAST line is the last thing that happened.\n"
             "# Format: [+seconds since start] LEVEL step | message      LEVEL = INFO | OK | WARN | FAIL\n"
             "# A game launch is bracketed by 'launch.begin' ... 'launch.end'. If the file stops before 'launch.end', the app was killed or crashed there.\n"
             "# The previous run is in diagnostics.prev.txt. Full emulator log: Vita3K.log (buffered, may miss the last lines after a crash).\n\n");

    struct utsname u;
    uname(&u);
    NSProcessInfo *pi = [NSProcessInfo processInfo];
    NSDictionary *info = [[NSBundle mainBundle] infoDictionary];
    diag("INFO", "device", "model=%s os=iOS %s arch=%s ram=%.1fGB", u.machine, UIDevice.currentDevice.systemVersion.UTF8String, u.machine, pi.physicalMemory / 1073741824.0);
    diag("INFO", "app", "bundle=%s version=%s", [info[@"CFBundleIdentifier"] UTF8String] ?: "?", [info[@"CFBundleShortVersionString"] UTF8String] ?: "?");
    diag("INFO", "paths", "documents=%s", dir.UTF8String);
    diag("INFO", "power", "low_power_mode=%d thermal_state=%ld", (int)pi.lowPowerModeEnabled, (long)pi.thermalState);

    // Did the previous run die while launching / playing a game?
    if (old.length) {
        NSRange b = [old rangeOfString:@"launch.begin" options:NSBackwardsSearch];
        NSRange e = [old rangeOfString:@"launch.end" options:NSBackwardsSearch];
        if (b.location != NSNotFound && (e.location == NSNotFound || e.location < b.location)) {
            NSArray<NSString *> *lines = [old componentsSeparatedByString:@"\n"];
            NSString *last = @"";
            for (NSInteger i = (NSInteger)lines.count - 1; i >= 0; --i)
                if (lines[i].length) { last = lines[i]; break; }
            diag("WARN", "prev_run", "previous run stopped DURING a game launch/session (crash or killed). Its last line was: %s", last.UTF8String);
            build_crash_report(dir, old, last);
            diag("INFO", "prev_run", "crash report saved: crash_report.txt (game %s)", g_crash_title.UTF8String);
        } else {
            diag("INFO", "prev_run", "previous run has no unfinished game launch");
        }
    }
}
static UIWindow *g_launcher_window = nil;

// ---------------------------------------------------------------------------------------------
// Settings (NSUserDefaults, applied to the emulator config at every game launch)
// ---------------------------------------------------------------------------------------------
static bool g_force_vulkan = false; // set when OpenGL ES failed to start -> automatic fallback

static NSString *g_edit_game = nil;   // settings screen editing a game's custom config (nil = global)
static NSString *g_active_game = nil; // game being launched (custom config applies)
static NSDictionary *v3k_defaults() {
    return @{
        @"backend" : @"Vulkan", @"res" : @1.0, @"aniso" : @1, @"filter" : @"Bilinear", @"vsync" : @YES,
        @"shadercache" : @YES, @"asyncpipe" : @NO, @"texcache" : @YES, @"nosurfsync" : @YES, @"spirv" : @NO,
        @"highacc" : @NO, @"fpshack" : @NO, @"accmath" : @YES, @"volume" : @100, @"ngs" : @YES,
        @"overlay" : @NO, @"perflog" : @YES, @"hashless" : @NO, @"mapping" : @"disabled",
        @"modulesmode" : @0, @"cpuopt" : @YES, @"cpupool" : @10, @"showcompile" : @YES, @"importtex" : @NO, @"exporttex" : @NO,
        @"exportpng" : @YES, @"stretch" : @NO, @"pixelperfect" : @NO, @"sysbutton" : @1, @"pstv" : @NO, @"showmode" : @NO,
        @"demomode" : @NO, @"syslang" : @1, @"sysdate" : @2, @"systime" : @0, @"overlaydetail" : @0, @"overlaypos" : @0,
        @"loglevel" : @2, @"logcompat" : @NO, @"archivelog" : @NO, @"screenshot" : @1, @"fileloaddelay" : @0,
        @"jitmain" : @64, @"jitthread" : @16, @"logshaders" : @NO, @"loguniforms" : @NO, @"colordebug" : @NO, @"validation" : @NO,
    };
}
static NSString *gkey(NSString *g, NSString *k) { return [NSString stringWithFormat:@"v3k.g.%@.%@", g, k]; }
static id S(NSString *key) {
    NSString *g = g_edit_game ?: g_active_game;
    if (g) {
        id gv = [NSUserDefaults.standardUserDefaults objectForKey:gkey(g, key)];
        if (gv) return gv;
    }
    id v = [NSUserDefaults.standardUserDefaults objectForKey:[@"v3k." stringByAppendingString:key]];
    return v ?: v3k_defaults()[key];
}
static void S_set(NSString *key, id val) {
    if (g_edit_game) [NSUserDefaults.standardUserDefaults setObject:val forKey:gkey(g_edit_game, key)];
    else [NSUserDefaults.standardUserDefaults setObject:val forKey:[@"v3k." stringByAppendingString:key]];
}
static void S_reset() {
    for (NSString *k in v3k_defaults())
        [NSUserDefaults.standardUserDefaults removeObjectForKey:[@"v3k." stringByAppendingString:k]];
}
static bool game_has_custom(NSString *g) {
    for (NSString *k in v3k_defaults())
        if ([NSUserDefaults.standardUserDefaults objectForKey:gkey(g, k)]) return true;
    return false;
}
static void game_clear_custom(NSString *g) {
    for (NSString *k in v3k_defaults())
        [NSUserDefaults.standardUserDefaults removeObjectForKey:gkey(g, k)];
}
// JIT code cache size per guest thread (MB). Dynarmic reserves 128 MB for EVERY guest thread by default and iOS charges that against the
// jetsam footprint (GOD EATER 2: +116 MB per thread, 15 threads = 1.7 GB). The first JIT created in a session belongs to the main game
// thread and gets its own (bigger) size. Values are cached here at launch so guest threads never touch NSUserDefaults.
static std::atomic<unsigned> g_jit_count{0}, g_jit_main_mb{64}, g_jit_thread_mb{16};
extern "C" unsigned ios_jit_cache_mb(void) {
    return g_jit_count.fetch_add(1) == 0 ? g_jit_main_mb.load() : g_jit_thread_mb.load();
}
static void apply_settings(EmuEnvState &e) {
    auto &c = e.cfg.current_config;
    const bool gl = !g_force_vulkan && [S(@"backend") isEqual:@"OpenGL"];
    e.backend_renderer = gl ? renderer::Backend::OpenGL : renderer::Backend::Vulkan;
    c.backend_renderer = gl ? "OpenGL" : "Vulkan";
    c.resolution_multiplier = [S(@"res") floatValue];
    c.anisotropic_filtering = [S(@"aniso") intValue];
    c.screen_filter = std::string([S(@"filter") UTF8String]);
    c.v_sync = [S(@"vsync") boolValue];
    c.shader_cache = [S(@"shadercache") boolValue];
    c.async_pipeline_compilation = [S(@"asyncpipe") boolValue];
    c.texture_cache = [S(@"texcache") boolValue];
    c.disable_surface_sync = [S(@"nosurfsync") boolValue];
    c.spirv_shader = [S(@"spirv") boolValue];
    c.high_accuracy = [S(@"highacc") boolValue];
    c.fps_hack = [S(@"fpshack") boolValue];
    c.audio_volume = [S(@"volume") intValue];
    c.ngs_enable = [S(@"ngs") boolValue];
    c.memory_mapping = std::string([S(@"mapping") UTF8String]);
    e.cfg.performance_overlay = [S(@"overlay") boolValue];
    c.modules_mode = [S(@"modulesmode") intValue];
    c.cpu_opt = [S(@"cpuopt") boolValue];
    e.cfg.cpu_pool_size = [S(@"cpupool") intValue];
    e.cfg.show_compile_shaders = [S(@"showcompile") boolValue];
    e.cfg.hashless_texture_cache = [S(@"hashless") boolValue];
    c.import_textures = [S(@"importtex") boolValue];
    c.export_textures = [S(@"exporttex") boolValue];
    c.export_as_png = [S(@"exportpng") boolValue];
    c.stretch_the_display_area = [S(@"stretch") boolValue];
    c.fullscreen_hd_res_pixel_perfect = [S(@"pixelperfect") boolValue];
    c.sys_button = [S(@"sysbutton") intValue];
    c.sys_lang = [S(@"syslang") intValue];
    c.sys_date_format = [S(@"sysdate") intValue];
    c.sys_time_format = [S(@"systime") intValue];
    c.pstv_mode = [S(@"pstv") boolValue];
    e.cfg.show_mode = [S(@"showmode") boolValue];
    e.cfg.demo_mode = [S(@"demomode") boolValue];
    e.cfg.performance_overlay_detail = [S(@"overlaydetail") intValue];
    e.cfg.performance_overlay_position = [S(@"overlaypos") intValue];
    e.cfg.screenshot_format = [S(@"screenshot") intValue];
    c.file_loading_delay = [S(@"fileloaddelay") intValue];
    e.cfg.log_level = [S(@"loglevel") intValue];
    e.cfg.log_compat_warn = [S(@"logcompat") boolValue];
    e.cfg.archive_log = [S(@"archivelog") boolValue];
    c.log_active_shaders = [S(@"logshaders") boolValue];
    c.log_uniforms = [S(@"loguniforms") boolValue];
    c.color_surface_debug = [S(@"colordebug") boolValue];
    c.validation_layer = [S(@"validation") boolValue];
#ifdef V3K_HAVE_SPDLOG
    logging::set_level(static_cast<spdlog::level::level_enum>(e.cfg.log_level));
#endif
    diag("INFO", "settings.game", "game=%s custom=%d loglevel=%d cpupool=%d", g_active_game ? g_active_game.UTF8String : "-", (int)(g_active_game && game_has_custom(g_active_game)), e.cfg.log_level, e.cfg.cpu_pool_size);
    g_jit_main_mb = (unsigned)std::clamp([S(@"jitmain") intValue], 8, 128);
    g_jit_thread_mb = (unsigned)std::clamp([S(@"jitthread") intValue], 4, 128);
    g_jit_count = 0; // next JIT created = main thread of this session
    diag("INFO", "jit.cache", "code cache per guest thread: main=%uMB others=%uMB (Dynarmic default is 128MB each)", g_jit_main_mb.load(), g_jit_thread_mb.load());
    diag("INFO", "settings", "backend=%s res=%.2fx aniso=%d filter=%s vsync=%d shadercache=%d asyncpipe=%d texcache=%d nosurfsync=%d spirv=%d highacc=%d accmath=%d vol=%d ngs=%d mapping=%s",
        c.backend_renderer.c_str(), c.resolution_multiplier, c.anisotropic_filtering, c.screen_filter.c_str(), c.v_sync, c.shader_cache,
        c.async_pipeline_compilation, c.texture_cache, c.disable_surface_sync, c.spirv_shader, c.high_accuracy, [S(@"accmath") boolValue], c.audio_volume, c.ngs_enable, c.memory_mapping.c_str());
}

// ---------------------------------------------------------------------------------------------
// Performance / memory / audio log (jetsam watch)
// ---------------------------------------------------------------------------------------------
static uint64_t mem_used_mb() {
    task_vm_info_data_t info;
    mach_msg_type_number_t cnt = TASK_VM_INFO_COUNT;
    if (task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&info, &cnt) == KERN_SUCCESS)
        return (uint64_t)info.phys_footprint >> 20;
    return 0;
}
// who owns the RAM? guest (emulated Vita) memory vs Metal/MoltenVK resources; the rest is JIT code, heap, threads
static uint64_t guest_resident_mb(EmuEnvState &e) {
    uint8_t *base = e.mem.memory.get();
    if (!base) return 0;
    const size_t total = (size_t)4 << 30, ps = (size_t)getpagesize();
    static std::vector<char> vec;
    vec.resize(total / ps);
    if (mincore(base, total, vec.data()) != 0) return 0;
    size_t c = 0;
    for (char v : vec) c += (v & 1);
    return (uint64_t)(c * ps) >> 20;
}
static uint64_t metal_alloc_mb() {
    static id<MTLDevice> dev = MTLCreateSystemDefaultDevice();
    return dev ? (uint64_t)dev.currentAllocatedSize >> 20 : 0;
}
static uint64_t mem_left_mb() { return (uint64_t)os_proc_available_memory() >> 20; }

// ---------------------------------------------------------------------------------------------
// Memory spike hunter: walks the process VM map and says WHICH kind of memory grew (guest RAM, malloc heap, JIT/executable
// mappings, Metal/IOKit, thread stacks...). Dirty + compressed ("swapped") pages are what iOS counts against the jetsam limit.
// ---------------------------------------------------------------------------------------------
static std::atomic<bool> g_vm_watch{false};
static std::atomic<uintptr_t> g_guest_base{0}; // refreshed by the main loop (perf_tick); the sampler thread never touches emuenv
static const char *vm_tag_name(unsigned tag) {
    switch (tag) {
    case VM_MEMORY_MALLOC: return "malloc";
    case VM_MEMORY_MALLOC_SMALL: return "malloc_small";
    case VM_MEMORY_MALLOC_LARGE: return "malloc_large";
    case VM_MEMORY_MALLOC_TINY: return "malloc_tiny";
    case VM_MEMORY_MALLOC_NANO: return "malloc_nano";
    case VM_MEMORY_STACK: return "stack";
    default: return nullptr;
    }
}
static void vm_breakdown(uintptr_t guest_base, const char *why) {
    const CFAbsoluteTime t_begin = CFAbsoluteTimeGetCurrent();
    diag("INFO", "vm.snapshot", "begin: %s", why);
    struct Cat { uint64_t dirty = 0, swapped = 0, virt = 0; unsigned n = 0; uint64_t big_sz = 0; uintptr_t big_addr = 0; };
    std::map<std::string, Cat> cats;
    const uintptr_t gend = guest_base + ((uintptr_t)4 << 30);
    const uint64_t ps = (uint64_t)getpagesize();
    vm_address_t addr = 0;
    natural_t depth = 0;
    for (int guard = 0; guard < 200000; guard++) {
        vm_size_t sz = 0;
        vm_region_submap_info_data_64_t info;
        mach_msg_type_number_t cnt = VM_REGION_SUBMAP_INFO_COUNT_64;
        if (vm_region_recurse_64(mach_task_self(), &addr, &sz, &depth, (vm_region_recurse_info_t)&info, &cnt) != KERN_SUCCESS)
            break;
        if (info.is_submap) { depth++; continue; }
        std::string key;
        if (guest_base && (uintptr_t)addr >= guest_base && (uintptr_t)addr < gend) key = "GUEST(emulated Vita RAM)";
        else {
            const bool exec = (info.protection & VM_PROT_EXECUTE) != 0;
            const char *nm = vm_tag_name(info.user_tag);
            char b[64];
            if (nm) snprintf(b, sizeof(b), "%s%s", exec ? "EXEC/JIT " : "", nm);
            else snprintf(b, sizeof(b), "%stag%u", exec ? "EXEC/JIT " : "", info.user_tag);
            key = b;
        }
        Cat &c = cats[key];
        const uint64_t d = (uint64_t)info.pages_dirtied * ps, sw = (uint64_t)info.pages_swapped_out * ps;
        c.dirty += d; c.swapped += sw; c.virt += sz; c.n++;
        if (d + sw > c.big_sz) { c.big_sz = d + sw; c.big_addr = (uintptr_t)addr; }
        addr += sz;
    }
    std::vector<std::pair<std::string, Cat>> v(cats.begin(), cats.end());
    std::sort(v.begin(), v.end(), [](auto &a, auto &b) { return a.second.dirty + a.second.swapped > b.second.dirty + b.second.swapped; });
    diag("INFO", "vm.snapshot", "---- walk took %.0f ms, %zu kinds (dirty+compressed per memory kind, top 6) ----", (CFAbsoluteTimeGetCurrent() - t_begin) * 1000.0, v.size());
    for (size_t i = 0; i < v.size() && i < 6; i++) {
        const Cat &c = v[i].second;
        diag("INFO", "vm.snapshot", "%-26s dirty=%lluMB compressed=%lluMB virtual=%lluMB regions=%u biggest=%lluMB@0x%lx",
            v[i].first.c_str(), c.dirty >> 20, c.swapped >> 20, c.virt >> 20, c.n, c.big_sz >> 20, (unsigned long)c.big_addr);
    }
}
// background sampler: takes a snapshot every time the footprint grew >=150MB since the last one (checked 4x per second)
static void vm_watch_start() {
    if (g_vm_watch.exchange(true)) return;
    std::thread([]() {
        uint64_t last = 0;
        int shots = 0;
        while (g_vm_watch.load() && shots < 12) {
            usleep(250000);
            const uint64_t used = mem_used_mb();
            if (used >= last + 150) {
                char why[96];
                snprintf(why, sizeof(why), "footprint %lluMB, ram_left %lluMB", used, mem_left_mb());
                vm_breakdown(g_guest_base.load(), why);
                last = used;
                shots++;
            }
        }
        g_vm_watch = false;
    }).detach();
}


static void mem_split_mb(uint64_t *internal_mb, uint64_t *compressed_mb) {
    task_vm_info_data_t info;
    mach_msg_type_number_t cnt = TASK_VM_INFO_COUNT;
    if (task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&info, &cnt) == KERN_SUCCESS) {
        *internal_mb = (uint64_t)info.internal >> 20;
        *compressed_mb = (uint64_t)info.compressed >> 20;
    } else {
        *internal_mb = *compressed_mb = 0;
    }
}
// Event notes from patched emulator sources (guest allocations / frees / thread creation): one diagnostics line each,
// so the trail shows WHAT was allocating while RAM climbed. Capped so it can never flood the file.
extern "C" void ios_diag_note(const char *what, const char *name, unsigned long long bytes) {
    static std::atomic<int> n{0};
    if (n.fetch_add(1) >= 900) return;
    diag("INFO", "note", "%-12s %-34s size=%lluKB | footprint=%lluMB left=%lluMB", what, name && *name ? name : "-", bytes >> 10, mem_used_mb(), mem_left_mb());
}
// RAM numbers for the in-game FPS overlay (called from overlay/perf_overlay.cpp, patched in apply_ios_patches.py)
extern "C" void ios_mem_status(unsigned *used_mb, unsigned *left_mb) {
    if (used_mb) *used_mb = (unsigned)mem_used_mb();
    if (left_mb) *left_mb = (unsigned)mem_left_mb();
}

static CFAbsoluteTime g_perf_t0 = 0;
static uint64_t g_min_left = UINT64_MAX, g_peak_used = 0;
static uint32_t g_perf_samples = 0, g_fps_sum = 0;

static void perf_reset() { g_perf_t0 = CFAbsoluteTimeGetCurrent(); g_min_left = UINT64_MAX; g_peak_used = 0; g_perf_samples = 0; g_fps_sum = 0; }
static void perf_tick(EmuEnvState &e) {
    static CFAbsoluteTime last = 0;
    const CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    // sample every second during the first 40 s of a session (that is when RAM spikes), then every 5 s
    if (now - last < (now - g_perf_t0 < 40.0 ? 1.0 : 5.0)) return;
    last = now;
    g_guest_base = (uintptr_t)e.mem.memory.get();
    const uint64_t left = mem_left_mb(), used = mem_used_mb(), guest = guest_resident_mb(e), metal = metal_alloc_mb();
    uint64_t vm_internal = 0, vm_compressed = 0;
    mem_split_mb(&vm_internal, &vm_compressed);
    g_min_left = std::min(g_min_left, left);
    g_peak_used = std::max(g_peak_used, used);
    g_perf_samples++;
    g_fps_sum += e.fps;
    if (![S(@"perflog") boolValue]) return;
    const char *lvl = left && left < 250 ? "WARN" : "INFO";
    diag(lvl, "perf", "fps=%u avg=%u min=%u max=%u frame=%ums | ram_used=%lluMB ram_left=%lluMB (guest=%lluMB metal=%lluMB other=%lldMB) internal=%lluMB compressed=%lluMB%s | thermal=%ld lowpower=%d",
        e.fps, e.avg_fps, e.min_fps, e.max_fps, e.ms_per_frame, used, left, guest, metal, (long long)used - (long long)guest - (long long)metal, vm_internal, vm_compressed,
        (left && left < 250) ? " **JETSAM RISK - iOS may kill the app**" : "",
        (long)NSProcessInfo.processInfo.thermalState, (int)NSProcessInfo.processInfo.lowPowerModeEnabled);
    const char *drv = SDL_GetCurrentAudioDriver();
    diag(e.audio.adapter ? "INFO" : "WARN", "audio", "backend=%s sdl_driver=%s adapter=%s volume=%d",
        e.audio.audio_backend.c_str(), drv ? drv : "none", e.audio.adapter ? "active" : "NOT created", e.cfg.current_config.audio_volume);
}
// ---------------------------------------------------------------------------------------------
// iOS keyboard -> game text input (SceIme + IME common dialog)
// Ported from the working Vita3K-iOS keyboard (IOSKeyboard.mm). The game owns delivery of events: UIKit only
// publishes text into Ime and calls Ime::native_input.submit() for Enter / Close (see vita3k/ime/native_input.h).
// ---------------------------------------------------------------------------------------------
static bool ime_dialog_active(const EmuEnvState &e) {
    return e.common_dialog.type == IME_DIALOG && e.common_dialog.status == SCE_COMMON_DIALOG_STATUS_RUNNING;
}
static std::u16string ime_utf16(NSString *value) {
    std::u16string result(value.length, u'\0');
    [value getCharacters:reinterpret_cast<unichar *>(result.data()) range:NSMakeRange(0, value.length)];
    return result;
}
static NSString *ime_native_text(const std::u16string &value) {
    return [[NSString alloc] initWithCharacters:reinterpret_cast<const unichar *>(value.data()) length:value.size()];
}

@interface Vita3KKeyboard : NSObject <UITextViewDelegate>
@property (nonatomic) EmuEnvState *environment;
@property (nonatomic) uint64_t generation;
@property (nonatomic) BOOL dialog;
@property (nonatomic) BOOL cancelable;
@property (nonatomic) BOOL updating;
@property (nonatomic) BOOL finished;
@property (nonatomic, strong) UIView *backdrop;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, strong) UIButton *confirmButton;
@property (nonatomic, strong) UITextView *editor;
@property (nonatomic, strong) UILabel *heading;
@property (nonatomic, strong) UIButton *cancelButton;
- (void)updatePlaceholder;
- (void)publishText;
- (void)submit;
- (void)cancel;
- (void)confirmOrEdit;
@end

@implementation Vita3KKeyboard
- (BOOL)matchesSession {
    return self.environment && self.environment->ime.generation == self.generation
        && (self.dialog ? ime_dialog_active(*self.environment) : self.environment->ime.state);
}
- (void)updatePlaceholder {
    self.heading.hidden = self.editor.text.length > 0;
}
- (void)publishText {
    if (self.updating || self.finished || self.editor.markedTextRange || !self.environment)
        return;
    auto &env = *self.environment;
    std::lock_guard dialogLock(env.common_dialog.mutex);
    std::lock_guard imeLock(env.ime.mutex);
    if (![self matchesSession])
        return;
    auto text = ime_utf16(self.editor.text);
    text.resize(ime::text_length(text, env.ime.param.maxTextLength));
    const auto caret = static_cast<uint32_t>(ime::text_length(text, self.editor.selectedRange.location));
    if (text != env.ime.str || caret != env.ime.edit_text.caretIndex) {
        env.ime.event_id = text != env.ime.str || env.ime.event_id == SCE_IME_EVENT_UPDATE_TEXT
            ? SCE_IME_EVENT_UPDATE_TEXT
            : SCE_IME_EVENT_UPDATE_CARET;
        env.ime.str = text;
        env.ime.edit_text.editIndex = 0;
        env.ime.edit_text.caretIndex = env.ime.caretIndex = caret;
        env.ime.edit_text.preeditIndex = caret;
        env.ime.edit_text.preeditLength = 0;
        env.ime.edit_text.editLengthChange = 0;
    }
    if (self.editor.text.length != text.size()) {
        self.updating = YES;
        self.editor.text = ime_native_text(text);
        self.editor.selectedRange = NSMakeRange(caret, 0);
        self.updating = NO;
    }
}
- (void)textViewDidChange:(UITextView *)textView {
    [self updatePlaceholder];
    [self publishText];
}
- (void)textViewDidChangeSelection:(UITextView *)textView {
    [self publishText];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if (ime::is_submit_key(ime_utf16(text), textView.markedTextRange != nil)) {
        [self submit];
        return NO;
    }
    return YES;
}
- (void)confirmOrEdit {
    if (!self.finished) {
        [self submit];
        return;
    }
    if (!self.environment || self.dialog)
        return;
    {
        auto &env = *self.environment;
        std::lock_guard dialogLock(env.common_dialog.mutex);
        std::lock_guard imeLock(env.ime.mutex);
        if (![self matchesSession] || !env.ime.native_input.resume())
            return;
    }
    self.finished = NO;
    self.editor.editable = YES;
    self.editor.userInteractionEnabled = YES;
    self.editor.delegate = self;
    self.heading.text = self.editor.accessibilityLabel;
    [self.confirmButton setTitle:@"Confirm" forState:UIControlStateNormal];
    self.cancelButton.hidden = !self.cancelable;
    [self.editor becomeFirstResponder];
}
- (void)lockEditor {
    self.finished = YES;
    self.editor.delegate = nil;
    [self.editor resignFirstResponder];
    self.editor.editable = NO;
    self.editor.userInteractionEnabled = NO;
    self.heading.text = @"Waiting for game";
    self.confirmButton.enabled = NO;
    [self.confirmButton setTitle:@"Edit" forState:UIControlStateNormal];
    self.cancelButton.hidden = YES;
}
- (void)submit {
    if (self.finished || !self.environment)
        return;
    [self.editor unmarkText];
    auto finalText = ime_utf16(self.editor.text);
    const auto finalCaret = self.editor.selectedRange.location;
    {
        auto &env = *self.environment;
        std::lock_guard dialogLock(env.common_dialog.mutex);
        std::lock_guard imeLock(env.ime.mutex);
        if (![self matchesSession])
            return;
        finalText.resize(ime::text_length(finalText, env.ime.param.maxTextLength));
        const auto caret = static_cast<uint32_t>(ime::text_length(finalText, finalCaret));
        if (finalText != env.ime.str || caret != env.ime.edit_text.caretIndex)
            env.ime.event_id = SCE_IME_EVENT_UPDATE_TEXT;
        env.ime.str = finalText;
        env.ime.caretIndex = env.ime.edit_text.caretIndex = caret;
        env.ime.edit_text.preeditIndex = caret;
        env.ime.edit_text.preeditLength = 0;
        if (self.dialog) {
            auto &dialog = env.common_dialog;
            const auto length = ime::text_length(env.ime.str, dialog.ime.max_length);
            if (dialog.ime.result) {
                std::memcpy(dialog.ime.result, env.ime.str.data(), length * sizeof(char16_t));
                dialog.ime.result[length] = 0;
            }
            const auto text = string_utils::utf16_to_utf8(env.ime.str.substr(0, length));
            std::snprintf(dialog.ime.text, sizeof(dialog.ime.text), "%s", text.c_str());
            dialog.ime.status = SCE_IME_DIALOG_BUTTON_ENTER;
            dialog.result = SCE_COMMON_DIALOG_RESULT_OK;
            dialog.status = SCE_COMMON_DIALOG_STATUS_FINISHED;
        } else {
            // The guest owns delivery, independently of UIKit frame polling.
            env.ime.native_input.submit(SCE_IME_EVENT_PRESS_ENTER);
        }
    }
    [self lockEditor];
}
- (void)cancel {
    if (!self.cancelable || self.finished || !self.environment)
        return;
    {
        auto &env = *self.environment;
        std::lock_guard dialogLock(env.common_dialog.mutex);
        std::lock_guard imeLock(env.ime.mutex);
        if (![self matchesSession])
            return;
        if (self.dialog) {
            env.common_dialog.ime.status = SCE_IME_DIALOG_BUTTON_CLOSE;
            env.common_dialog.result = SCE_COMMON_DIALOG_RESULT_USER_CANCELED;
            env.common_dialog.status = SCE_COMMON_DIALOG_STATUS_FINISHED;
        } else {
            env.ime.native_input.submit(SCE_IME_EVENT_PRESS_CLOSE);
        }
    }
    [self lockEditor];
}
@end

static Vita3KKeyboard *g_keyboard = nil;

static void ime_keyboard_close() {
    if (!g_keyboard)
        return;
    g_keyboard.environment = nullptr;
    g_keyboard.editor.delegate = nil;
    [g_keyboard.editor resignFirstResponder];
    [g_keyboard.backdrop removeFromSuperview];
    g_keyboard = nil;
}

// called from the main loop: keeps the iOS keyboard in sync with the game's text-input state
static void ime_prompt_tick(EmuEnvState &env) {
    bool active, isDialog, multiline, cancelable, dismissed, pending;
    uint64_t generation;
    std::u16string text;
    uint32_t caret, type, enterLabel;
    NSString *title;
    {
        std::lock_guard dialogLock(env.common_dialog.mutex);
        std::lock_guard imeLock(env.ime.mutex);
        isDialog = ime_dialog_active(env);
        active = isDialog || env.ime.state;
        generation = env.ime.generation;
        text = env.ime.str;
        caret = env.ime.edit_text.caretIndex;
        multiline = isDialog ? env.common_dialog.ime.multiline : (env.ime.param.option & SCE_IME_OPTION_MULTILINE) != 0;
        cancelable = !isDialog || env.common_dialog.ime.cancelable;
        type = env.ime.param.type;
        enterLabel = env.ime.param.enterLabel;
        title = isDialog ? [NSString stringWithUTF8String:env.common_dialog.ime.title] : @"Game text input";
        dismissed = !isDialog && env.ime.native_input.dismissed();
        pending = env.ime.native_input.pending();
    }
    if (!active) {
        ime_keyboard_close();
        return;
    }
    if (g_keyboard && (g_keyboard.generation != generation || g_keyboard.dialog != isDialog))
        ime_keyboard_close();
    // Keep the system keyboard dismissed while the callback runs or the game keeps SceIme open.
    // A later close/open increments generation.
    if (dismissed) {
        if (g_keyboard) {
            g_keyboard.heading.text = @"Waiting for game";
            g_keyboard.confirmButton.enabled = !pending;
            [g_keyboard.backdrop.superview bringSubviewToFront:g_keyboard.backdrop];
        }
        return;
    }
    if (g_keyboard) {
        if (g_keyboard.finished) {
            [g_keyboard.editor resignFirstResponder];
            g_keyboard.panel.hidden = YES;
        } else if (!g_keyboard.editor.markedTextRange
            && (![g_keyboard.editor.text isEqualToString:ime_native_text(text)] || g_keyboard.editor.selectedRange.location != caret)) {
            g_keyboard.updating = YES;
            g_keyboard.editor.text = ime_native_text(text);
            g_keyboard.editor.selectedRange = NSMakeRange(std::min<size_t>(caret, text.size()), 0);
            g_keyboard.updating = NO;
            [g_keyboard updatePlaceholder];
        }
        if (!g_keyboard.finished) {
            g_keyboard.panel.hidden = NO;
            [g_keyboard.backdrop.superview bringSubviewToFront:g_keyboard.backdrop];
            if (!g_keyboard.editor.isFirstResponder && UIApplication.sharedApplication.applicationState == UIApplicationStateActive)
                [g_keyboard.editor becomeFirstResponder];
        }
        return;
    }
    UIWindow *window = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (scene.activationState != UISceneActivationStateForegroundActive || ![scene isKindOfClass:UIWindowScene.class])
            continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows)
            if (candidate.isKeyWindow) {
                window = candidate;
                break;
            }
    }
    if (!window)
        return;
    Vita3KKeyboard *kb = [Vita3KKeyboard new];
    g_keyboard = kb;
    kb.environment = &env;
    kb.generation = generation;
    kb.dialog = isDialog;
    kb.cancelable = cancelable;
    kb.backdrop = [UIView new];
    kb.backdrop.backgroundColor = UIColor.clearColor;
    kb.backdrop.frame = window.bounds;
    kb.backdrop.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    kb.panel = [UIView new];
    kb.panel.backgroundColor = UIColor.whiteColor;
    kb.panel.tintColor = UIColor.systemBlueColor;
    kb.panel.layer.borderColor = [UIColor colorWithWhite:0.8 alpha:1].CGColor;
    kb.panel.layer.borderWidth = 0.5;
    kb.panel.layer.cornerRadius = 12;
    kb.panel.layer.shadowColor = UIColor.blackColor.CGColor;
    kb.panel.layer.shadowOpacity = 0.25;
    kb.panel.layer.shadowRadius = 8;
    kb.panel.layer.shadowOffset = CGSizeMake(0, 2);
    kb.panel.translatesAutoresizingMaskIntoConstraints = NO;
    kb.editor = [UITextView new];
    // Compact field: light-grey rounded box, fixed 17pt font, text vertically centred.
    // (Previously: plain white box, Dynamic Type font and a separate title row, which ate half of the landscape screen.)
    const CGFloat kLine = [UIFont systemFontOfSize:17].lineHeight;
    const CGFloat kEditorHeight = multiline ? 72 : 36;
    const CGFloat kInsetV = multiline ? 8 : std::max<CGFloat>(0, std::floor((kEditorHeight - kLine) / 2));
    kb.editor.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1];
    kb.editor.layer.cornerRadius = 8;
    kb.editor.clipsToBounds = YES;
    kb.editor.textColor = UIColor.blackColor;
    kb.editor.tintColor = UIColor.systemBlueColor;
    kb.editor.font = [UIFont systemFontOfSize:17];
    kb.editor.textContainerInset = UIEdgeInsetsMake(kInsetV, 6, kInsetV, 6);
    kb.editor.scrollEnabled = YES; // long text scrolls so the caret stays visible
    kb.editor.text = ime_native_text(text);
    kb.editor.selectedRange = NSMakeRange(std::min<size_t>(caret, text.size()), 0);
    kb.editor.delegate = kb;
    kb.editor.accessibilityLabel = title;
    kb.editor.autocorrectionType = UITextAutocorrectionTypeNo;
    switch (type) {
    case SCE_IME_TYPE_BASIC_LATIN: kb.editor.keyboardType = UIKeyboardTypeASCIICapable; break;
    case SCE_IME_TYPE_NUMBER: kb.editor.keyboardType = UIKeyboardTypeNumberPad; break;
    case SCE_IME_TYPE_EXTENDED_NUMBER: kb.editor.keyboardType = UIKeyboardTypeNumbersAndPunctuation; break;
    case SCE_IME_TYPE_URL: kb.editor.keyboardType = UIKeyboardTypeURL; break;
    case SCE_IME_TYPE_MAIL: kb.editor.keyboardType = UIKeyboardTypeEmailAddress; break;
    default: kb.editor.keyboardType = UIKeyboardTypeDefault; break;
    }
    switch (enterLabel) {
    case SCE_IME_ENTER_LABEL_SEND: kb.editor.returnKeyType = UIReturnKeySend; break;
    case SCE_IME_ENTER_LABEL_SEARCH: kb.editor.returnKeyType = UIReturnKeySearch; break;
    case SCE_IME_ENTER_LABEL_GO: kb.editor.returnKeyType = UIReturnKeyGo; break;
    default: kb.editor.returnKeyType = UIReturnKeyDone; break;
    }
    kb.heading = [UILabel new];
    kb.heading.text = title;
    // heading is now a grey placeholder drawn inside the text field (hidden as soon as there is text)
    kb.heading.textColor = [UIColor colorWithWhite:0.55 alpha:1];
    kb.heading.font = [UIFont systemFontOfSize:17];
    kb.heading.lineBreakMode = NSLineBreakByTruncatingTail;
    kb.heading.userInteractionEnabled = NO;
    kb.heading.translatesAutoresizingMaskIntoConstraints = NO;
    kb.heading.hidden = text.size() > 0;
    kb.cancelButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [kb.cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
    kb.cancelButton.hidden = !cancelable;
    [kb.cancelButton addTarget:kb action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
    UIButton *done = [UIButton buttonWithType:UIButtonTypeSystem];
    kb.confirmButton = done;
    [done setTitle:@"Confirm" forState:UIControlStateNormal];
    [done addTarget:kb action:@selector(confirmOrEdit) forControlEvents:UIControlEventTouchUpInside];
    kb.cancelButton.titleLabel.font = [UIFont systemFontOfSize:17];
    done.titleLabel.font = [UIFont boldSystemFontOfSize:17];
    for (UIButton *b in @[ kb.cancelButton, done ]) {
        [b setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
        [b setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    }
    [kb.editor setContentHuggingPriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisHorizontal];
    [kb.editor addSubview:kb.heading];
    // Single row: Cancel | text field (fills the width) | Confirm. Buttons hidden => field simply takes the space.
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[ kb.cancelButton, kb.editor, done ]];
    stack.axis = UILayoutConstraintAxisHorizontal;
    stack.alignment = UIStackViewAlignmentCenter;
    stack.spacing = 8;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [kb.panel addSubview:stack];
    [kb.backdrop addSubview:kb.panel];
    [window addSubview:kb.backdrop];
    [window bringSubviewToFront:kb.backdrop];
    NSLayoutConstraint *preferredWidth = [kb.panel.widthAnchor constraintEqualToAnchor:kb.backdrop.safeAreaLayoutGuide.widthAnchor constant:-24];
    preferredWidth.priority = UILayoutPriorityDefaultHigh;
    [NSLayoutConstraint activateConstraints:@[
        preferredWidth,
        [kb.panel.widthAnchor constraintLessThanOrEqualToConstant:560],
        [kb.panel.centerXAnchor constraintEqualToAnchor:kb.backdrop.safeAreaLayoutGuide.centerXAnchor],
        [kb.panel.leadingAnchor constraintGreaterThanOrEqualToAnchor:kb.backdrop.safeAreaLayoutGuide.leadingAnchor constant:12],
        [kb.panel.trailingAnchor constraintLessThanOrEqualToAnchor:kb.backdrop.safeAreaLayoutGuide.trailingAnchor constant:-12],
        [kb.panel.bottomAnchor constraintEqualToAnchor:kb.backdrop.keyboardLayoutGuide.topAnchor constant:-8],
        [stack.leadingAnchor constraintEqualToAnchor:kb.panel.leadingAnchor constant:10],
        [stack.trailingAnchor constraintEqualToAnchor:kb.panel.trailingAnchor constant:-10],
        [stack.topAnchor constraintEqualToAnchor:kb.panel.topAnchor constant:6],
        [stack.bottomAnchor constraintEqualToAnchor:kb.panel.bottomAnchor constant:-6],
        [kb.editor.heightAnchor constraintEqualToConstant:kEditorHeight],
        // placeholder sits exactly where the first typed character would appear
        [kb.heading.leadingAnchor constraintEqualToAnchor:kb.editor.frameLayoutGuide.leadingAnchor constant:6 + 5],
        [kb.heading.trailingAnchor constraintEqualToAnchor:kb.editor.frameLayoutGuide.trailingAnchor constant:-6],
        multiline ? [kb.heading.topAnchor constraintEqualToAnchor:kb.editor.frameLayoutGuide.topAnchor constant:kInsetV]
                  : [kb.heading.centerYAnchor constraintEqualToAnchor:kb.editor.frameLayoutGuide.centerYAnchor]
    ]];
    [kb.editor becomeFirstResponder];
}

// ---------------------------------------------------------------------------------------------
// Crash guard: records real crashes (signals / uncaught exceptions) in diagnostics.txt with a backtrace.
// A process killed by iOS (jetsam / watchdog) receives SIGKILL, which cannot be caught -> in that case the trail
// simply stops with NO "[CRASH]" line. That difference tells "emulator crashed" from "iOS killed the app".
// ---------------------------------------------------------------------------------------------
static struct sigaction g_old_sa[32];
static void crash_handler(int sig, siginfo_t *info, void *ctx) {
    uint8_t *base = g_emuenv ? g_emuenv->mem.memory.get() : nullptr;
    const uintptr_t a = (uintptr_t)info->si_addr;
    const bool guest = base && (sig == SIGSEGV || sig == SIGBUS) && a >= (uintptr_t)base && a < (uintptr_t)base + ((uintptr_t)4 << 30);
    if (!guest && g_diag_fd >= 0) {
        char buf[200];
        const int n = snprintf(buf, sizeof(buf), "[CRASH] signal=%d (%s) fault_addr=0x%lx\n", sig, strsignal(sig), (unsigned long)a);
        (void)!write(g_diag_fd, buf, (size_t)n);
        void *bt[48];
        const int c = backtrace(bt, 48);
        backtrace_symbols_fd(bt, c, g_diag_fd);
        fsync(g_diag_fd);
    }
    struct sigaction &o = g_old_sa[sig];
    if ((o.sa_flags & SA_SIGINFO) && o.sa_sigaction) {
        o.sa_sigaction(sig, info, ctx);
    } else if (o.sa_handler && o.sa_handler != SIG_DFL && o.sa_handler != SIG_IGN) {
        o.sa_handler(sig);
    } else if (!guest) {
        signal(sig, SIG_DFL);
        raise(sig);
    }
}
static void install_crash_handlers() {
    static const int sigs[] = { SIGSEGV, SIGBUS, SIGTRAP, SIGABRT, SIGILL, SIGFPE };
    for (int sg : sigs) {
        struct sigaction cur;
        sigaction(sg, nullptr, &cur);
        if ((cur.sa_flags & SA_SIGINFO) && cur.sa_sigaction == crash_handler) continue;
        g_old_sa[sg] = cur;
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_flags = SA_SIGINFO;
        sigemptyset(&sa.sa_mask);
        sa.sa_sigaction = crash_handler;
        sigaction(sg, &sa, nullptr);
    }
    diag("INFO", "crashguard", "crash handlers installed (if the trail ends without a CRASH-signal line, iOS killed the app, e.g. jetsam)");
}

static void perf_summary() {
    g_vm_watch = false;
    if (!g_perf_samples) return;
    diag("INFO", "perf.summary", "avg_fps=%u peak_ram_used=%lluMB min_ram_left=%lluMB samples=%u",
        g_fps_sum / g_perf_samples, g_peak_used, g_min_left == UINT64_MAX ? 0 : g_min_left, g_perf_samples);
}

// ---------------------------------------------------------------------------------------------
// Vulkan loader / metal layer hooks used by patched renderer sources
// ---------------------------------------------------------------------------------------------
extern "C" void *ios_get_vk_instance_proc_addr() {
    static void *fn = nullptr;
    if (fn)
        return fn;
    NSString *fw = [[NSBundle mainBundle] privateFrameworksPath];
    NSString *path = [fw stringByAppendingPathComponent:@"MoltenVK.framework/MoltenVK"];
    void *handle = dlopen(path.UTF8String, RTLD_NOW | RTLD_LOCAL);
    if (handle) {
        LOG_INFO("MoltenVK loaded from {}", path.UTF8String);
        diag("OK", "moltenvk", "loaded %s", path.UTF8String);
    } else {
        const char *err = dlerror();
        LOG_ERROR("dlopen({}) failed: {}", path.UTF8String, err ? err : "unknown error");
        diag("FAIL", "moltenvk", "dlopen(%s) failed: %s", path.UTF8String, err ? err : "unknown error");
        handle = dlopen("libMoltenVK.dylib", RTLD_NOW | RTLD_LOCAL);
    }
    if (!handle)
        handle = RTLD_DEFAULT;
    fn = dlsym(handle, "vkGetInstanceProcAddr");
    if (!fn && handle != RTLD_DEFAULT)
        fn = dlsym(RTLD_DEFAULT, "vkGetInstanceProcAddr");
    if (!fn) {
        LOG_ERROR("Could not resolve vkGetInstanceProcAddr from MoltenVK ({})", path.UTF8String);
        diag("FAIL", "moltenvk", "vkGetInstanceProcAddr not found");
    } else {
        diag("OK", "moltenvk", "vkGetInstanceProcAddr resolved");
    }
    return fn;
}

// screen_renderer.cpp calls this with MacOSDisplayHandle::view; on iOS that view is an SDL_MetalView
extern "C" void *get_metal_layer_from_view(void *view) {
    return SDL_Metal_GetLayer(static_cast<SDL_MetalView>(view));
}

// ---------------------------------------------------------------------------------------------
// Session init (same flow as android/jni/native_bootstrap.cpp)
// ---------------------------------------------------------------------------------------------
static fs::path documents_path() {
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    return fs::path(std::string(docs.UTF8String)) / "Vita3K" / "";
}

static bool init_session() {
    try {
        const fs::path storage_path = documents_path();
        const fs::path vita_path = storage_path / "vita" / "";
        const fs::path bundle_path = fs::path(std::string([[NSBundle mainBundle] resourcePath].UTF8String)) / "";

        g_root.set_static_assets_path(bundle_path);
        g_root.set_vita_fs_path(vita_path);
        g_root.set_log_path(storage_path);
        g_root.set_config_path(storage_path);
        g_root.set_shared_path(storage_path);
        g_root.set_cache_path(storage_path / "cache" / "");
        g_root.set_patch_path(storage_path / "patch" / "");

        fs::create_directories(g_root.get_vita_fs_path());
        fs::create_directories(g_root.get_config_path());
        fs::create_directories(g_root.get_cache_path());
        fs::create_directories(g_root.get_log_path() / "shaderlog");
        fs::create_directories(g_root.get_log_path() / "texturelog");
        fs::create_directories(g_root.get_patch_path());
        fs::create_directories(g_root.get_shared_path() / "textures");

        if (logging::init(g_root, true) != Success)
            return false;
#ifdef V3K_HAVE_SPDLOG
        spdlog::default_logger()->flush_on(spdlog::level::trace);
#endif
        LOG_INFO("{}", window_title);

        g_emuenv = std::make_unique<EmuEnvState>();

        Config cfg{};
        char arg0[] = "vita3k";
        char *argv[] = { arg0, nullptr };
        if (config::init_config(cfg, 1, argv, g_root) != Success) {
            LOG_ERROR("Failed to initialise config.");
            diag("FAIL", "init_session", "failed to initialise config");
            g_emuenv.reset();
            return false;
        }
        fs::create_directories(cfg.get_vita_fs_path());

        if (!app::init(*g_emuenv, cfg, g_root)) {
            LOG_ERROR("Failed to initialise emulated environment.");
            diag("FAIL", "init_session", "failed to initialise emulated environment");
            g_emuenv.reset();
            return false;
        }

        // Debugger-based JIT (StikDebug etc.) intercepts memory-fault signals, so never use fault-based memory mapping.
        g_emuenv->cfg.memory_mapping = "page-table";
        g_emuenv->cfg.current_config.memory_mapping = "page-table";

        g_emuenv->vulkan_device_info = std::make_unique<renderer::VulkanDeviceInfo>(renderer::enumerate_vulkan_devices());

        if (g_emuenv->cfg.controller_binds.empty() || g_emuenv->cfg.controller_binds.size() != 15
            || g_emuenv->cfg.controller_axis_binds.empty() || g_emuenv->cfg.controller_axis_binds.size() != 6) {
            app::reset_controller_binding(*g_emuenv);
        }

        init_libraries(*g_emuenv);

        if (!app::init_apps_list(*g_emuenv)) {
            LOG_ERROR("Failed to initialise apps list.");
            diag("WARN", "init_session", "apps list is empty / not initialised yet (normal on first run)");
        }

        app::load_users(*g_emuenv);
        if (!app::ensure_current_user(*g_emuenv)) {
            LOG_ERROR("Failed to initialize active user.");
            diag("FAIL", "init_session", "failed to initialise active user");
            return false;
        }
        compat::load_from_disk(g_emuenv->compat, std::filesystem::path(g_emuenv->cache_path.string()));

        g_controller = std::make_unique<app::AppSessionController>(*g_emuenv);
        return true;
    } catch (const std::exception &e) {
        LOG_ERROR("iOS session init failed: {}", e.what());
        diag("FAIL", "init_session", "exception: %s", e.what());
        g_emuenv.reset();
        return false;
    }
}

// ---------------------------------------------------------------------------------------------
// Virtual controller (same approach as android/jni/input_overlay.cpp)
// ---------------------------------------------------------------------------------------------
static SDL_JoystickID g_vjoy_id = 0;
static SDL_Joystick *g_vjoy = nullptr;

static void detach_virtual_controller() {
    if (g_vjoy)
        SDL_CloseJoystick(g_vjoy);
    if (g_vjoy_id)
        SDL_DetachVirtualJoystick(g_vjoy_id);
    g_vjoy = nullptr;
    g_vjoy_id = 0;
}

static void attach_virtual_controller() {
    detach_virtual_controller();
    if (!SDL_WasInit(SDL_INIT_GAMEPAD))
        return;

    SDL_VirtualJoystickDesc desc;
    SDL_INIT_INTERFACE(&desc);
    desc.type = SDL_JOYSTICK_TYPE_GAMEPAD;
    desc.naxes = SDL_GAMEPAD_AXIS_COUNT;
    desc.nbuttons = SDL_GAMEPAD_BUTTON_COUNT;
    desc.name = "Vita3K Virtual Controller";

    g_vjoy_id = SDL_AttachVirtualJoystick(&desc);
    if (g_vjoy_id == 0) {
        LOG_ERROR("Could not attach virtual joystick: {}", SDL_GetError());
        return;
    }
    g_vjoy = SDL_OpenJoystick(g_vjoy_id);
    if (!g_vjoy) {
        LOG_ERROR("Could not open virtual joystick: {}", SDL_GetError());
        detach_virtual_controller();
        return;
    }
    refresh_controllers(g_emuenv->ctrl, *g_emuenv);
}

static void vjoy_button(int button, bool down) {
    if (g_vjoy)
        SDL_SetJoystickVirtualButton(g_vjoy, button, down);
}
static void vjoy_axis(int axis, float v) { // v in [-1, 1]
    if (g_vjoy)
        SDL_SetJoystickVirtualAxis(g_vjoy, axis, static_cast<Sint16>(std::clamp(v, -1.f, 1.f) * 32767.f));
}

// ---------------------------------------------------------------------------------------------
// On-screen controls: grouped, draggable, resizable, layout saved in NSUserDefaults
// ---------------------------------------------------------------------------------------------
typedef NS_ENUM(NSInteger, V3KCtlKind) { V3KCtlButton, V3KCtlStick, V3KCtlMenu };

@interface V3KControl : NSObject
@property CGRect rect;
@property V3KCtlKind kind;
@property int button;
@property int axisX, axisY;
@property(copy) NSString *label;
@property(copy) NSString *group;
@property CGPoint off;   // offset from group center, in units
@property CGSize size;   // in units
@property(weak) UITouch *touch;
@property CGPoint stickOffset;
@end
@implementation V3KControl
@end

static NSString *const kLayoutKey = @"v3k_layout_v1";
static NSString *const kOpacityKey = @"v3k_opacity_v1";

@interface V3KOverlayView : UIView
@property(copy) void (^onMenu)(void);
@property(nonatomic) BOOL editing;
- (void)resetLayout;
- (void)saveLayout;
@end

@implementation V3KOverlayView {
    NSMutableArray<V3KControl *> *_controls;
    NSMutableDictionary<NSString *, NSMutableArray<NSNumber *> *> *_layout; // group -> [cx, cy, scale]
    NSString *_selected;
    __weak UITouch *_dragTouch;
    NSString *_dragGroup;
    CGPoint _grab;
    CGFloat _alpha;
    UIView *_bar;
}

static NSDictionary<NSString *, NSArray<NSNumber *> *> *DefaultLayout() {
    return @{
        @"dpad" : @[ @0.13, @0.46, @1.0 ],
        @"face" : @[ @0.87, @0.46, @1.0 ],
        @"ls" : @[ @0.15, @0.80, @1.0 ],
        @"rs" : @[ @0.85, @0.80, @1.0 ],
        @"L" : @[ @0.10, @0.10, @1.0 ],
        @"R" : @[ @0.90, @0.10, @1.0 ],
        @"select" : @[ @0.42, @0.93, @1.0 ],
        @"start" : @[ @0.58, @0.93, @1.0 ],
        @"menu" : @[ @0.50, @0.07, @1.0 ],
    };
}

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.multipleTouchEnabled = YES;
        self.backgroundColor = UIColor.clearColor;
        self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _controls = [NSMutableArray array];
        _layout = [NSMutableDictionary dictionary];
        NSDictionary *saved = [[NSUserDefaults standardUserDefaults] dictionaryForKey:kLayoutKey];
        [DefaultLayout() enumerateKeysAndObjectsUsingBlock:^(NSString *k, NSArray<NSNumber *> *v, BOOL *) {
            NSArray *s = saved[k];
            _layout[k] = [(s.count == 3 ? s : v) mutableCopy];
        }];
        _alpha = [[NSUserDefaults standardUserDefaults] objectForKey:kOpacityKey]
            ? [[NSUserDefaults standardUserDefaults] floatForKey:kOpacityKey] : 0.5;
    }
    return self;
}

- (void)saveLayout {
    [[NSUserDefaults standardUserDefaults] setObject:_layout forKey:kLayoutKey];
    [[NSUserDefaults standardUserDefaults] setFloat:_alpha forKey:kOpacityKey];
}

- (void)resetLayout {
    [DefaultLayout() enumerateKeysAndObjectsUsingBlock:^(NSString *k, NSArray<NSNumber *> *v, BOOL *) { _layout[k] = [v mutableCopy]; }];
    _alpha = 0.5;
    [self rebuild];
}

- (void)add:(NSString *)group off:(CGPoint)o size:(CGSize)s kind:(V3KCtlKind)k button:(int)b label:(NSString *)l {
    V3KControl *c = [V3KControl new];
    c.group = group; c.off = o; c.size = s; c.kind = k; c.button = b; c.label = l;
    [_controls addObject:c];
}

- (void)rebuild {
    for (V3KControl *c in _controls)
        if (c.touch) [self release:c];
    [_controls removeAllObjects];
    // unit offsets (1 unit == button size)
    [self add:@"dpad" off:CGPointMake(0, -1) size:CGSizeMake(1, 1) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_DPAD_UP label:@"▲"];
    [self add:@"dpad" off:CGPointMake(0, 1) size:CGSizeMake(1, 1) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_DPAD_DOWN label:@"▼"];
    [self add:@"dpad" off:CGPointMake(-1, 0) size:CGSizeMake(1, 1) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_DPAD_LEFT label:@"◀"];
    [self add:@"dpad" off:CGPointMake(1, 0) size:CGSizeMake(1, 1) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_DPAD_RIGHT label:@"▶"];
    [self add:@"face" off:CGPointMake(0, -1) size:CGSizeMake(1, 1) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_NORTH label:@"△"];
    [self add:@"face" off:CGPointMake(0, 1) size:CGSizeMake(1, 1) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_SOUTH label:@"✕"];
    [self add:@"face" off:CGPointMake(-1, 0) size:CGSizeMake(1, 1) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_WEST label:@"□"];
    [self add:@"face" off:CGPointMake(1, 0) size:CGSizeMake(1, 1) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_EAST label:@"○"];
    [self add:@"L" off:CGPointZero size:CGSizeMake(2.2, 0.9) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_LEFT_SHOULDER label:@"L"];
    [self add:@"R" off:CGPointZero size:CGSizeMake(2.2, 0.9) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER label:@"R"];
    [self add:@"select" off:CGPointZero size:CGSizeMake(1.5, 0.7) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_BACK label:@"SELECT"];
    [self add:@"start" off:CGPointZero size:CGSizeMake(1.5, 0.7) kind:V3KCtlButton button:SDL_GAMEPAD_BUTTON_START label:@"START"];
    [self add:@"menu" off:CGPointZero size:CGSizeMake(1.1, 0.8) kind:V3KCtlMenu button:0 label:@"☰"];
    [self add:@"ls" off:CGPointZero size:CGSizeMake(2.6, 2.6) kind:V3KCtlStick button:0 label:@""];
    [self add:@"rs" off:CGPointZero size:CGSizeMake(2.6, 2.6) kind:V3KCtlStick button:0 label:@""];
    for (V3KControl *c in _controls) {
        if ([c.group isEqualToString:@"ls"]) { c.axisX = SDL_GAMEPAD_AXIS_LEFTX; c.axisY = SDL_GAMEPAD_AXIS_LEFTY; }
        if ([c.group isEqualToString:@"rs"]) { c.axisX = SDL_GAMEPAD_AXIS_RIGHTX; c.axisY = SDL_GAMEPAD_AXIS_RIGHTY; }
    }
    [self relayout];
}

- (void)relayout {
    const CGFloat W = self.bounds.size.width, H = self.bounds.size.height;
    const CGFloat u = MIN(W, H) * 0.115;
    for (V3KControl *c in _controls) {
        NSArray<NSNumber *> *g = _layout[c.group];
        CGFloat s = g[2].doubleValue;
        CGPoint ctr = CGPointMake(g[0].doubleValue * W, g[1].doubleValue * H);
        CGFloat uw = u * s;
        c.rect = CGRectMake(ctr.x + c.off.x * uw - c.size.width * uw / 2, ctr.y + c.off.y * uw - c.size.height * uw / 2,
            c.size.width * uw, c.size.height * uw);
    }
    [self setNeedsDisplay];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self rebuild];
    _bar.frame = CGRectMake(0, self.safeAreaInsets.top, self.bounds.size.width, 44);
}

// ----- edit mode -----
- (UIButton *)barButton:(NSString *)t sel:(SEL)sel {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:t forState:UIControlStateNormal];
    b.backgroundColor = [UIColor colorWithWhite:0 alpha:0.7];
    b.layer.cornerRadius = 8;
    [b setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [b addTarget:self action:sel forControlEvents:UIControlEventTouchUpInside];
    return b;
}

- (void)setEditing:(BOOL)editing {
    _editing = editing;
    [_bar removeFromSuperview];
    _bar = nil;
    _selected = nil;
    if (editing) {
        UIStackView *st = [[UIStackView alloc] initWithArrangedSubviews:@[
            [self barButton:@"Done" sel:@selector(editDone)], [self barButton:@" − " sel:@selector(editSmaller)],
            [self barButton:@" + " sel:@selector(editBigger)], [self barButton:@"Opacity" sel:@selector(editOpacity)],
            [self barButton:@"Reset" sel:@selector(editReset)] ]];
        st.axis = UILayoutConstraintAxisHorizontal;
        st.distribution = UIStackViewDistributionFillEqually;
        st.spacing = 8;
        st.frame = CGRectMake(self.bounds.size.width * 0.2, self.safeAreaInsets.top + 4, self.bounds.size.width * 0.6, 36);
        _bar = st;
        [self addSubview:_bar];
    }
    [self setNeedsDisplay];
}
- (void)editDone { [self saveLayout]; self.editing = NO; if (self.onMenu) self.onMenu(); }
- (void)editReset { [self resetLayout]; }
- (void)editOpacity { _alpha = _alpha >= 0.85 ? 0.2 : _alpha + 0.15; [self setNeedsDisplay]; }
- (void)scaleSelected:(CGFloat)f {
    if (!_selected) return;
    NSMutableArray<NSNumber *> *g = _layout[_selected];
    g[2] = @(MIN(2.5, MAX(0.5, g[2].doubleValue * f)));
    [self relayout];
}
- (void)editSmaller { [self scaleSelected:0.9]; }
- (void)editBigger { [self scaleSelected:1.1]; }

// ----- hit testing / drawing -----
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    if (_editing) return v ?: self;
    if (v && v != self) return v;
    for (V3KControl *c in _controls)
        if (CGRectContainsPoint(CGRectInset(c.rect, -6, -6), point)) return self;
    return nil; // pass through to SDL (front touch)
}

- (void)drawRect:(CGRect)rect {
    CGContextRef g = UIGraphicsGetCurrentContext();
    for (V3KControl *c in _controls) {
        BOOL pressed = c.touch != nil;
        BOOL sel = _editing && [c.group isEqualToString:_selected];
        if (c.kind == V3KCtlStick) {
            CGContextSetFillColorWithColor(g, [UIColor colorWithWhite:1 alpha:_alpha * 0.25].CGColor);
            CGContextFillEllipseInRect(g, c.rect);
            CGContextSetStrokeColorWithColor(g, (sel ? UIColor.yellowColor : [UIColor colorWithWhite:1 alpha:_alpha * 0.8]).CGColor);
            CGContextStrokeEllipseInRect(g, c.rect);
            CGFloat r = c.rect.size.width * 0.22;
            CGPoint ctr = CGPointMake(CGRectGetMidX(c.rect) + c.stickOffset.x, CGRectGetMidY(c.rect) + c.stickOffset.y);
            CGContextSetFillColorWithColor(g, [UIColor colorWithWhite:1 alpha:_alpha * (pressed ? 1.2 : 0.7)].CGColor);
            CGContextFillEllipseInRect(g, CGRectMake(ctr.x - r, ctr.y - r, r * 2, r * 2));
            continue;
        }
        UIBezierPath *p = [UIBezierPath bezierPathWithRoundedRect:c.rect cornerRadius:MIN(c.rect.size.width, c.rect.size.height) * 0.35];
        [[UIColor colorWithWhite:1 alpha:_alpha * (pressed ? 1.0 : 0.4)] setFill];
        [p fill];
        [(sel ? UIColor.yellowColor : [UIColor colorWithWhite:1 alpha:_alpha * 0.9]) setStroke];
        p.lineWidth = sel ? 3 : 1;
        [p stroke];
        NSDictionary *attrs = @{ NSFontAttributeName : [UIFont boldSystemFontOfSize:MAX(9, MIN(c.rect.size.height * 0.5, 18))],
                                 NSForegroundColorAttributeName : [UIColor colorWithWhite:1 alpha:MIN(1, _alpha + 0.3)] };
        CGSize sz = [c.label sizeWithAttributes:attrs];
        [c.label drawAtPoint:CGPointMake(CGRectGetMidX(c.rect) - sz.width / 2, CGRectGetMidY(c.rect) - sz.height / 2) withAttributes:attrs];
    }
    if (_editing) {
        NSString *hint = @"Drag a control to move it • tap − / + to resize the selected one";
        NSDictionary *a = @{ NSFontAttributeName : [UIFont systemFontOfSize:13], NSForegroundColorAttributeName : UIColor.yellowColor };
        CGSize sz = [hint sizeWithAttributes:a];
        [hint drawAtPoint:CGPointMake((self.bounds.size.width - sz.width) / 2, self.safeAreaInsets.top + 46) withAttributes:a];
    }
}

- (V3KControl *)controlAt:(CGPoint)pt {
    for (V3KControl *c in [_controls reverseObjectEnumerator])
        if (CGRectContainsPoint(CGRectInset(c.rect, -6, -6), pt)) return c;
    return nil;
}

- (void)press:(V3KControl *)c touch:(UITouch *)t {
    c.touch = t;
    if (c.kind == V3KCtlButton) vjoy_button(c.button, true);
    else if (c.kind == V3KCtlMenu && self.onMenu) self.onMenu();
}
- (void)release:(V3KControl *)c {
    c.touch = nil;
    if (c.kind == V3KCtlButton) vjoy_button(c.button, false);
    if (c.kind == V3KCtlStick) {
        c.stickOffset = CGPointZero;
        vjoy_axis(c.axisX, 0);
        vjoy_axis(c.axisY, 0);
    }
}
- (void)updateStick:(V3KControl *)c at:(CGPoint)pt {
    CGPoint center = CGPointMake(CGRectGetMidX(c.rect), CGRectGetMidY(c.rect));
    CGFloat radius = c.rect.size.width / 2;
    CGFloat dx = pt.x - center.x, dy = pt.y - center.y, len = hypot(dx, dy);
    if (len > radius) { dx *= radius / len; dy *= radius / len; }
    c.stickOffset = CGPointMake(dx, dy);
    vjoy_axis(c.axisX, dx / radius);
    vjoy_axis(c.axisY, dy / radius);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    for (UITouch *t in touches) {
        CGPoint pt = [t locationInView:self];
        V3KControl *c = [self controlAt:pt];
        if (_editing) {
            if (c && !_dragTouch) {
                _selected = c.group;
                _dragTouch = t;
                _dragGroup = c.group;
                NSArray<NSNumber *> *g = _layout[c.group];
                _grab = CGPointMake(pt.x - g[0].doubleValue * self.bounds.size.width, pt.y - g[1].doubleValue * self.bounds.size.height);
            }
            continue;
        }
        if (!c || c.touch) continue;
        [self press:c touch:t];
        if (c.kind == V3KCtlStick) [self updateStick:c at:pt];
    }
    [self setNeedsDisplay];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    for (UITouch *t in touches) {
        CGPoint pt = [t locationInView:self];
        if (_editing) {
            if (t == _dragTouch && _dragGroup) {
                NSMutableArray<NSNumber *> *g = _layout[_dragGroup];
                g[0] = @(MIN(0.97, MAX(0.03, (pt.x - _grab.x) / self.bounds.size.width)));
                g[1] = @(MIN(0.97, MAX(0.03, (pt.y - _grab.y) / self.bounds.size.height)));
                [self relayout];
            }
            continue;
        }
        for (V3KControl *c in _controls)
            if (c.touch == t && c.kind == V3KCtlStick) [self updateStick:c at:pt];
    }
    [self setNeedsDisplay];
}

- (void)finish:(NSSet<UITouch *> *)touches {
    for (UITouch *t in touches) {
        if (t == _dragTouch) { _dragTouch = nil; _dragGroup = nil; }
        for (V3KControl *c in _controls)
            if (c.touch == t) [self release:c];
    }
    [self setNeedsDisplay];
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self finish:touches]; }
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self finish:touches]; }
@end

// ---------------------------------------------------------------------------------------------
// Frame host (Vulkan via MoltenVK on an SDL_MetalView)
// ---------------------------------------------------------------------------------------------
class IOSFrameHost final : public renderer::FrameHost {
public:
    void set(SDL_Window *window, SDL_MetalView view) {
        m_window = window;
        m_view = view;
        m_gl = nullptr;
    }
    void set_gl(SDL_Window *window, SDL_GLContext *ctx) {
        m_window = window;
        m_view = nullptr;
        m_gl = ctx;
    }
    renderer::DisplayHandle handle() const override {
        return renderer::MacOSDisplayHandle{ m_view };
    }
    int drawable_width() const override {
        int w = 960, h = 544;
        if (m_window) SDL_GetWindowSizeInPixels(m_window, &w, &h);
        return w;
    }
    int drawable_height() const override {
        int w = 960, h = 544;
        if (m_window) SDL_GetWindowSizeInPixels(m_window, &w, &h);
        return h;
    }
    std::vector<std::string> font_dirs() const override {
        return { "/System/Library/Fonts/", "/System/Library/Fonts/Core/", "/System/Library/Fonts/CoreUI/",
            "/System/Library/Fonts/LanguageSupport/", "/System/Library/Fonts/Cache/" };
    }
    // ---- OpenGL ES (only used when the OpenGL backend is selected) ----
    void *get_proc_address(const char *name) const override {
        return reinterpret_cast<void *>(SDL_GL_GetProcAddress(name));
    }
    unsigned int default_fbo() const override {
        if (!m_window) return 0;
        return (unsigned int)SDL_GetNumberProperty(SDL_GetWindowProperties(m_window), SDL_PROP_WINDOW_UIKIT_OPENGL_FRAMEBUFFER_NUMBER, 0);
    }
    bool make_current() override {
        if (!m_gl || !*m_gl) return false;
        return SDL_GL_MakeCurrent(m_window, *m_gl);
    }
    void done_current() override {
        if (m_gl) SDL_GL_MakeCurrent(m_window, nullptr);
    }
    void swap_buffers() override {
        if (m_gl) SDL_GL_SwapWindow(m_window);
    }
    bool set_vsync(bool enabled) override {
        return m_gl ? SDL_GL_SetSwapInterval(enabled ? 1 : 0) : false;
    }
    void prepare_for_render_thread() override {
        if (m_gl && *m_gl) SDL_GL_MakeCurrent(m_window, nullptr);
    }
    void destroy_render_context() override {
        if (!m_gl || !*m_gl) return;
        SDL_GL_DestroyContext(*m_gl);
        *m_gl = nullptr;
    }

private:
    SDL_Window *m_window = nullptr;
    SDL_MetalView m_view = nullptr;
    SDL_GLContext *m_gl = nullptr;
};

// ---------------------------------------------------------------------------------------------
// Game session (same flow as SDL_main in android/jni/main_android.cpp)
// ---------------------------------------------------------------------------------------------
static UIViewController *top_vc(UIWindow *w) {
    UIViewController *vc = w.rootViewController;
    while (vc.presentedViewController) vc = vc.presentedViewController;
    return vc;
}

static void run_game(const std::string &title_id) {
    auto *emuenv = g_emuenv.get();
    auto *session = g_controller.get();
    if (!emuenv || !session)
        return;

    diag("INFO", "launch.begin", "title_id=%s", title_id.c_str());
    if (!ios_jit_available()) {
        diag("FAIL", "launch.jit", "JIT memory is not available (MAP_JIT mmap fails and no debugger is attached) - the emulator cannot run games");
        g_launch_fail_msg = @"JIT is not enabled. Install with TrollStore, or enable JIT with StikDebug / AltJIT, then try again.";
        g_launch_failed = true;
        diag("INFO", "launch.end", "aborted before start (no JIT)");
        return;
    }
    diag("OK", "launch.jit", "JIT memory available (map_jit=%d)", ios_jit_use_map_jit());
    diag("INFO", "launch.memory", "ram_used=%lluMB ram_left=%lluMB (iOS kills the app when ram_left reaches 0)", mem_used_mb(), mem_left_mb());
    g_force_vulkan = false;
    g_active_game = [NSString stringWithUTF8String:title_id.c_str()];
    perf_reset();
    g_guest_base = (uintptr_t)emuenv->mem.memory.get();
    vm_watch_start();

    AppLaunchRequest launch_request{ .app_path = title_id };
    bool relaunch = false;

    do {
        relaunch = false;
        SDL_Window *window = nullptr;
        SDL_MetalView metal_view = nullptr;
        SDL_GLContext gl_ctx = nullptr;
        IOSFrameHost frame_host;
        V3KOverlayView *overlay = nil;
        std::optional<AppLaunchRequest> pending;

        auto cleanup = [&](app::AppSessionStopReason reason) {
            if (reason == app::AppSessionStopReason::LaunchFailure)
                g_launch_failed = true;
            diag(reason == app::AppSessionStopReason::LaunchFailure ? "FAIL" : "INFO", "launch.end", "stop reason=%d", (int)reason);
            perf_summary();
            detach_virtual_controller();
            if (overlay) {
                [overlay removeFromSuperview];
                overlay = nil;
            }
            session->stop(reason);
            if (emuenv->audio.adapter) {
                emuenv->audio.adapter.reset();
                emuenv->audio.audio_backend.clear();
            }
            // (ime::set_sdl_window is Android-only in this source tree; no native IME hook on iOS yet)
            if (metal_view) {
                SDL_Metal_DestroyView(metal_view);
                metal_view = nullptr;
            }
            if (gl_ctx) {
                SDL_GL_DestroyContext(gl_ctx);
                gl_ctx = nullptr;
            }
            if (window) {
                SDL_DestroyWindow(window);
                window = nullptr;
            }
            SDL_QuitSubSystem(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMEPAD | SDL_INIT_HAPTIC | SDL_INIT_SENSOR | SDL_INIT_CAMERA);
        };

        LOG_INFO("Booting game '{}'", launch_request.app_path);
        SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");

        if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMEPAD | SDL_INIT_HAPTIC | SDL_INIT_SENSOR | SDL_INIT_CAMERA)) {
            LOG_ERROR("SDL_Init failed: {}", SDL_GetError());
            diag("FAIL", "launch.sdl_init", "%s", SDL_GetError());
            cleanup(app::AppSessionStopReason::LaunchFailure);
            break;
        }
        diag("OK", "launch.sdl_init", "SDL video/audio/gamepad subsystems ready");
        refresh_controllers(emuenv->ctrl, *emuenv);

        if (!session->begin_launch(launch_request, launch_request.reason != AppLaunchReason::LoadExec)) {
            LOG_ERROR("Could not find app '{}' in apps list.", launch_request.app_path);
            diag("FAIL", "launch.begin_launch", "app '%s' not found in apps list", launch_request.app_path.c_str());
            cleanup(app::AppSessionStopReason::LaunchFailure);
            break;
        }

        diag("OK", "launch.begin_launch", "app found, config loaded");
        // per-app custom configs are loaded by begin_launch(); re-force the fault-free memory mapping afterwards
        emuenv->cfg.current_config.memory_mapping = "page-table";

        apply_settings(*emuenv);
        auto make_window = [&](bool gl) -> bool {
            // SDL3: SDL_WINDOW_METAL / SDL_WINDOW_VULKAN / SDL_WINDOW_OPENGL are mutually exclusive.
            // Vulkan (MoltenVK) draws into a CAMetalLayer, so it needs METAL only (not VULKAN).
            SDL_PropertiesID props = SDL_CreateProperties();
            SDL_SetStringProperty(props, SDL_PROP_WINDOW_CREATE_TITLE_STRING, "Vita3K");
            SDL_SetNumberProperty(props, SDL_PROP_WINDOW_CREATE_WIDTH_NUMBER, 960);
            SDL_SetNumberProperty(props, SDL_PROP_WINDOW_CREATE_HEIGHT_NUMBER, 544);
            if (gl) {
                SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
                SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
                SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0); // iOS maximum
                SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
                SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 0);
            }
            SDL_SetNumberProperty(props, SDL_PROP_WINDOW_CREATE_FLAGS_NUMBER,
                (gl ? SDL_WINDOW_OPENGL : SDL_WINDOW_METAL) | SDL_WINDOW_FULLSCREEN | SDL_WINDOW_HIGH_PIXEL_DENSITY);
            window = SDL_CreateWindowWithProperties(props);
            SDL_DestroyProperties(props);
            if (!window) {
                LOG_ERROR("SDL_CreateWindow failed: {}", SDL_GetError());
                diag("FAIL", "launch.window", "SDL_CreateWindow(%s): %s", gl ? "OpenGL ES" : "Metal", SDL_GetError());
                return false;
            }
            if (gl) {
                gl_ctx = SDL_GL_CreateContext(window);
                if (!gl_ctx) {
                    diag("FAIL", "launch.window", "SDL_GL_CreateContext(ES3.0): %s", SDL_GetError());
                    SDL_DestroyWindow(window);
                    window = nullptr;
                    return false;
                }
                frame_host.set_gl(window, &gl_ctx);
                diag("OK", "launch.window", "SDL window + OpenGL ES context created");
                return true;
            }
            metal_view = SDL_Metal_CreateView(window);
            if (!metal_view) {
                LOG_ERROR("SDL_Metal_CreateView failed: {}", SDL_GetError());
                diag("FAIL", "launch.window", "SDL_Metal_CreateView: %s", SDL_GetError());
                SDL_DestroyWindow(window);
                window = nullptr;
                return false;
            }
            frame_host.set(window, metal_view);
            diag("OK", "launch.window", "SDL window + Metal view created");
            return true;
        };
        const bool want_gl = emuenv->backend_renderer == renderer::Backend::OpenGL;
        bool window_ok = make_window(want_gl);
        if (!window_ok && want_gl) {
            diag("WARN", "launch.fallback", "OpenGL ES window failed -> falling back to Vulkan");
            g_force_vulkan = true;
            apply_settings(*emuenv);
            window_ok = make_window(false);
        }
        if (!window_ok) {
            cleanup(app::AppSessionStopReason::LaunchFailure);
            break;
        }

        // on-screen controller
        UIWindow *uiwin = (__bridge UIWindow *)SDL_GetPointerProperty(SDL_GetWindowProperties(window), SDL_PROP_WINDOW_UIKIT_WINDOW_POINTER, nullptr);
        __block bool menu_open = false;
        if (uiwin && uiwin.rootViewController) {
            overlay = [[V3KOverlayView alloc] initWithFrame:uiwin.rootViewController.view.bounds];
            __weak V3KOverlayView *weak_overlay = overlay;
            __block bool controls_hidden = false;
            overlay.onMenu = ^{
                if (menu_open) return;
                menu_open = true;
                session->set_pause_reason(app::AppSessionPauseReason::Menu, true);
                UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Vita3K" message:nil preferredStyle:UIAlertControllerStyleAlert];
                auto resume = ^{
                    menu_open = false;
                    session->set_pause_reason(app::AppSessionPauseReason::Menu, false);
                };
                [a addAction:[UIAlertAction actionWithTitle:@"Resume" style:UIAlertActionStyleDefault handler:^(UIAlertAction *) { resume(); }]];
                [a addAction:[UIAlertAction actionWithTitle:@"Edit Controls (drag to move)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *) {
                    // stay paused while editing; the editor's "Done" reopens this menu
                    weak_overlay.hidden = NO;
                    controls_hidden = false;
                    menu_open = false;
                    weak_overlay.editing = YES;
                }]];
                [a addAction:[UIAlertAction actionWithTitle:@"Show / Hide Controls" style:UIAlertActionStyleDefault handler:^(UIAlertAction *) {
                    controls_hidden = !controls_hidden;
                    weak_overlay.hidden = controls_hidden;
                    resume();
                }]];
                [a addAction:[UIAlertAction actionWithTitle:@"Quit Game" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *) {
                    resume();
                    SDL_Event quit{};
                    quit.type = SDL_EVENT_QUIT;
                    SDL_PushEvent(&quit);
                }]];
                [top_vc(uiwin) presentViewController:a animated:YES completion:nil];
            };
            [uiwin.rootViewController.view addSubview:overlay];
            attach_virtual_controller();
        }

        const bool using_gl = emuenv->backend_renderer == renderer::Backend::OpenGL;
        diag("INFO", "launch.renderer", "initialising renderer (%s)...", using_gl ? "OpenGL ES 3.0" : "Vulkan via MoltenVK");
        if (!session->initialize_renderer(frame_host)) {
            if (using_gl && !g_force_vulkan) {
                diag("WARN", "launch.fallback", "OpenGL ES renderer failed to initialise -> restarting with Vulkan");
                g_force_vulkan = true;
                relaunch = true;
                cleanup(app::AppSessionStopReason::Relaunch);
                continue;
            }
            LOG_ERROR("Failed to initialise renderer.");
            diag("FAIL", "launch.renderer", "initialize_renderer failed (see Vita3K.log; usually Vulkan/MoltenVK)");
            cleanup(app::AppSessionStopReason::LaunchFailure);
            break;
        }
        if (!session->initialize_runtime()) {
            LOG_ERROR("Failed late initialisation.");
            diag("FAIL", "launch.runtime", "initialize_runtime failed");
            cleanup(app::AppSessionStopReason::LaunchFailure);
            break;
        }
        if (!session->load_and_run()) {
            LOG_ERROR("Failed to load or start the app session.");
            diag("FAIL", "launch.load_and_run", "load_and_run failed (module loading / emulation start)");
            cleanup(app::AppSessionStopReason::LaunchFailure);
            break;
        }
        if (auto request = emuenv->take_app_launch_request())
            pending = std::move(request);

        LOG_INFO("Game started: {} ({})", emuenv->current_app_title, launch_request.app_path);
        diag("OK", "launch.running", "game started: %s (%s)", emuenv->current_app_title.c_str(), launch_request.app_path.c_str());
        app::LaunchRuntimeMetrics metrics{};

        install_crash_handlers();
        bool running = !pending.has_value();
        while (running) {
            SDL_Event event;
            while (SDL_PollEvent(&event)) {
                switch (event.type) {
                case SDL_EVENT_QUIT:
                case SDL_EVENT_WINDOW_CLOSE_REQUESTED:
                    running = false;
                    break;
                case SDL_EVENT_WILL_ENTER_BACKGROUND:
                    session->set_pause_reason(app::AppSessionPauseReason::Background, true);
                    break;
                case SDL_EVENT_DID_ENTER_FOREGROUND:
                    session->set_pause_reason(app::AppSessionPauseReason::Background, false);
                    break;
                case SDL_EVENT_FINGER_DOWN:
                case SDL_EVENT_FINGER_MOTION:
                case SDL_EVENT_FINGER_UP: {
                    handle_touch_event(emuenv->touch, event.tfinger);
                    auto &mouse = emuenv->ctrl.overlay_mouse;
                    mouse.x.store(event.tfinger.x * 960.f, std::memory_order_relaxed);
                    mouse.y.store(event.tfinger.y * 544.f, std::memory_order_relaxed);
                    mouse.pressed.store(event.type != SDL_EVENT_FINGER_UP, std::memory_order_relaxed);
                    break;
                }
                case SDL_EVENT_GAMEPAD_ADDED:
                case SDL_EVENT_GAMEPAD_REMOVED:
                    refresh_controllers(emuenv->ctrl, *emuenv);
                    break;
                case SDL_EVENT_GAMEPAD_TOUCHPAD_DOWN:
                case SDL_EVENT_GAMEPAD_TOUCHPAD_MOTION:
                case SDL_EVENT_GAMEPAD_TOUCHPAD_UP:
                    handle_touchpad_event(emuenv->touch, event.gtouchpad);
                    break;
                case SDL_EVENT_GAMEPAD_SENSOR_UPDATE:
                    handle_motion_event(*emuenv, event.gsensor.sensor, event.gsensor);
                    break;
                case SDL_EVENT_SENSOR_UPDATE:
                    handle_motion_event(*emuenv, SDL_GetSensorTypeForID(event.sensor.which), event.sensor);
                    break;
                default:
                    break;
                }
            }

            if (!pending) {
                if (auto request = emuenv->take_app_launch_request()) {
                    pending = std::move(request);
                    running = false;
                }
            }
            app::update_runtime_metrics(*emuenv, metrics);
            perf_tick(*emuenv);
            ime_prompt_tick(*emuenv);
            if (!session->is_running())
                running = false;
            if (running)
                SDL_Delay(16);
        }

        ime_keyboard_close();
        LOG_INFO("Shutting down game");
        diag("INFO", "launch.stopping", "shutting down game");
        if (pending) {
            launch_request = std::move(*pending);
            relaunch = true;
        }
        cleanup(relaunch ? app::AppSessionStopReason::Relaunch : app::AppSessionStopReason::UserRequest);
    } while (relaunch);
}

// ---------------------------------------------------------------------------------------------
// Launcher (UIKit)
// ---------------------------------------------------------------------------------------------
static void show_alert(UIViewController *vc, NSString *title, NSString *msg) {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [vc presentViewController:a animated:YES completion:nil];
}


static void share_file(UIViewController *from, NSString *path) {
    UIActivityViewController *av = [[UIActivityViewController alloc] initWithActivityItems:@[ [NSURL fileURLWithPath:path] ] applicationActivities:nil];
    av.popoverPresentationController.sourceView = from.view;
    av.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(from.view.bounds), CGRectGetMidY(from.view.bounds), 1, 1);
    [from presentViewController:av animated:YES completion:nil];
}
static NSString *last_crash_report_path() {
    NSString *dir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"Vita3K"];
    NSString *p = [dir stringByAppendingPathComponent:@"crash_report.txt"];
    return [[NSFileManager defaultManager] fileExistsAtPath:p] ? p : nil;
}

// ---------------------------------------------------------------------------------------------
// ZIP install helper: finds work.bin (licence) and an optional .pkg inside the archive
// ---------------------------------------------------------------------------------------------
struct ZipScan {
    std::vector<uint8_t> work_bin;
    std::string pkg_path; // extracted copy of the .pkg (in tmp), empty if the zip holds no pkg
    bool has_work_bin = false;
};
static bool zip_has_suffix(const std::string &name, const char *suf) {
    std::string n = name;
    std::transform(n.begin(), n.end(), n.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    const size_t l = strlen(suf);
    return n.size() >= l && n.compare(n.size() - l, l, suf) == 0;
}
static ZipScan scan_zip(const std::string &zip_path, const std::string &tmp_dir) {
    ZipScan r;
    mz_zip_archive z{};
    if (!mz_zip_reader_init_file(&z, zip_path.c_str(), 0)) {
        diag("WARN", "install.zip", "cannot open zip for scanning");
        return r;
    }
    const mz_uint n = mz_zip_reader_get_num_files(&z);
    int work_idx = -1, pkg_idx = -1;
    for (mz_uint i = 0; i < n; i++) {
        if (mz_zip_reader_is_file_a_directory(&z, i)) continue;
        char fname[1024];
        mz_zip_reader_get_filename(&z, i, fname, sizeof(fname));
        if (zip_has_suffix(fname, "work.bin")) work_idx = (int)i;
        else if (zip_has_suffix(fname, ".pkg")) pkg_idx = (int)i;
    }
    if (work_idx >= 0) {
        size_t sz = 0;
        void *buf = mz_zip_reader_extract_to_heap(&z, (mz_uint)work_idx, &sz, 0);
        if (buf) {
            r.work_bin.assign((uint8_t *)buf, (uint8_t *)buf + sz);
            mz_free(buf);
            r.has_work_bin = sz >= 0x50;
        }
    }
    if (pkg_idx >= 0) {
        const std::string out = tmp_dir + "/zip_install.pkg";
        if (mz_zip_reader_extract_to_file(&z, (mz_uint)pkg_idx, out.c_str(), 0)) r.pkg_path = out;
    }
    mz_zip_reader_end(&z);
    diag("INFO", "install.zip", "scan: work.bin=%s pkg=%s", r.has_work_bin ? "found" : "none", r.pkg_path.empty() ? "none" : "found");
    return r;
}
// work.bin is a PS Vita .rif: content id (e.g. UP0000-PCSE00000_00-XXXXXXXXXXXXXXXX) lives at offset 0x10
static std::string install_work_bin(const std::vector<uint8_t> &bin, const fs::path &vita_fs_path) {
    char cid[0x31] = {};
    memcpy(cid, bin.data() + 0x10, 0x30);
    const std::string content_id(cid);
    if (content_id.size() < 16) return {};
    const std::string title_id = content_id.substr(7, 9);
    const fs::path dir = vita_fs_path / "ux0/license" / title_id;
    try {
        fs::create_directories(dir);
    } catch (...) {
        return {};
    }
    FILE *f = fopen((dir / (content_id + ".rif")).string().c_str(), "wb");
    if (!f) return {};
    fwrite(bin.data(), 1, bin.size(), f);
    fclose(f);
    diag("OK", "install.license", "work.bin installed as ux0/license/%s/%s.rif", title_id.c_str(), content_id.c_str());
    return title_id;
}

#include "ios_ui.inc.mm"

// ---------------------------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------------------------
static void pump_runloop_until_launch() {
    while (!g_launch_title) {
        if (![[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:0.02]])
            [NSThread sleepForTimeInterval:0.01];
    }
}

static int ios_entry(int, char **) {
    @autoreleasepool {
        // MoltenVK location for SDL / Vulkan loader
        NSString *mvk = [[[NSBundle mainBundle] privateFrameworksPath] stringByAppendingPathComponent:@"MoltenVK.framework/MoltenVK"];
        if ([[NSFileManager defaultManager] fileExistsAtPath:mvk])
            setenv("SDL_VULKAN_LIBRARY", mvk.UTF8String, 1);
        setenv("MVK_CONFIG_LOG_LEVEL", "1", 0);
        // Fast-math in Metal shader compilation is a known cause of garbled geometry / stripes with translated shaders.
        setenv("MVK_CONFIG_FAST_MATH_ENABLED", [S(@"accmath") boolValue] ? "0" : "1", 1);
    }

    // Make the app's folder show up in the Files app: iOS only lists an app's Documents folder once it contains something,
    // so write a small marker file right at launch (before anything else can fail).
    @autoreleasepool {
        NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        NSString *readme = [docs stringByAppendingPathComponent:@"README.txt"];
        if (![[NSFileManager defaultManager] fileExistsAtPath:readme])
            [@"Vita3K data folder. Game data, config and logs live in the 'Vita3K' subfolder." writeToFile:readme atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [[NSFileManager defaultManager] createDirectoryAtPath:[docs stringByAppendingPathComponent:@"Vita3K"] withIntermediateDirectories:YES attributes:nil error:nil];
        diag_init([docs stringByAppendingPathComponent:@"Vita3K"]);
    }

    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidReceiveMemoryWarningNotification object:nil queue:nil
        usingBlock:^(NSNotification *) {
            diag("WARN", "memory_warning", "iOS memory warning! ram_used=%lluMB ram_left=%lluMB guest=%lluMB metal=%lluMB - jetsam may kill the app next",
                mem_used_mb(), mem_left_mb(), g_emuenv ? guest_resident_mb(*g_emuenv) : 0, metal_alloc_mb());
        }];
    std::set_terminate([]() {
        diag("FAIL", "terminate", "uncaught C++ exception / std::terminate");
        void *bt[48];
        const int c = backtrace(bt, 48);
        if (g_diag_fd >= 0) { backtrace_symbols_fd(bt, c, g_diag_fd); fsync(g_diag_fd); }
        abort();
    });
    SDL_SetMainReady();
    const bool jit_ok = ios_jit_try_enable(); // TrollStore / entitled builds can turn JIT on by themselves
    diag(jit_ok ? "OK" : "WARN", "jit", "available=%d map_jit=%d%s", (int)ios_jit_available(), ios_jit_use_map_jit(),
        jit_ok ? "" : " (games cannot start until JIT is enabled: TrollStore install, or StikDebug/AltJIT)");
    const bool ok = init_session();
    diag(ok ? "OK" : "FAIL", "init_session", "core %s", ok ? "initialised" : "FAILED to initialise");

    g_launcher_window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    g_launcher_window.rootViewController = v3k_make_root();
    [g_launcher_window makeKeyAndVisible];
    if (!ok)
        show_alert(g_launcher_window.rootViewController, @"Initialisation failed", @"Vita3K core could not start. See diagnostics.txt in the Vita3K folder (Files app).");

    while (true) {
        @autoreleasepool {
            g_launch_title = nil;
            pump_runloop_until_launch();
            NSString *tid = g_launch_title;
            g_launcher_window.hidden = YES;
            run_game(std::string(tid.UTF8String));
            g_active_game = nil;
            g_launcher_window.hidden = NO;
            [g_launcher_window makeKeyAndVisible];
            if (g_launch_failed) {
                g_launch_failed = false;
                show_alert(g_launcher_window.rootViewController, @"Could not start game", g_launch_fail_msg ?: @"See diagnostics.txt in the Vita3K folder for details.");
                g_launch_fail_msg = nil;
            }
            v3k_reload_games();
        }
    }
    return 0;
}

int main(int argc, char **argv) {
    return SDL_RunApp(argc, argv, ios_entry, nullptr);
}
