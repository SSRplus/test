#!/bin/bash
# usage: metal-shader-test.sh <patched_source_dir> <port_dir> <out_dir>
# Builds the Phase 1 unit test natively (macOS host), runs it, then compiles every generated MSL file with Apple's offline
# compiler for the iPhone SDK. Exit code != 0 on any failure. Steps that cannot run in the environment are reported as SKIPPED.
set -u
SRC="$1"; PORT="$2"; OUT="$3"
mkdir -p "$OUT"
rc=0

cmake -S "$PORT/metal/tests/metal_shader_test" -B "$OUT/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DVITA3K_SRC="$SRC" \
  -DCMAKE_POLICY_VERSION_MINIMUM=3.5 || { echo "TEST-BUILD: cmake configure FAILED"; exit 1; }
cmake --build "$OUT/build" || { echo "TEST-BUILD: compile FAILED"; exit 1; }

echo "=== run unit test"
"$OUT/build/metal_shader_test" "$OUT/msl" || rc=1

echo "=== offline MSL compile for iPhoneOS (xcrun metal)"
if ! xcrun -sdk iphoneos --find metal >/dev/null 2>&1; then
  echo "SKIPPED: 'metal' offline compiler not installed on this runner (generated MSL NOT verified for iOS)"
else
  for f in "$OUT"/msl/*.metal; do
    [ -f "$f" ] || continue
    for std in "metal3.0 16.4" "metal3.1 17.0"; do
      set -- $std
      if xcrun -sdk iphoneos metal -std="$1" -mios-version-min="$2" -fno-fast-math -Werror -c "$f" -o /tmp/msl_check.air 2>"$OUT/msl_err.txt"; then
        echo "OK   $(basename "$f")  -std=$1 (iOS $2+)"
      else
        echo "FAIL $(basename "$f")  -std=$1"; sed 's/^/     /' "$OUT/msl_err.txt" | head -20; rc=1
      fi
    done
  done
fi

echo "=== generated MSL (for the log)"
for f in "$OUT"/msl/*.metal; do [ -f "$f" ] && { echo "----- $(basename "$f")"; cat "$f"; }; done
[ $rc -eq 0 ] && echo "METAL-PHASE1: PASS" || echo "METAL-PHASE1: FAIL"
exit $rc
