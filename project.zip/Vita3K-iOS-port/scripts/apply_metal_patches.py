#!/usr/bin/env python3
"""Metal backend, Phase 1 (GXP -> SPIR-V -> MSL). Adds new files and two small CMake hunks to a Vita3K-Plus source tree.
Runs independently of apply_ios_patches.py (no overlapping hunks) and fails loudly if a hunk does not match.
Nothing under renderer/vulkan or shader/src/spirv_recompiler.cpp is touched: the Vulkan backend is unchanged."""
import os, shutil, sys

root, port = sys.argv[1], sys.argv[2]
failed = []

def edit(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding="utf-8").read()
    for i, (old, new) in enumerate(pairs):
        if s.count(old) != 1:
            failed.append(f"{rel} hunk#{i} (matches={s.count(old)}): {old[:70]!r}")
            continue
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8").write(s)

# 1. new sources
src = os.path.join(port, "metal", "shader")
for sub in ("include/shader", "src"):
    dst = os.path.join(root, "vita3k", "shader", sub)
    for f in os.listdir(os.path.join(src, sub)):
        shutil.copy(os.path.join(src, sub, f), os.path.join(dst, f))
        print("added vita3k/shader/%s/%s" % (sub, f))

# 2. SPIRV-Cross: the MSL backend is OFF in this tree. Turn it on for Apple platforms only.
edit("external/CMakeLists.txt", [
    ('option(SPIRV_CROSS_ENABLE_MSL "Enable MSL target support." OFF)\n',
     'if(APPLE)\n\tset(SPIRV_CROSS_ENABLE_MSL ON CACHE BOOL "Enable MSL target support." FORCE)\nendif()\n'
     'option(SPIRV_CROSS_ENABLE_MSL "Enable MSL target support." OFF)\n'),
])

# 3. shader library: compile + link the MSL translator on Apple platforms only (Linux/Windows/Android builds are untouched)
edit("vita3k/shader/CMakeLists.txt", [
    ("target_link_libraries(shader PRIVATE SPIRV spirv-cross-glsl)\n",
     "target_link_libraries(shader PRIVATE SPIRV spirv-cross-glsl)\n\n"
     "# Metal backend (GXP -> SPIR-V -> MSL)\n"
     "if(APPLE)\n"
     "\ttarget_sources(shader PRIVATE src/spirv_to_msl.cpp src/gxp_to_msl.cpp)\n"
     "\ttarget_link_libraries(shader PRIVATE spirv-cross-msl)\n"
     "\ttarget_compile_definitions(shader PUBLIC VITA3K_BACKEND_METAL=1)\n"
     "endif()\n"),
])

if failed:
    print("METAL PATCH FAILED:\n  " + "\n  ".join(failed))
    sys.exit(1)
print("metal phase 1 patches applied")
