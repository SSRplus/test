# Vita3K-Plus → iOS (16.4+)

## ใช้งาน (ทำจากมือถือได้ทั้งหมด)
1. อัปโหลด `Vita3K-iOS-port.zip` ไว้ที่ root ของ repo
2. ซอร์ส: อัปโหลด `Vita3K-Plus-master.zip` ไว้ที่ root  **หรือ** กด Run workflow แล้วใส่ลิงก์ในช่อง `source_url`
   (เช่น `https://github.com/OWNER/Vita3K-Plus/archive/refs/heads/master.zip`)
   ข้อจำกัด: อัปโหลดไฟล์ผ่านเว็บ GitHub ได้ไม่เกิน 25 MB ต่อไฟล์
3. สร้าง `.github/workflows/build-ios.yml` แล้ววางเนื้อหาจาก `build-ios.yml`
4. Actions > Build Vita3K iOS > Run workflow

## ถ้า build ไม่ผ่าน
- หน้า Actions > run > Summary มีรายการ error + log ท้ายของทุกขั้นตอน
- ไฟล์ `REPORT.md` และ `logs/` อยู่ที่ branch `build-logs` (เปิดอ่าน/คัดลอกบนมือถือได้) แล้วส่งให้ผมแก้

## ในแอป
- เมนูหลัก: ติดตั้ง Firmware (.PUP) ก่อน แล้วติดตั้งเกม (.pkg / .vpk / .zip) — ไฟล์เกมวางใน Files > Vita3K ได้
- ปุ่มควบคุมบนจอ: กด ☰ > "Edit Controls" แล้ว **ลากปุ่มไปวางตำแหน่งที่ต้องการ** ปุ่ม − / + ปรับขนาด, Opacity ปรับความโปร่งใส, Reset คืนค่าเดิม ระบบจำค่าไว้ให้
- Show / Hide Controls ซ่อนปุ่มเมื่อใช้จอยบลูทูธ

## JIT
- TrollStore (.tipa): แอปเปิด JIT ให้ตัวเอง (entitlements + ptrace attach) ถ้าไม่ติดให้เปิดด้วย StikDebug
- Sideload (.ipa): เปิดด้วย StikDebug / AltJIT / SideJITServer ก่อนเปิดเกม
- แอปบังคับใช้โหมดหน่วยความจำแบบ page-table (ไม่พึ่ง signal) เพื่อให้เสถียรตอนเปิด JIT ผ่าน debugger
- iOS 26+ ที่ใช้ระบบ JIT แบบใหม่ ยังไม่รองรับ

## v0.1.1
- แก้เกมไม่รัน: `SDL_WINDOW_METAL` + `SDL_WINDOW_VULKAN` ใช้พร้อมกันไม่ได้ใน SDL3 → ใช้ METAL อย่างเดียวสำหรับ Vulkan(MoltenVK)
- เพิ่มหน้า Settings (ปุ่ม Settings มุมซ้ายบน): Renderer Vulkan/OpenGL ES, ความละเอียด, filter, anisotropic, V-Sync, shader fix (accurate math, async compile, surface sync, SPIR-V), preset 4 แบบ, เสียง, คัดลอก diagnostics
- OpenGL ES 3.0 (ทดลอง): ถ้าเริ่มไม่ได้จะ fallback เป็น Vulkan อัตโนมัติ และบันทึกใน diagnostics
- diagnostics.txt ทุก 5 วินาที: fps, ram_used, ram_left (ก่อน jetsam), thermal, สถานะเสียง; มี memory warning + perf.summary ตอนจบเกม
- แก้ FAIL ปลอมใน diagnostics (if ไม่มีปีกกา), swapchain ใช้ BGRA บน iOS ลดสีเพี้ยน
- แรมพุ่ง/เกมเด้ง (jetsam): เอา `memory-mapping=page-table` ที่บังคับไว้ออก, เพิ่มตัวเลือก GPU memory mapping (ค่าเริ่มต้น Disabled = กินแรมน้อยสุด), ลด Vulkan stream buffer บน iOS จาก ~300MB เหลือ ~100MB
- คีย์บอร์ด iOS: เมื่อเกมขอพิมพ์ข้อความ (SceIme / IME dialog) คีย์บอร์ดระบบ iOS จะเด้งขึ้นมา พิมพ์เข้าเกมโดยตรง (ไม่มีกล่อง Text input แล้ว) กด return เพื่อยืนยัน ส่ง Enter ให้เกม แล้วคีย์บอร์ดจะปิดและไม่เด้งซ้ำ
- ติดตั้ง .zip: สแกนหา work.bin อัตโนมัติ (ทั้งแบบ zip ที่มี .pkg + work.bin และแบบเกมแตกไฟล์ + work.bin)
- Crash report: ถ้ารอบก่อนเกมเด้ง/โดน jetsam เปิดแอปรอบถัดไปจะแสดง "Crash detected" พร้อม title id/ชื่อเกม และปุ่ม Share log (ไฟล์ crash_report.txt รวม diagnostics + ท้าย Vita3K.log); แชร์ย้อนหลังได้ที่ Settings > Tools
- Log RAM แยกส่วน: `guest` (แรมเกมจำลอง) / `metal` (MoltenVK/GPU) / `other` (JIT, heap) ทุก 1 วินาทีใน 40 วินาทีแรกของเกม (ช่วงที่แรมพุ่ง)
- Crash guard: ดักสัญญาณ crash จริง (SEGV/BUS/TRAP/ABRT/ILL/FPE + C++ exception) เขียน `[CRASH] signal=…` พร้อม backtrace ลง diagnostics; ถ้าเทรลจบโดยไม่มีบรรทัดนี้ = iOS ฆ่าแอป (jetsam/watchdog) และ crash_report.txt จะมีบรรทัด Verdict บอกชัดเจน

## v0.1.2
- แรมพุ่งตอนเกมบูต (jetsam): ข้ามการเขียน 0xcc ทับ stack ของทุก thread เกม (patch #13 ใน apply_ios_patches.py)
- diagnostics: เพิ่ม `vm.snapshot` — ทุกครั้งที่แรมโต ≥150MB จะแจกแจงว่าแรมอยู่ที่ไหน (GUEST / malloc / EXEC-JIT / tag อื่น) ทั้ง dirty และ compressed ใช้หาตัวการที่ยังไม่รู้
- FPS overlay: เพิ่มบรรทัด `RAM: <ใช้อยู่> MB (left <เหลือ> MB)` (patch #14) — left คือแรมที่เหลือก่อน iOS ฆ่าแอป ค่าเข้า 0 = เด้ง; อัปเดตทุก 0.5 วิ; เปิดที่ Settings > FPS overlay in game (overlay จะโผล่เมื่อเกมเริ่มวาดเฟรมแล้วเท่านั้น)
- แก้ build ล้ม: `pages_dirty` -> `pages_dirtied` ใน vm.snapshot
- แก้ crash_report ระบุชื่อเกมผิด (เดิมเอาเกมแรกของไฟล์ ตอนนี้เอาเกมล่าสุด)


## v0.1.3
- แรมเกมบน iOS (patch #15 ใน apply_ios_patches.py): (1) ไม่เขียน 0 ทับทุกบล็อกแรมเกมตอนจอง (เดิมทำให้ทุกหน้าถูกใช้จริงทันที) (2) คืนแรมตอน free จริงด้วย mmap MAP_FIXED แทน madvise(MADV_DONTNEED) ที่บน Darwin ไม่คืนอะไรเลย
- diagnostics: บรรทัด `note` ทุกครั้งที่เกมจองบล็อก ≥2MB / free ≥2MB / สร้าง thread (พร้อม footprint ณ ตอนนั้น), perf มี `internal=` `compressed=`, vm.snapshot พิมพ์ `begin` ก่อนเดินแผนที่แรม


## v0.1.4 — ลดแรม (JIT code cache)
สาเหตุที่หาเจอจาก diagnostics ของ GOD EATER 2: Dynarmic จอง JIT code cache **128 MB ต่อทุก thread ของเกม** (Vita3K สร้าง JIT แยกต่อ thread) และ iOS นับเต็มเข้า footprint — ใน log แรมกระโดด ~116 MB ทุกครั้งที่เกมสร้าง thread (nus3::UpdateThread, Wordfilter ×10 ฯลฯ) จนชน ~2.1 GB แล้วโดน jetsam ภายใน ~8 วินาที (patch #16 ใน apply_ios_patches.py)
- ขนาด cache ต่อ thread ลดจาก 128 MB เป็น **16 MB** (thread หลักของเกม **64 MB**) ปรับได้ที่ Settings > "Memory (JIT)"
- Preset "Low RAM (avoid jetsam)" ใช้ main 32 MB / thread อื่น 8 MB (+ texture cache ปิด) — เหมาะกับเป้าหมาย ~1.5 GB
- Preset "Performance" ใช้ main 96 MB / thread อื่น 32 MB
- diagnostics: บรรทัด `jit.cache` ตอนเริ่มเกม (ขนาดที่ตั้ง) + `note jit.cache applied` ทุกครั้งที่สร้าง JIT พร้อม footprint — ถ้าเห็น `NOT-SUPPORTED(field missing)` แปลว่า Dynarmic fork ไม่มีฟิลด์ `code_cache_size` (แพตช์จะไม่มีผล ส่ง log กลับมาแก้ต่อ)
- ถ้าเกมช้า/กระตุกเป็นพิเศษหลังลดค่า = cache เต็มแล้วถูกล้างบ่อย ให้เพิ่มค่าทีละขั้น (16→32 MB สำหรับ thread อื่น, 64→96 MB สำหรับ thread หลัก)


## v0.1.5 — รวม UI ใหม่ (0.1.2 UI) + ระบบลดแรม (0.1.4)
- UI แบบ Vita3K Plus: แท็บ Games / Manage / Settings / Logs (ไฟล์ `ios/ios_ui.inc.mm`), ตั้งค่าแยกรายเกม (Custom config), Presets, Logs ค้นหา/กรองระดับ/แชร์
- คงระบบ 0.1.2–0.1.4 ทั้งหมด: ไม่เขียน 0xcc ทับ stack, RAM ใน FPS overlay, ลด guest RAM บน iOS, vm.snapshot, `note`/`jit.cache` diagnostics และ JIT code cache ต่อ thread (ย้ายตัวเลือก "Memory (JIT)" ไปอยู่ Settings > CPU; ค่าเก็บแยกรายเกมได้)
- ค่าเริ่มต้น log level = Info บน iOS

## v0.1.6 — แก้เกมเด้งตอนโหลดโมดูล (condition_variable)
- crash_report ของ GOD EATER 2 บน 0.1.5 ชี้ว่า**ไม่ใช่แรมแล้ว** (footprint ~850 MB เหลือ ~1.2 GB): `std::terminate` ใน `start_module` ← `run_guest_function` ← `status_cond.wait()` ด้วยข้อความ `condition_variable wait failed: Invalid argument`
- สาเหตุ: `ThreadState::status_cond` ถูก wait ด้วย mutex คนละตัว (ของ thread กับของ primitive) ซึ่ง Linux ยอม แต่ Darwin คืน EINVAL → patch #17 เปลี่ยนเป็น `std::condition_variable_any` บน iOS

## v0.1.7 — ภาพเพี้ยน (texture) + เกมปิดตัวตอนพิมพ์ชื่อ
- **ภาพเพี้ยน** (ลายสี่เหลี่ยมสีเต็มจอ / แผ่นดำใน UI ของ GOD EATER 2): Vita3K ใช้ตัวถอดรหัส PVRTC ของ GPU เองเฉพาะบน PowerVR แต่เช็กด้วยฟอร์แมตเดียว MoltenVK รายงานว่ารองรับ PVRTC1 บน Apple GPU จึงอัปโหลด PVRT ทั้ง 4 แบบแบบ native รวมถึง PVRTC2 ที่ Metal ไม่มีฟอร์แมตนี้เลย — patch #18 บังคับให้ iOS ถอดรหัส PVRT ด้วย software (ทางเดียวกับ GPU อื่นทุกตัว) พร้อมบรรทัด `note gpu.formats` ใน diagnostics
- **เกมปิดตัวเองตอนพิมพ์ข้อความ** (diagnostics: `ime game requested text input` ตามด้วย `std::terminate`, ข้อความ `basic_string`): หลัง `str.clear()` ค่า caret/preedit เก่ายังค้าง ทำให้ `ime_commit_text` โยน `std::out_of_range` — รีเซ็ตค่าก่อน และครอบ try/catch
- **กล่อง Text input เด้งซ้ำ / เกมไม่ยืนยันข้อความ**: เดิมใช้ UIAlertController และเปิดใหม่ทุกครั้งที่เกมยังเปิด IME อยู่ อีกทั้ง `ime.event_id` มีช่องเดียว สัญญาณ Enter ไปทับ UPDATE_TEXT ก่อนเกมอ่าน — เปลี่ยนเป็น UITextField ที่ซ่อนไว้ (พิมพ์เข้าเกมสดๆ ทุกตัวอักษร) + คิว event ส่งทีละอันหลังเกมอ่านอันก่อนหน้าแล้ว (`ime_queue_event` / `ime_pump_events`) และจำ session ไม่ให้คีย์บอร์ดเด้งซ้ำหลังกด return

## v0.1.8 — กด Done แล้วเกมไม่รับข้อความ / ช่องพิมพ์ไม่ปิด / เกมค้าง
- สาเหตุจาก log ของ GOD EATER 2: เกม**อ่าน** `PRESS_ENTER` แล้ว แต่ไม่ปิดช่องพิมพ์ (ไม่เรียก sceImeClose) แอปเดิมเลยส่ง `PRESS_CLOSE` เป็นครั้งที่ 3 ซึ่งเกมถือว่า "ยกเลิก" → ช่องหาย ข้อความถูกทิ้ง เกมค้าง
- เลิกส่ง `PRESS_CLOSE` แล้ว ลำดับใหม่: `UPDATE_TEXT` (ข้อความสุดท้าย) → `PRESS_ENTER` → ถ้าเกมอ่านแล้วยังไม่ปิดใน 1 วิ ส่ง `UPDATE_TEXT`+`PRESS_ENTER` อีกรอบ → ถ้ายังไม่ปิด แอปปิด IME ฝั่ง emulator เองเหมือน sceImeClose (ข้อความอยู่ใน buffer ของเกมแล้ว) แทนการยกเลิก
- `PRESS_ENTER` ต่อคิวหลัง `UPDATE_TEXT` ไม่เขียนทับ; Done จะ commit ตัวอักษรที่กำลังประกอบ (ไทย/ญี่ปุ่น) ก่อน; ไม่ส่ง UPDATE_TEXT ซ้ำถ้าข้อความไม่เปลี่ยน
- patch #19: `Ime::open_serial` นับทุก sceImeOpen / sceImeDialogInit ใช้แยกรอบการเปิด IME (เดิมใช้ที่อยู่ buffer ซึ่งถูกใช้ซ้ำ)
- diagnostics.txt (เขียนทันที ไม่หายตอนแอปโดนฆ่า): บรรทัด `ime.game` แสดงสิ่งที่เกมเรียกจริง — sceImeOpen (maxLen/type/option/enterLabel), sceImeClose, sceImeSetText/SetCaret/SetPreeditGeometry, การส่ง PRESS_ENTER เข้า handler และผลหลัง handler กลับ (`ime still open=0/1`) + บรรทัด `ime` ฝั่ง iOS

## v0.1.9 — กด Done ส่ง Enter แบบเดียวกับ Vita3K Plus Android
- เส้นทาง `sceImeOpen`: กด Done แล้วตั้ง `PRESS_ENTER` ตรงๆ (เหมือน `submit_current_ime` ฝั่ง Android) `sceImeUpdate` ก๊อปข้อความล่าสุดเข้า event ให้เอง จึงไม่ต้องรอคิว
- เลิกส่ง Enter ซ้ำ และเลิกปิด IME ฝั่ง emulator แทนเกม ให้เกมเรียก `sceImeClose` เอง
- IME dialog เหมือนเดิม (ตรงกับ Android อยู่แล้ว)
- v0.1.9: diagnostics.txt บรรทัด `ime.game` ตอนนี้บันทึก **ทุก** event ที่ส่งเข้าเกม (id, ความยาวข้อความ, caret, preedit, editIndex) ไม่ใช่แค่ Enter/Close; เลขเวอร์ชันในแอป = 0.1.9 (ถ้า log ยังเขียน version=0.1.8 แปลว่ายังเป็น build เก่า)
- v0.1.9 (ทดลอง): ถ้าเกมอ่าน PRESS_ENTER แล้วยังไม่ปิดช่องพิมพ์ใน 0.25 วิ แอปส่ง PRESS_CLOSE ตามหลัง (ตอนนี้ข้อความถูกส่งเข้าเกมครบแล้ว ต่างจาก v0.1.7 ที่ Enter ทับข้อความ) ถ้ายังไม่ปิดอีกค่อยแตะ ✕ หนึ่งครั้ง; diagnostics: `EXPERIMENT: ...`

## v0.1.9
- ช่องพิมพ์เป็นกล่องสีขาวที่มองเห็นได้ (ใต้ปุ่มเมนู เหนือคีย์บอร์ด) อยู่ตลอดที่เกมขอพิมพ์ แตะกล่องเพื่อเรียกคีย์บอร์ดกลับมา กล่องหายเมื่อเกมปิดช่องพิมพ์
- ระบบกด Done เดิมของ v0.1.8 (คิว event, ส่ง Enter ซ้ำ, ปิดฝั่ง emulator) กลับมาเหมือนเดิมทั้งหมด
- diagnostics.txt บรรทัด `ime.game` บันทึกทุก event ที่ส่งเข้าเกม (id, ความยาวข้อความ, caret, preedit, editIndex); เลขเวอร์ชัน = 0.1.9

## Metal backend (เริ่มทำ — Phase 1)
ดู `README-backend-metal.md` (อยู่ในโฟลเดอร์ Vita3K-iOS-port) — Phase 1 = GXP → SPIR-V → MSL + unit test ใน CI
