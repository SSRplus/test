// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include <shader/spirv_to_msl.h>

#include <spirv_msl.hpp>

#include <cstdio>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <sstream>

namespace shader::msl {

Result translate(const std::vector<uint32_t> &spirv, const Options &options) {
    Result result;

    if (spirv.size() < 5 || spirv[0] != 0x07230203u) {
        result.error = "not a SPIR-V binary";
        return result;
    }

    try {
        spirv_cross::CompilerMSL compiler(spirv);

        const auto entry_points = compiler.get_entry_points_and_stages();
        if (entry_points.size() != 1) {
            result.error = "expected exactly one entry point, found " + std::to_string(entry_points.size());
            return result;
        }
        const auto &entry = entry_points[0];
        result.is_fragment = (entry.execution_model == spv::ExecutionModelFragment);

        spirv_cross::CompilerMSL::Options msl_options;
        msl_options.platform = options.ios ? spirv_cross::CompilerMSL::Options::iOS : spirv_cross::CompilerMSL::Options::macOS;
        msl_options.msl_version = spirv_cross::CompilerMSL::Options::make_msl_version(options.msl_major, options.msl_minor);
        msl_options.enable_decoration_binding = true;
        msl_options.argument_buffers = false;
        msl_options.use_framebuffer_fetch_subpasses = options.framebuffer_fetch && options.ios;
        // NOTE: deliberately NO fast-math switch here. Fast math is a property of MTLCompileOptions at pipeline creation time
        // (Phase 3), where it is set to NO / MTLMathModeSafe. SPIRV-Cross keeps NoContraction/Invariant decorations as-is.
        compiler.set_msl_options(msl_options);

        // explicit (set, binding) -> Metal slot mapping, see header
        const spirv_cross::ShaderResources resources = compiler.get_shader_resources();
        auto add_binding = [&](const spirv_cross::Resource &res, bool is_buffer, bool is_texture, bool is_sampler) {
            const uint32_t set = compiler.get_decoration(res.id, spv::DecorationDescriptorSet);
            const uint32_t binding = compiler.get_decoration(res.id, spv::DecorationBinding);
            spirv_cross::MSLResourceBinding rb{};
            rb.stage = entry.execution_model;
            rb.desc_set = set;
            rb.binding = binding;
            if (is_buffer)
                rb.msl_buffer = buffer_slot(set, binding);
            if (is_texture)
                rb.msl_texture = texture_slot(set, binding);
            if (is_sampler)
                rb.msl_sampler = texture_slot(set, binding);
            compiler.add_msl_resource_binding(rb);
        };
        for (const auto &r : resources.uniform_buffers)
            add_binding(r, true, false, false);
        for (const auto &r : resources.storage_buffers)
            add_binding(r, true, false, false);
        for (const auto &r : resources.sampled_images)
            add_binding(r, false, true, true);
        for (const auto &r : resources.separate_images)
            add_binding(r, false, true, false);
        for (const auto &r : resources.separate_samplers)
            add_binding(r, false, false, true);
        for (const auto &r : resources.storage_images)
            add_binding(r, false, true, false);
        // subpass inputs are intentionally not bound: they become [[color(n)]] framebuffer fetch (see Options::framebuffer_fetch)

        result.source = compiler.compile();
        result.entry_point = compiler.get_cleansed_entry_point_name(entry.name, entry.execution_model);
        result.ok = !result.source.empty();
        if (!result.ok)
            result.error = "SPIRV-Cross returned an empty MSL source";
    } catch (const std::exception &e) {
        result.ok = false;
        result.source.clear();
        result.error = std::string("SPIRV-Cross: ") + e.what();
    }
    return result;
}

std::string spirv_to_msl(const std::vector<uint32_t> &spirv, std::string *error) {
    Result r = translate(spirv);
    if (!r.ok) {
        if (error)
            *error = r.error;
        return {};
    }
    return std::move(r.source);
}

// ------------------------------------------------------------------ SourceCache

namespace fs = std::filesystem;

SourceCache::SourceCache(std::string directory, std::string salt)
    : directory_(std::move(directory))
    , salt_(std::move(salt)) {
    for (char &c : salt_) // the salt is parsed back with operator>>, it must not contain whitespace
        if (c == ' ' || c == '\n' || c == '\t' || c == '\r')
            c = '_';
    std::error_code ec;
    fs::create_directories(directory_, ec);
}

// file layout: "V3KMSL <version> <salt>\n<entry_point> <is_fragment>\n<msl source...>"
bool SourceCache::load(const std::string &shader_hash, Result &out) const {
    std::ifstream in(fs::path(directory_) / (shader_hash + ".msl"), std::ios::binary);
    if (!in)
        return false;

    std::string magic, version, salt;
    in >> magic >> version >> salt;
    if (!in || magic != "V3KMSL" || version != std::to_string(SOURCE_CACHE_VERSION) || salt != salt_)
        return false;

    std::string entry;
    int is_fragment = 0;
    in >> entry >> is_fragment;
    if (!in || entry.empty())
        return false;
    in.get(); // newline after the header

    std::string source((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    if (source.empty())
        return false;

    out.ok = true;
    out.source = std::move(source);
    out.entry_point = std::move(entry);
    out.is_fragment = is_fragment != 0;
    out.error.clear();
    return true;
}

void SourceCache::store(const std::string &shader_hash, const Result &result) const {
    if (!result.ok)
        return;
    const fs::path final_path = fs::path(directory_) / (shader_hash + ".msl");
    const fs::path tmp_path = fs::path(directory_) / (shader_hash + ".msl.tmp");
    {
        std::ofstream out(tmp_path, std::ios::binary | std::ios::trunc);
        if (!out)
            return;
        out << "V3KMSL " << SOURCE_CACHE_VERSION << ' ' << salt_ << '\n'
            << result.entry_point << ' ' << (result.is_fragment ? 1 : 0) << '\n'
            << result.source;
        if (!out)
            return;
    }
    std::error_code ec;
    fs::rename(tmp_path, final_path, ec); // atomic replace: a crash never leaves a half-written entry
    if (ec)
        fs::remove(tmp_path, ec);
}

} // namespace shader::msl
