// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include <shader/gxp_to_msl.h>

#include <util/log.h>

namespace shader {

FeatureState metal_feature_profile(FeatureState base) {
    base.direct_fragcolor = true;
    base.support_shader_interlock = false;
    base.support_texture_barrier = false;
    base.enable_memory_mapping = false;
    base.support_scaled_attribute_formats = false;
    base.spirv_shader = false;
    return base;
}

msl::Result convert_gxp_to_msl(const SceGxmProgram &program, const std::string &shader_hash, const FeatureState &metal_features, const Hints &hints,
    bool maskupdate, bool force_shader_debug, const std::function<bool(const std::string &ext, const std::string &dump)> &dumper) {
    // the same recompiler as the Vulkan backend: bit-identical SPIR-V semantics, only the last step differs
    GeneratedShader generated = convert_gxp(program, shader_hash, metal_features, Target::SpirVVulkan, hints, maskupdate, force_shader_debug, dumper);

    msl::Result result = msl::translate(generated.spirv);
    if (!result.ok) {
        LOG_ERROR("SPIR-V -> MSL failed for shader {}: {}", shader_hash, result.error);
        return result;
    }

    if (dumper)
        dumper(program.is_fragment() ? "frag.metal" : "vert.metal", result.source);

    return result;
}

} // namespace shader
