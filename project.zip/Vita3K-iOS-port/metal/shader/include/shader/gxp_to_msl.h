// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#pragma once

#include <shader/spirv_recompiler.h>
#include <shader/spirv_to_msl.h>

namespace shader {

// Feature profile of the Metal backend. Mirrors what the Vulkan backend ends up with on MoltenVK:
//  - programmable blending goes through the subpass input (direct_fragcolor) which SPIRV-Cross turns into [[color(0)]]
//  - no shader interlock / texture barrier (they do not exist in Metal)
//  - no GPU memory mapping yet (Vulkan-only buffer device address path)
//  - Metal has no "scaled" vertex attribute formats, the shader converts integers itself (Hints::attributes)
FeatureState metal_feature_profile(FeatureState base);

// GXP -> SPIR-V (Vulkan flavour) -> MSL
msl::Result convert_gxp_to_msl(const SceGxmProgram &program, const std::string &shader_hash, const FeatureState &metal_features, const Hints &hints,
    bool maskupdate = false, bool force_shader_debug = false,
    const std::function<bool(const std::string &ext, const std::string &dump)> &dumper = nullptr);

} // namespace shader
