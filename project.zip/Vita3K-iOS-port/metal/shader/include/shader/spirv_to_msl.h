// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#pragma once

// SPIR-V (Vulkan flavour, as produced by shader::convert_gxp with Target::SpirVVulkan) -> Metal Shading Language.
// This header only depends on the standard library so that it can be unit tested without the rest of Vita3K.

#include <cstdint>
#include <string>
#include <vector>

namespace shader::msl {

// ---------------------------------------------------------------------------------------------------------------------
// Fixed Metal argument-table layout shared by the shader translator and the Metal pipeline code (Phase 3).
//
// The Vulkan SPIR-V uses descriptor sets (see spirv_recompiler.cpp):
//   set 0: binding 0 = vertex render-info UBO, 1 = fragment render-info UBO, 2 = vertex SSBO, 3 = fragment SSBO
//   set 1: binding 0 = last_frag_data subpass input (-> framebuffer fetch), binding 1 = mask texture
//   set 2: vertex textures   (binding = gxm texture unit)
//   set 3: fragment textures (binding = gxm texture unit)
// Metal has one flat table per resource kind and per stage, so every (set, binding) is mapped explicitly.
// ---------------------------------------------------------------------------------------------------------------------

// buffers (UBO / SSBO / push constants): [[buffer(set * BUFFERS_PER_SET + binding)]]  ->  set 0 gives slots 0..3
inline constexpr uint32_t BUFFERS_PER_SET = 4;
// Vertex stream buffers set in MTLVertexDescriptor.layouts[] MUST start here so they never alias a uniform/storage buffer slot.
inline constexpr uint32_t VERTEX_STREAM_BUFFER_BASE = 16;
// textures / samplers: sets 2 (vertex) and 3 (fragment) use [[texture(binding)]] / [[sampler(binding)]] (separate table per stage).
// any other set is placed after the 16 gxm texture units: slot = TEXTURE_AUX_BASE + set * 4 + binding
inline constexpr uint32_t TEXTURE_AUX_BASE = 16;

inline constexpr uint32_t buffer_slot(uint32_t set, uint32_t binding) {
    return set * BUFFERS_PER_SET + binding;
}
inline constexpr uint32_t texture_slot(uint32_t set, uint32_t binding) {
    return (set == 2 || set == 3) ? binding : TEXTURE_AUX_BASE + set * 4 + binding;
}

struct Options {
    bool ios = true; // MSL platform: iOS (true) or macOS (false)
    uint32_t msl_major = 3; // target MSL version. 3.1 == MTLLanguageVersion3_1 (iOS 17+); on iOS 16.x the runtime must pass 3.0 (see README)
    uint32_t msl_minor = 1;
    // map the Vulkan subpass input (last_frag_data, used for GXM programmable blending) to [[color(0)]] framebuffer fetch
    bool framebuffer_fetch = true;
};

struct Result {
    bool ok = false;
    std::string source; // MSL source
    std::string entry_point; // name of the entry function in `source` ("main" is reserved in MSL, SPIRV-Cross renames it)
    bool is_fragment = false;
    std::string error; // filled when ok == false
};

Result translate(const std::vector<uint32_t> &spirv, const Options &options = {});

// Convenience wrapper with the requested signature. Returns an empty string on failure (the reason is written to *error if given).
std::string spirv_to_msl(const std::vector<uint32_t> &spirv, std::string *error = nullptr);

// ---------------------------------------------------------------------------------------------------------------------
// Persistent MSL source cache (separate from the Vulkan SPIR-V cache). Only used to skip SPIR-V -> MSL; the compiled
// GPU binaries live in the MTLBinaryArchive (Phase 3).
// ---------------------------------------------------------------------------------------------------------------------
class SourceCache {
public:
    // `directory` is created if needed. `salt` must change whenever the SPIR-V producer or the translator options change
    // (e.g. shader::CURRENT_VERSION combined with SOURCE_CACHE_VERSION).
    SourceCache(std::string directory, std::string salt);

    // returns false if no valid entry exists
    bool load(const std::string &shader_hash, Result &out) const;
    void store(const std::string &shader_hash, const Result &result) const;

    static constexpr uint32_t SOURCE_CACHE_VERSION = 1;

private:
    std::string directory_;
    std::string salt_;
};

} // namespace shader::msl
