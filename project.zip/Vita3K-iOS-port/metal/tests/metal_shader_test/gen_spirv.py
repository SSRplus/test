#!/usr/bin/env python3
"""Hand-assembles the tiny Vulkan-flavoured SPIR-V 1.0 modules used by the unit test (no glslang needed).
Output: test_spirv.h  (re-generate with: python3 gen_spirv.py > test_spirv.h)"""
import struct, sys

OP = dict(Capability=17, MemoryModel=14, EntryPoint=15, ExecutionMode=16, Decorate=71, TypeVoid=19, TypeFloat=22,
          TypeVector=23, TypeFunction=33, TypePointer=32, Variable=59, Function=54, Label=248, Load=61, Store=62,
          Return=253, FunctionEnd=56, Constant=43, ConstantComposite=44, TypeImage=25, TypeSampledImage=27,
          ImageSampleImplicitLod=87)

def s(text):
    b = text.encode() + b"\0"
    b += b"\0" * (-len(b) % 4)
    return list(struct.unpack("<%dI" % (len(b) // 4), b))

class M:
    def __init__(self):
        self.head, self.decl, self.body = [], [], []
        self.bound = 1
    def id(self):
        i = self.bound; self.bound += 1; return i
    def ins(self, lst, op, *words):
        w = []
        for x in words:
            w += x if isinstance(x, list) else [x]
        lst.append(((len(w) + 1) << 16) | OP[op]); lst.extend(w)
    def words(self):
        return [0x07230203, 0x00010000, 0, self.bound, 0] + self.head + self.decl + self.body

def f32(x): return struct.unpack("<I", struct.pack("<f", x))[0]

def vertex_passthrough():
    m = M()
    void, fn, flt, v4, pin, pout, main, vin, vout, lbl, ld = [m.id() for _ in range(11)]
    m.ins(m.head, "Capability", 1)
    m.ins(m.head, "MemoryModel", 0, 1)
    m.ins(m.head, "EntryPoint", 0, main, s("main"), vin, vout)          # Vertex
    m.ins(m.decl, "Decorate", vin, 30, 0)                                # Location 0
    m.ins(m.decl, "Decorate", vout, 11, 0)                               # BuiltIn Position
    m.ins(m.decl, "TypeVoid", void)
    m.ins(m.decl, "TypeFunction", fn, void)
    m.ins(m.decl, "TypeFloat", flt, 32)
    m.ins(m.decl, "TypeVector", v4, flt, 4)
    m.ins(m.decl, "TypePointer", pin, 1, v4)                             # Input
    m.ins(m.decl, "TypePointer", pout, 3, v4)                            # Output
    m.ins(m.decl, "Variable", pin, vin, 1)
    m.ins(m.decl, "Variable", pout, vout, 3)
    m.ins(m.body, "Function", void, main, 0, fn)
    m.ins(m.body, "Label", lbl)
    m.ins(m.body, "Load", v4, ld, vin)
    m.ins(m.body, "Store", vout, ld)
    m.ins(m.body, "Return")
    m.ins(m.body, "FunctionEnd")
    return m.words()

def fragment_solid(color=(0.25, 0.5, 0.75, 1.0)):
    m = M()
    void, fn, flt, v4, pout, main, out, lbl = [m.id() for _ in range(8)]
    cs = [m.id() for _ in range(4)]; cc = m.id()
    m.ins(m.head, "Capability", 1)
    m.ins(m.head, "MemoryModel", 0, 1)
    m.ins(m.head, "EntryPoint", 4, main, s("main"), out)                 # Fragment
    m.ins(m.head, "ExecutionMode", main, 7)                              # OriginUpperLeft
    m.ins(m.decl, "Decorate", out, 30, 0)
    m.ins(m.decl, "TypeVoid", void)
    m.ins(m.decl, "TypeFunction", fn, void)
    m.ins(m.decl, "TypeFloat", flt, 32)
    m.ins(m.decl, "TypeVector", v4, flt, 4)
    m.ins(m.decl, "TypePointer", pout, 3, v4)
    for c, v in zip(cs, color):
        m.ins(m.decl, "Constant", flt, c, f32(v))
    m.ins(m.decl, "ConstantComposite", v4, cc, *cs)
    m.ins(m.decl, "Variable", pout, out, 3)
    m.ins(m.body, "Function", void, main, 0, fn)
    m.ins(m.body, "Label", lbl)
    m.ins(m.body, "Store", out, cc)
    m.ins(m.body, "Return")
    m.ins(m.body, "FunctionEnd")
    return m.words()

def fragment_texture():
    """set 3 / binding 2 combined image sampler, uv at location 4 (like Vita3K's fragTex_ / v_TexCoord0)"""
    m = M()
    void, fn, flt, v2, v4, pin2, pout4, pimg, main, uv, out, tex, lbl = [m.id() for _ in range(13)]
    img, simg, ld_tex, ld_uv, res = [m.id() for _ in range(5)]
    m.ins(m.head, "Capability", 1)
    m.ins(m.head, "MemoryModel", 0, 1)
    m.ins(m.head, "EntryPoint", 4, main, s("main"), uv, out)
    m.ins(m.head, "ExecutionMode", main, 7)
    m.ins(m.decl, "Decorate", uv, 30, 4)
    m.ins(m.decl, "Decorate", out, 30, 0)
    m.ins(m.decl, "Decorate", tex, 34, 3)                                # DescriptorSet 3
    m.ins(m.decl, "Decorate", tex, 33, 2)                                # Binding 2
    m.ins(m.decl, "TypeVoid", void)
    m.ins(m.decl, "TypeFunction", fn, void)
    m.ins(m.decl, "TypeFloat", flt, 32)
    m.ins(m.decl, "TypeVector", v2, flt, 2)
    m.ins(m.decl, "TypeVector", v4, flt, 4)
    m.ins(m.decl, "TypePointer", pin2, 1, v2)
    m.ins(m.decl, "TypePointer", pout4, 3, v4)
    m.ins(m.decl, "TypeImage", img, flt, 1, 0, 0, 0, 1, 0)               # 2D, sampled, unknown format
    m.ins(m.decl, "TypeSampledImage", simg, img)
    m.ins(m.decl, "TypePointer", pimg, 0, simg)                          # UniformConstant
    m.ins(m.decl, "Variable", pin2, uv, 1)
    m.ins(m.decl, "Variable", pout4, out, 3)
    m.ins(m.decl, "Variable", pimg, tex, 0)
    m.ins(m.body, "Function", void, main, 0, fn)
    m.ins(m.body, "Label", lbl)
    m.ins(m.body, "Load", simg, ld_tex, tex)
    m.ins(m.body, "Load", v2, ld_uv, uv)
    m.ins(m.body, "ImageSampleImplicitLod", v4, res, ld_tex, ld_uv)
    m.ins(m.body, "Store", out, res)
    m.ins(m.body, "Return")
    m.ins(m.body, "FunctionEnd")
    return m.words()

def emit(name, w):
    print("static const std::vector<uint32_t> %s = {" % name)
    for i in range(0, len(w), 8):
        print("    " + ", ".join("0x%08x" % x for x in w[i:i + 8]) + ",")
    print("};\n")

print("// generated by gen_spirv.py - do not edit\n#pragma once\n#include <cstdint>\n#include <vector>\n")
emit("SPIRV_VERTEX_PASSTHROUGH", vertex_passthrough())
emit("SPIRV_FRAGMENT_SOLID", fragment_solid())
emit("SPIRV_FRAGMENT_TEXTURE", fragment_texture())
