// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


// Phase 1 unit test for SPIR-V -> MSL. Run on a macOS host (CI) - it does not need Vita3K itself.
//   metal_shader_test <output_dir>
// Writes the generated MSL (iOS flavour) to <output_dir>/*.metal so that the CI script can additionally compile them with
// `xcrun -sdk iphoneos metal -std=metal3.1`, and renders with the real Metal runtime when a GPU is available.

#import <Foundation/Foundation.h>
#import <Metal/Metal.h>

#include <shader/spirv_to_msl.h>

#include "test_spirv.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>

static int g_failures = 0;
static int g_skipped = 0;

#define CHECK(cond, ...)                                  \
    do {                                                  \
        if (!(cond)) {                                    \
            ++g_failures;                                 \
            std::printf("  FAIL %s:%d  ", __FILE__, __LINE__); \
            std::printf(__VA_ARGS__);                     \
            std::printf("\n");                            \
        }                                                 \
    } while (0)

static bool contains(const std::string &s, const char *needle) {
    return s.find(needle) != std::string::npos;
}

static void write_file(const std::filesystem::path &p, const std::string &text) {
    std::ofstream(p, std::ios::binary) << text;
}

static shader::msl::Result translate_checked(const char *name, const std::vector<uint32_t> &spirv, bool ios) {
    shader::msl::Options opt;
    opt.ios = ios;
    shader::msl::Result r = shader::msl::translate(spirv, opt);
    std::printf("[%s] ios=%d ok=%d entry=%s fragment=%d\n", name, ios, r.ok, r.entry_point.c_str(), r.is_fragment);
    CHECK(r.ok, "translate failed: %s", r.error.c_str());
    if (!r.ok)
        std::printf("%s\n", r.error.c_str());
    return r;
}

static void test_translation(const std::filesystem::path &out_dir) {
    auto vs = translate_checked("vertex_passthrough", SPIRV_VERTEX_PASSTHROUGH, true);
    CHECK(!vs.is_fragment, "vertex shader reported as fragment");
    CHECK(contains(vs.source, "[[position]]"), "missing [[position]]");
    CHECK(contains(vs.source, "[[attribute(0)]]"), "missing [[attribute(0)]] (location 0)");
    CHECK(contains(vs.source, "vertex "), "missing 'vertex' qualifier");
    CHECK(!contains(vs.source, "fast::"), "fast:: math found in output");
    write_file(out_dir / "vertex_passthrough.metal", vs.source);

    auto fs = translate_checked("fragment_solid", SPIRV_FRAGMENT_SOLID, true);
    CHECK(fs.is_fragment, "fragment shader reported as vertex");
    CHECK(contains(fs.source, "[[color(0)]]"), "missing [[color(0)]]");
    CHECK(contains(fs.source, "fragment "), "missing 'fragment' qualifier");
    CHECK(contains(fs.source, "0.25") && contains(fs.source, "0.75"), "constants lost");
    write_file(out_dir / "fragment_solid.metal", fs.source);

    auto ft = translate_checked("fragment_texture", SPIRV_FRAGMENT_TEXTURE, true);
    CHECK(contains(ft.source, "texture2d<float>"), "missing texture2d<float>");
    CHECK(contains(ft.source, "[[texture(2)]]"), "set 3 binding 2 must land on [[texture(2)]]");
    CHECK(contains(ft.source, "[[sampler(2)]]"), "set 3 binding 2 must land on [[sampler(2)]]");
    write_file(out_dir / "fragment_texture.metal", ft.source);

    // the macOS flavour is what the runtime part below compiles
    translate_checked("vertex_passthrough(macOS)", SPIRV_VERTEX_PASSTHROUGH, false);

    // string-returning wrapper with the requested signature
    std::string err;
    CHECK(!shader::msl::spirv_to_msl(SPIRV_VERTEX_PASSTHROUGH, &err).empty(), "wrapper returned empty: %s", err.c_str());

    // garbage must fail cleanly, not crash
    std::vector<uint32_t> garbage = { 1, 2, 3, 4, 5, 6 };
    shader::msl::Result bad = shader::msl::translate(garbage);
    CHECK(!bad.ok && !bad.error.empty(), "garbage SPIR-V accepted");
    std::vector<uint32_t> truncated(SPIRV_FRAGMENT_SOLID.begin(), SPIRV_FRAGMENT_SOLID.begin() + 12);
    shader::msl::Result bad2 = shader::msl::translate(truncated);
    CHECK(!bad2.ok, "truncated SPIR-V accepted");
}

static void test_cache(const std::filesystem::path &dir) {
    std::filesystem::remove_all(dir);
    shader::msl::SourceCache cache(dir.string(), "test salt 1");
    shader::msl::Result r = shader::msl::translate(SPIRV_FRAGMENT_SOLID);
    shader::msl::Result loaded;
    CHECK(!cache.load("abc123", loaded), "empty cache returned a hit");
    cache.store("abc123", r);
    CHECK(cache.load("abc123", loaded), "stored entry not found");
    CHECK(loaded.source == r.source && loaded.entry_point == r.entry_point && loaded.is_fragment == r.is_fragment, "cache round trip changed the data");
    shader::msl::SourceCache other(dir.string(), "different salt");
    shader::msl::Result miss;
    CHECK(!other.load("abc123", miss), "entry with a different salt must be ignored");
    std::printf("[cache] round trip %s\n", g_failures ? "see failures" : "ok");
}

static id<MTLLibrary> compile_msl(id<MTLDevice> device, const std::string &source, const char *what) {
    MTLCompileOptions *opts = [MTLCompileOptions new];
    if (@available(macOS 14.0, *))
        opts.languageVersion = MTLLanguageVersion3_1;
    else
        opts.languageVersion = MTLLanguageVersion3_0;
    // never fast math: image correctness comes before speed
    if (@available(macOS 15.0, *))
        opts.mathMode = MTLMathModeSafe;
    else
        opts.fastMathEnabled = NO;
    NSError *error = nil;
    id<MTLLibrary> lib = [device newLibraryWithSource:[NSString stringWithUTF8String:source.c_str()] options:opts error:&error];
    if (!lib) {
        ++g_failures;
        std::printf("  FAIL runtime compile of %s: %s\n", what, error.localizedDescription.UTF8String);
    }
    return lib;
}

static void test_render() {
    id<MTLDevice> device = MTLCreateSystemDefaultDevice();
    if (!device) {
        ++g_skipped;
        std::printf("[render] SKIPPED: no Metal device in this environment (NOT verified)\n");
        return;
    }
    std::printf("[render] device: %s\n", device.name.UTF8String);

    shader::msl::Options opt;
    opt.ios = false;
    opt.msl_major = 3;
    opt.msl_minor = 0; // macOS runners may be older than 14; MSL 3.0 is enough for these shaders
    auto vs = shader::msl::translate(SPIRV_VERTEX_PASSTHROUGH, opt);
    auto fs = shader::msl::translate(SPIRV_FRAGMENT_SOLID, opt);
    if (!vs.ok || !fs.ok) {
        ++g_failures;
        std::printf("  FAIL macOS-flavour translation\n");
        return;
    }
    id<MTLLibrary> vlib = compile_msl(device, vs.source, "vertex");
    id<MTLLibrary> flib = compile_msl(device, fs.source, "fragment");
    if (!vlib || !flib)
        return;

    id<MTLFunction> vfn = [vlib newFunctionWithName:[NSString stringWithUTF8String:vs.entry_point.c_str()]];
    id<MTLFunction> ffn = [flib newFunctionWithName:[NSString stringWithUTF8String:fs.entry_point.c_str()]];
    CHECK(vfn && ffn, "entry points '%s' / '%s' not found in the compiled libraries", vs.entry_point.c_str(), fs.entry_point.c_str());
    if (!vfn || !ffn)
        return;

    MTLVertexDescriptor *vd = [MTLVertexDescriptor vertexDescriptor];
    vd.attributes[0].format = MTLVertexFormatFloat4;
    vd.attributes[0].offset = 0;
    vd.attributes[0].bufferIndex = shader::msl::VERTEX_STREAM_BUFFER_BASE;
    vd.layouts[shader::msl::VERTEX_STREAM_BUFFER_BASE].stride = 16;

    MTLRenderPipelineDescriptor *pd = [MTLRenderPipelineDescriptor new];
    pd.vertexFunction = vfn;
    pd.fragmentFunction = ffn;
    pd.vertexDescriptor = vd;
    pd.colorAttachments[0].pixelFormat = MTLPixelFormatRGBA8Unorm;
    NSError *error = nil;
    id<MTLRenderPipelineState> pso = [device newRenderPipelineStateWithDescriptor:pd error:&error];
    CHECK(pso != nil, "pipeline creation failed: %s", error.localizedDescription.UTF8String);
    if (!pso)
        return;

    const NSUInteger W = 64, H = 64;
    MTLTextureDescriptor *td = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm width:W height:H mipmapped:NO];
    td.usage = MTLTextureUsageRenderTarget;
    td.storageMode = MTLStorageModeShared;
    id<MTLTexture> target = [device newTextureWithDescriptor:td];

    // full-screen triangle
    const float verts[12] = { -1, -1, 0, 1, 3, -1, 0, 1, -1, 3, 0, 1 };
    id<MTLBuffer> vb = [device newBufferWithBytes:verts length:sizeof(verts) options:MTLResourceStorageModeShared];

    MTLRenderPassDescriptor *rp = [MTLRenderPassDescriptor renderPassDescriptor];
    rp.colorAttachments[0].texture = target;
    rp.colorAttachments[0].loadAction = MTLLoadActionClear;
    rp.colorAttachments[0].clearColor = MTLClearColorMake(0, 0, 0, 0);
    rp.colorAttachments[0].storeAction = MTLStoreActionStore;

    id<MTLCommandQueue> queue = [device newCommandQueue];
    id<MTLCommandBuffer> cb = [queue commandBuffer];
    id<MTLRenderCommandEncoder> enc = [cb renderCommandEncoderWithDescriptor:rp];
    [enc setRenderPipelineState:pso];
    [enc setVertexBuffer:vb offset:0 atIndex:shader::msl::VERTEX_STREAM_BUFFER_BASE];
    [enc drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];
    [enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    CHECK(cb.status == MTLCommandBufferStatusCompleted, "command buffer did not complete");

    uint8_t px[W * H * 4];
    [target getBytes:px bytesPerRow:W * 4 fromRegion:MTLRegionMake2D(0, 0, W, H) mipmapLevel:0];
    // 0.25/0.5/0.75 -> 64 / 128 / 191 (+-1 for rounding of the unorm conversion)
    int bad = 0;
    for (NSUInteger i = 0; i < W * H; ++i) {
        const uint8_t *p = px + i * 4;
        if (std::abs(p[0] - 64) > 1 || std::abs(p[1] - 128) > 1 || std::abs(p[2] - 191) > 1 || p[3] != 255)
            ++bad;
    }
    std::printf("[render] %lu/%lu pixels wrong, centre = (%d,%d,%d,%d)\n", (unsigned long)bad, (unsigned long)(W * H),
        px[(32 * W + 32) * 4], px[(32 * W + 32) * 4 + 1], px[(32 * W + 32) * 4 + 2], px[(32 * W + 32) * 4 + 3]);
    CHECK(bad == 0, "rendered image is not the expected solid colour");
}

int main(int argc, char **argv) {
    @autoreleasepool {
        std::filesystem::path out_dir = argc > 1 ? argv[1] : "msl_out";
        std::filesystem::create_directories(out_dir);

        test_translation(out_dir);
        test_cache(out_dir / "cache_test");
        test_render();

        if (g_failures) {
            std::printf("RESULT: FAIL (%d failures)\n", g_failures);
            return 1;
        }
        std::printf("RESULT: PASS%s\n", g_skipped ? " (render step SKIPPED - no GPU)" : "");
        return 0;
    }
}
