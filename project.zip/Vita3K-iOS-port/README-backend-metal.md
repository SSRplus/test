# Metal backend สำหรับ Vita3K iOS (GXM → SPIR-V → MSL → Metal)

สถานะ: **Phase 1 เสร็จในระดับโค้ด + มี unit test ใน CI** — Phase 2-5 ยังไม่ได้เริ่ม
สิ่งที่ "ยังไม่ได้ตรวจ" เขียนไว้ท้ายไฟล์ (ห้ามอ่านข้าม)

## สถาปัตยกรรม (Phase 1)
```
GXP ──convert_gxp(Target::SpirVVulkan)──► SPIR-V ──shader::msl::translate──► MSL source ──(Phase 3)──► MTLLibrary/PSO
        (recompiler เดิม ไม่แก้)                    (SPIRV-Cross CompilerMSL)
```
- ใช้ recompiler ตัวเดิมของ Vulkan → ความหมายของ shader เหมือน MoltenVK ทุกประการ แตกต่างแค่ขั้นสุดท้าย
- ไม่แตะไฟล์ Vulkan ใดๆ และไม่แตะ `spirv_recompiler.cpp` (Vulkan backend ไม่เปลี่ยน)
- คอมไพล์เฉพาะ `if(APPLE)` → Linux / Windows / Android ไม่ได้รับผลกระทบ; define `VITA3K_BACKEND_METAL=1` ให้ target `shader`

### ไฟล์
| ไฟล์ | หน้าที่ |
|---|---|
| `shader/include/shader/spirv_to_msl.h`, `src/spirv_to_msl.cpp` | `translate()`, `spirv_to_msl()`, `SourceCache` (พึ่ง std + SPIRV-Cross เท่านั้น) |
| `shader/include/shader/gxp_to_msl.h`, `src/gxp_to_msl.cpp` | `metal_feature_profile()`, `convert_gxp_to_msl()` |
| `tests/metal_shader_test/` | unit test (SPIR-V ประกอบมือ 3 ตัว: vertex passthrough, fragment solid color, fragment texture) |
| `scripts/apply_metal_patches.py` | คัดลอกไฟล์ + แก้ CMake 2 จุด (เปิด `SPIRV_CROSS_ENABLE_MSL` เฉพาะ Apple, link `spirv-cross-msl`) |
| `scripts/metal-shader-test.sh` | build + รัน test บน macOS runner + คอมไพล์ MSL ด้วย `xcrun -sdk iphoneos metal` |

### Argument-table layout (ต้องตรงกันระหว่าง translator กับ pipeline ใน Phase 3)
| SPIR-V (Vulkan) | Metal |
|---|---|
| set 0 binding 0..3 (render-info UBO vert/frag, SSBO vert/frag) | `[[buffer(0..3)]]` (`set*4+binding`) |
| set 2 binding n (vertex texture) | `[[texture(n)]]` / `[[sampler(n)]]` ใน vertex stage |
| set 3 binding n (fragment texture) | `[[texture(n)]]` / `[[sampler(n)]]` ใน fragment stage |
| set 1 binding 1 (mask) | `[[texture(21)]]` / `[[sampler(21)]]` |
| set 1 binding 0 (`last_frag_data` subpass input) | framebuffer fetch `[[color(0)]]` (ไม่ผูก resource) |
| vertex attribute location n | `[[attribute(n)]]` → `MTLVertexDescriptor.attributes[n]` |
| vertex stream buffers | `bufferIndex >= 16` (`VERTEX_STREAM_BUFFER_BASE`) กันชน slot ของ uniform |

### Feature profile ของ Metal (`metal_feature_profile`)
`direct_fragcolor=true` (เหมือนที่ Vulkan/MoltenVK ใช้อยู่แล้วเมื่อไม่เปิด high-accuracy), ไม่มี shader interlock / texture barrier,
`enable_memory_mapping=false` (path buffer-device-address เป็นของ Vulkan), `support_scaled_attribute_formats=false` (Metal ไม่มี scaled format)

### Fast-math
- **ไม่มี** การเปิด fast-math ใน translator
- ใน SPIRV-Cross ฉบับที่อยู่ในโปรเจกต์ ผมไม่พบ option ชื่อ `use_fast_math_pragmas` (และไม่ได้ใส่) — fast-math ของ Metal ถูกควบคุมที่ `MTLCompileOptions` (`mathMode = MTLMathModeSafe` / `fastMathEnabled = NO`) ตอนสร้าง pipeline ใน Phase 3; unit test ใช้ค่านี้อยู่แล้ว
- การเลือก `metal::fast`/`metal::precise` ตาม decoration ใน SPIR-V: ยังไม่ได้ทำ (ต้องอ่านโค้ด SPIRV-Cross ที่ pin ไว้ก่อนว่ารองรับระดับไหน) → ค้างไว้เป็นงาน Phase 3

### SourceCache (MSL source, แยกจาก cache ของ Vulkan)
ไฟล์ `<dir>/<shader_hash>.msl` หัวไฟล์มี `version + salt` (salt ต้องเปลี่ยนเมื่อ `shader::CURRENT_VERSION` หรือ option ของ translator เปลี่ยน), เขียนผ่านไฟล์ชั่วคราว + rename (ไม่มีไฟล์ค้างครึ่งๆ กลางๆ ถ้าแอปโดนฆ่า)

## ข้อสังเกตที่ต้องตัดสินใจก่อน Phase 2/3
1. **MSL 3.1 vs iOS 16.4**: `MTLLanguageVersion3_1` เริ่มที่ iOS 17 → เครื่อง iOS 16.x ต้องคอมไพล์ด้วย 3.0 (`Options::msl_minor = 0`). Shader ที่เจนมา CI คอมไพล์ทั้ง 3.0 และ 3.1 ให้ดูผล
2. **ทิศแกน Y / clip space**: Vulkan NDC y ชี้ลง, Metal ชี้ขึ้น — ต้องดูว่า MoltenVK ชดเชยอย่างไรแล้วทำให้เหมือนกันใน viewport/pipeline (ตรวจด้วย image diff)
3. `MTLBinaryArchive` เป็น path เดียวที่ทำให้ไม่กระตุก แต่บน iOS archive ผูกกับ GPU/OS build — ต้องมี fallback compile ตอน archive ไม่ตรง
4. Phase 4 (surface/texture cache) เป็นงานก้อนใหญ่ที่สุด (port logic ทั้งไฟล์ของ Vulkan) และไม่ควรเริ่มก่อน Phase 2-3 ผ่าน

## สิ่งที่ยังไม่ได้ตรวจ (ความจริงของ Phase 1)
- โค้ดชุดนี้ **ผมยังไม่ได้คอมไพล์เอง** (sandbox ของผมไม่มี clang/SPIRV-Cross/อินเทอร์เน็ต) — ผลคอมไพล์จริงออกที่ขั้น "Metal shader unit test" ใน GitHub Actions ถ้าพังให้ส่ง REPORT.md กลับมาแก้
- การ render จริงทดสอบเมื่อ runner มี Metal device เท่านั้น ถ้าไม่มี test จะพิมพ์ `SKIPPED` ชัดเจน (ไม่ใช่ PASS เงียบๆ)
- ยังไม่มี Metal renderer ใดๆ (Phase 2+), ยังไม่ได้รันเกมบนเครื่อง iOS, ยังไม่มี diagnostics/perflog ของ Metal, ยังไม่ได้เทียบภาพกับ MoltenVK
