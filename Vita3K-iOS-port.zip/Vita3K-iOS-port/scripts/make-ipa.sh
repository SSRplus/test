#!/bin/bash
# usage: make-ipa.sh <patched_source_dir> <port_dir> <out_dir>
set -ex
SRC="$1"; PORT="$2"; OUT="$3"
export IOS_DEPS=${IOS_DEPS:-$PWD/ios-deps}
rm -rf Payload "$OUT" && mkdir -p "$OUT"
APP=$(find "$SRC/build-ios" -maxdepth 4 -type d -name 'Vita3K.app' | head -1)
if [ -z "$APP" ]; then
  echo "Vita3K.app not found - the build failed or produced a bare executable"; find "$SRC/build-ios" -maxdepth 3 -name 'Vita3K*' ; exit 1
fi
mkdir -p Payload && cp -R "$APP" Payload/Vita3K.app
cp "$PORT/ios/Info.plist" Payload/Vita3K.app/Info.plist
[ -d Payload/Vita3K.app/data ] || cp -R "$SRC/data" Payload/Vita3K.app/data
[ -d Payload/Vita3K.app/shaders-builtin ] || cp -R "$SRC/vita3k/shaders-builtin" Payload/Vita3K.app/shaders-builtin
[ -f "$PORT/ios/AppIcon.png" ] && cp "$PORT/ios/AppIcon.png" Payload/Vita3K.app/AppIcon60x60@2x.png || true
[ -f "$SRC/vita3k/Vita3K.png" ] && cp "$SRC/vita3k/Vita3K.png" Payload/Vita3K.app/Icon.png || true
mkdir -p Payload/Vita3K.app/Frameworks
cp -R "$IOS_DEPS/Frameworks/MoltenVK.framework" Payload/Vita3K.app/Frameworks/
ldid -S Payload/Vita3K.app/Frameworks/MoltenVK.framework/MoltenVK
ldid -S"$PORT/ios/entitlements.plist" Payload/Vita3K.app/Vita3K
zip -qry "$OUT/Vita3K.ipa" Payload
cp "$OUT/Vita3K.ipa" "$OUT/Vita3K.tipa"   # TrollStore .tipa = same zip, different extension
ls -la "$OUT"
