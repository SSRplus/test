#!/usr/bin/env python3
"""Applies the iOS port to a Vita3K-Plus source tree. Exact-match edits: fails loudly if a hunk does not match."""
import os, shutil, sys

root = sys.argv[1]
port = sys.argv[2]
failed = []

def edit(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding="utf-8").read()
    for i, (old, new) in enumerate(pairs):
        if old not in s:
            failed.append(f"{rel} hunk#{i}: {old[:70]!r}")
            continue
        s = s.replace(old, new)
    open(p, "w", encoding="utf-8").write(s)

# 0. copy iOS sources into the tree
shutil.copytree(os.path.join(port, "ios"), os.path.join(root, "ios"), dirs_exist_ok=True)

# 1. root CMakeLists
edit("CMakeLists.txt", [
    ("set(CMAKE_OSX_DEPLOYMENT_TARGET 11.0)\n",
     "if(NOT IOS)\n\tset(CMAKE_OSX_DEPLOYMENT_TARGET 11.0)\nendif()\nif(IOS)\n\tadd_compile_definitions(VITA3K_IOS=1)\nendif()\n"),
    ("if(APPLE)\n    enable_language(OBJC)\nendif()",
     "if(APPLE)\n    enable_language(OBJC)\n    enable_language(OBJCXX)\n    set(CMAKE_OBJCXX_STANDARD 23)\n    set(CMAKE_OBJCXX_STANDARD_REQUIRED ON)\nendif()"),
])

# 2. external/CMakeLists.txt
edit("external/CMakeLists.txt", [
    ("add_subdirectory(ffmpeg)\n",
     "if(IOS)\n\tinclude(\"${CMAKE_SOURCE_DIR}/ios/ffmpeg_ios.cmake\")\nelse()\n\tadd_subdirectory(ffmpeg)\nendif()\n"),
    ("if(APPLE OR NOT FORCE_BUILD_OPENSSL_MAC)", "if(NOT IOS AND (APPLE OR NOT FORCE_BUILD_OPENSSL_MAC))"),
    ("if(NOT ANDROID)\n\t# nativefiledialog-extended", "if(NOT ANDROID AND NOT IOS)\n\t# nativefiledialog-extended"),
    ('target_include_directories(vulkan INTERFACE "${CMAKE_CURRENT_SOURCE_DIR}/VulkanMemoryAllocator-Hpp/Vulkan-Headers/include")\nif(APPLE)\n',
     'target_include_directories(vulkan INTERFACE "${CMAKE_CURRENT_SOURCE_DIR}/VulkanMemoryAllocator-Hpp/Vulkan-Headers/include")\n'
     'if(IOS)\n\tset(V3K_MVK_FLAVOR ios)\n\tset(V3K_MVK_DYLIB_DIR iOS)\nelse()\n\tset(V3K_MVK_FLAVOR macos)\n\tset(V3K_MVK_DYLIB_DIR macOS)\nendif()\nif(APPLE)\n'),
    ("MoltenVK-macos.tar", "MoltenVK-${V3K_MVK_FLAVOR}.tar"),
    ("dylib/macOS/libMoltenVK.dylib", "dylib/${V3K_MVK_DYLIB_DIR}/libMoltenVK.dylib"),
])

# 3. vita3k/CMakeLists.txt
IOS_BLOCK = '''elseif(IOS)
	# pugixml was only reachable through gui-qt (excluded on iOS); interface.cpp needs it directly (as on Android)
	target_link_libraries(vita3k PRIVATE pugixml::pugixml miniz)
	foreach(fw UIKit Foundation Metal QuartzCore CoreGraphics AVFoundation AudioToolbox CoreAudio CoreMotion CoreHaptics
			GameController CoreMedia CoreVideo CoreFoundation Security SystemConfiguration UniformTypeIdentifiers CoreBluetooth ImageIO OpenGLES)
		target_link_libraries(vita3k PRIVATE "-framework ${fw}")
	endforeach()
	target_link_libraries(vita3k PRIVATE c++ z bz2 iconv)
	set_target_properties(vita3k PROPERTIES LINK_FLAGS "-rpath @executable_path/Frameworks"
		OBJCXX_STANDARD 23 OBJCXX_STANDARD_REQUIRED ON OBJCXX_EXTENSIONS OFF)
	add_custom_command(
		TARGET vita3k
		POST_BUILD
		COMMAND ${CMAKE_COMMAND} -E copy_directory "${CMAKE_CURRENT_SOURCE_DIR}/../data" "$<TARGET_FILE_DIR:vita3k>/data"
		COMMAND ${CMAKE_COMMAND} -E copy_directory "${CMAKE_CURRENT_SOURCE_DIR}/shaders-builtin" "$<TARGET_FILE_DIR:vita3k>/shaders-builtin")
elseif(LINUX)
	set(CMAKE_EXE_LINKER_FLAGS'''
edit("vita3k/CMakeLists.txt", [
    ("if(NOT ANDROID)\n\tinclude(${CMAKE_SOURCE_DIR}/cmake/qt6.cmake)\nendif()",
     "if(NOT ANDROID AND NOT IOS)\n\tinclude(${CMAKE_SOURCE_DIR}/cmake/qt6.cmake)\nendif()"),
    ("if(NOT ANDROID)\n\tadd_subdirectory(gui-qt)\nendif()",
     "if(NOT ANDROID AND NOT IOS)\n\tadd_subdirectory(gui-qt)\nendif()"),
    ("else()\n\tadd_executable(vita3k MACOSX_BUNDLE main.cpp interface.cpp interface.h performance.cpp)\nendif()",
     "elseif(IOS)\n"
     "\tadd_executable(vita3k MACOSX_BUNDLE ${CMAKE_SOURCE_DIR}/ios/ios_main.mm ${CMAKE_SOURCE_DIR}/ios/ios_jit.cpp interface.cpp interface.h performance.cpp)\n"
     "\ttarget_include_directories(vita3k PRIVATE ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_SOURCE_DIR}/ios)\n"
     "\tset_source_files_properties(${CMAKE_SOURCE_DIR}/ios/ios_main.mm PROPERTIES COMPILE_FLAGS \"-fobjc-arc\")\n"
     "else()\n\tadd_executable(vita3k MACOSX_BUNDLE main.cpp interface.cpp interface.h performance.cpp)\nendif()"),
    ("if(NOT ANDROID)\n\ttarget_link_libraries(vita3k PRIVATE gui-qt)\nendif()",
     "if(NOT ANDROID AND NOT IOS)\n\ttarget_link_libraries(vita3k PRIVATE gui-qt)\nendif()"),
    ("if(NOT ANDROID)\n\tfile(GLOB VITA3K_QT_TS_FILES", "if(NOT ANDROID AND NOT IOS)\n\tfile(GLOB VITA3K_QT_TS_FILES"),
    ("if(APPLE)\n\tadd_custom_command(\n\t\tOUTPUT Vita3K.icns", "if(APPLE AND NOT IOS)\n\tadd_custom_command(\n\t\tOUTPUT Vita3K.icns"),
    ("elseif(LINUX)\n\tset(CMAKE_EXE_LINKER_FLAGS", IOS_BLOCK),
])

# 4. renderer: no Cocoa / NSView helper on iOS (ios_main.mm provides get_metal_layer_from_view via SDL)
edit("vita3k/renderer/CMakeLists.txt", [
    ('if(APPLE)\n\ttarget_sources(renderer PRIVATE src/vulkan/metal_layer.mm)\n\ttarget_link_libraries(renderer PRIVATE "-framework QuartzCore" "-framework Cocoa")\nendif()',
     'if(APPLE AND NOT IOS)\n\ttarget_sources(renderer PRIVATE src/vulkan/metal_layer.mm)\n\ttarget_link_libraries(renderer PRIVATE "-framework QuartzCore" "-framework Cocoa")\nelseif(IOS)\n\ttarget_link_libraries(renderer PRIVATE "-framework QuartzCore" "-framework Metal" "-framework UIKit")\nendif()'),
])

# 5. Vulkan loader: MoltenVK lives in the app bundle, load it explicitly
edit("vita3k/renderer/src/vulkan/renderer.cpp", [
    ("#ifdef __ANDROID__\n// must be first\n#define __ANDROID_UNAVAILABLE_SYMBOLS_ARE_WEAK__\n#endif\n",
     "#ifdef __ANDROID__\n// must be first\n#define __ANDROID_UNAVAILABLE_SYMBOLS_ARE_WEAK__\n#endif\n"
     "#ifdef VITA3K_IOS\nextern \"C\" void *ios_get_vk_instance_proc_addr();\n#endif\n"),
    ("#else\n        VULKAN_HPP_DEFAULT_DISPATCHER.init();\n#endif",
     "#elif defined(VITA3K_IOS)\n        VULKAN_HPP_DEFAULT_DISPATCHER.init(reinterpret_cast<PFN_vkGetInstanceProcAddr>(ios_get_vk_instance_proc_addr()));\n#else\n        VULKAN_HPP_DEFAULT_DISPATCHER.init();\n#endif"),
    ("#else\n        dispatch.init();\n#endif",
     "#elif defined(VITA3K_IOS)\n        dispatch.init(reinterpret_cast<PFN_vkGetInstanceProcAddr>(ios_get_vk_instance_proc_addr()));\n#else\n        dispatch.init();\n#endif"),
])

# 6. gen-modules is a host tool, not needed for iOS
edit("tools/gen-modules/CMakeLists.txt", [("if(NOT ANDROID)", "if(NOT ANDROID AND NOT IOS)")])

# 7. SceNet: SCDynamicStore is not available on iOS -> replace helper implementation
shutil.copyfile(os.path.join(port, "ios", "ios_net_helper.cpp"), os.path.join(root, "vita3k/modules/SceNet/macos_net_helper.cpp"))

# 8. Dynarmic (submodule): MAP_JIT must be chosen at runtime. Entitled builds (TrollStore) can use MAP_JIT, debugger-enabled JIT
#    (StikDebug/AltJIT) must use plain RWX mappings.
import re
dyn = os.path.join(root, "external", "dynarmic")
patched = 0
decl = 'extern "C" int ios_jit_use_map_jit(void);\n'
pat = re.compile(r'(?<!defined\()(?<!#ifdef )(?<!#ifndef )(?<!# ifdef )\bMAP_JIT\b')
for dp, _, files in os.walk(dyn):
    for f in files:
        if not f.endswith((".h", ".hpp", ".cpp", ".c", ".inc")):
            continue
        fp = os.path.join(dp, f)
        try:
            t = open(fp, encoding="utf-8").read()
        except Exception:
            continue
        if "MAP_JIT" not in t or "mmap" not in t:
            continue
        t2 = pat.sub("(ios_jit_use_map_jit() ? MAP_JIT : 0)", t)
        if t2 == t:
            continue
        m = re.search(r"^#include[^\n]*\n", t2, re.M)
        t2 = t2[:m.end()] + decl + t2[m.end():] if m else decl + t2
        open(fp, "w", encoding="utf-8").write(t2)
        patched += 1
        print("dynarmic MAP_JIT patched:", os.path.relpath(fp, root))
if patched == 0:
    print("WARNING: no MAP_JIT mmap site found in external/dynarmic (check JIT allocation manually)")

# 9. capstone: its CMakeLists forces a universal macOS build (-arch x86_64 -arch arm64), which the iPhoneOS SDK rejects
#    ("Unsupported architecture"). Drop any CMAKE_OSX_ARCHITECTURES override there (non-fatal if absent).
cap = os.path.join(root, "external", "capstone", "CMakeLists.txt")
if os.path.exists(cap):
    t = open(cap, encoding="utf-8").read()
    t2 = re.sub(r'^[ \t]*set\s*\(\s*CMAKE_OSX_ARCHITECTURES[^)]*\)[ \t]*$', '# (iOS port) removed CMAKE_OSX_ARCHITECTURES override', t, flags=re.M | re.I)
    if t2 != t:
        open(cap, "w", encoding="utf-8").write(t2)
        print("capstone arch override removed")
    else:
        print("capstone: no CMAKE_OSX_ARCHITECTURES override found (relying on -DCAPSTONE_BUILD_MACOS_THIN=ON)")

# 10. cubeb: its macOS backend (cubeb_audiounit.cpp / cubeb_osx_run_loop.cpp) needs CoreAudio hardware APIs that do not exist
#     on iOS. On iOS don't build cubeb at all; audio goes through the SDL backend ("Cubeb" selection falls back to SDL).
edit("external/CMakeLists.txt", [
    ("add_subdirectory(cubeb EXCLUDE_FROM_ALL)\n",
     "if(NOT IOS)\n\tadd_subdirectory(cubeb EXCLUDE_FROM_ALL)\nendif()\n"),
    ('if (ARCHITECTURE STREQUAL "arm64")\n\ttarget_compile_definitions(speex',
     'if (IOS)\n\t# cubeb/speex are not built on iOS\nelseif (ARCHITECTURE STREQUAL "arm64")\n\ttarget_compile_definitions(speex'),
])
edit("vita3k/audio/CMakeLists.txt", [
    ("    src/impl/sdl_audio.cpp\n    src/impl/cubeb_audio.cpp)\n",
     "    src/impl/sdl_audio.cpp\n    $<$<NOT:$<BOOL:${IOS}>>:src/impl/cubeb_audio.cpp>)\n"),
    ("target_link_libraries(audio PRIVATE util cubeb SDL3::SDL3)",
     "if(IOS)\n\ttarget_link_libraries(audio PRIVATE util SDL3::SDL3)\nelse()\n\ttarget_link_libraries(audio PRIVATE util cubeb SDL3::SDL3)\nendif()"),
])
edit("vita3k/audio/src/audio.cpp", [
    ("#include <audio/impl/cubeb_audio.h>\n",
     "#ifndef VITA3K_IOS\n#include <audio/impl/cubeb_audio.h>\n#endif\n"),
    ('    } else if (adapter_name == "Cubeb") {\n        adapter = std::make_unique<CubebAudioAdapter>(*this);\n',
     '    } else if (adapter_name == "Cubeb") {\n#ifdef VITA3K_IOS\n        adapter = std::make_unique<SDLAudioAdapter>(*this); // no cubeb on iOS\n#else\n        adapter = std::make_unique<CubebAudioAdapter>(*this);\n#endif\n'),
])

# 11. v0.1.1: OpenGL ES backend on iOS (reuses the Android GLES code paths), BGRA swapchain, backend selection
edit("vita3k/app/src/app_init.cpp", [
    ("static void set_backend_renderer(EmuEnvState &emuenv, const std::string &backend_renderer) {\n#ifndef __APPLE__",
     "static void set_backend_renderer(EmuEnvState &emuenv, const std::string &backend_renderer) {\n#if !defined(__APPLE__) || defined(VITA3K_IOS)"),
])
edit("vita3k/renderer/src/vulkan/screen_renderer.cpp", [
    ("        if ((format.format == vk::Format::eB8G8R8A8Unorm || format.format == vk::Format::eR8G8B8A8Unorm)\n",
     "#ifdef VITA3K_IOS\n        // CAMetalLayer's native format is BGRA8: asking for RGBA8 makes MoltenVK swizzle and can tint the picture\n        if (format.format == vk::Format::eB8G8R8A8Unorm\n#else\n        if ((format.format == vk::Format::eB8G8R8A8Unorm || format.format == vk::Format::eR8G8B8A8Unorm)\n#endif\n"),
])
import glob
for f in glob.glob(os.path.join(root, "vita3k/renderer/src/gl/*.cpp")):
    t = open(f, encoding="utf-8").read()
    t2 = t.replace("#ifdef __ANDROID__", "#if defined(__ANDROID__) || defined(VITA3K_IOS)").replace("#ifndef __ANDROID__", "#if !defined(__ANDROID__) && !defined(VITA3K_IOS)")
    if t2 != t:
        open(f, "w", encoding="utf-8").write(t2)
        print("GLES paths enabled for iOS:", os.path.relpath(f, root))

# 12. v0.1.1: smaller Vulkan stream buffers on iOS (6 x ~300 MB of host-visible buffers is too much for a 3 GB phone / jetsam)
edit("vita3k/renderer/src/vulkan/creation.cpp", [
    ("namespace renderer::vulkan {\n\nVKContext::VKContext",
     "#ifdef VITA3K_IOS\n#define V3K_RING_MB 24\n#define V3K_UBO_MB 8\n#else\n#define V3K_RING_MB 64\n#define V3K_UBO_MB 16\n#endif\n\nnamespace renderer::vulkan {\n\nVKContext::VKContext"),
    ("eVertexBuffer, MiB(/*128*/ 64))", "eVertexBuffer, MiB(V3K_RING_MB))"),
    ("eIndexBuffer, MiB(64))", "eIndexBuffer, MiB(V3K_RING_MB))"),
    ("eStorageBuffer, MiB(/*256*/ 64))", "eStorageBuffer, MiB(V3K_RING_MB))"),
    ("eUniformBuffer, MiB(16))", "eUniformBuffer, MiB(V3K_UBO_MB))"),
    ("eUniformBuffer, MiB(32))", "eUniformBuffer, MiB(2 * V3K_UBO_MB))"),
])

# 13. v0.1.2: jetsam fix. Every guest thread stack was filled with 0xcc (a debug pattern), which touches EVERY page of the stack
#     at thread creation. GOD EATER 2 etc. create many threads with large stacks, so RAM exploded to the ~2.1 GB per-process limit
#     within seconds (fps=0, 'other' grew 185MB -> 1.5GB in diagnostics). alloc_block() already returns zeroed memory, so the fill
#     is only a debugging aid; skip it on iOS so untouched stack pages are never committed.
edit("vita3k/kernel/src/thread.cpp", [
    ("    memset(stack.get_ptr<void>().get(mem), 0xcc, stack_size);\n",
     "#ifndef VITA3K_IOS\n    memset(stack.get_ptr<void>().get(mem), 0xcc, stack_size);\n#endif\n"),
])

# 14. v0.1.2: show RAM in the FPS overlay ("RAM: <footprint> MB (left <n> MB)"). "left" is os_proc_available_memory(): iOS kills the
#     app when it reaches 0. Values come from ios_mem_status() in ios/ios_main.mm and refresh at most twice per second.
edit("vita3k/overlay/include/overlay/perf_overlay.h", [
    ("    bool m_force_repaint = true;\n",
     "    bool m_force_repaint = true;\n\n    // iOS RAM line\n    bool refresh_ram();\n    uint32_t m_ram_used_mb = 0;\n    uint32_t m_ram_left_mb = 0;\n"
     "    std::chrono::steady_clock::time_point m_ram_tick{};\n"),
])
edit("vita3k/overlay/src/perf_overlay.cpp", [
    ("#include <cmath>\n",
     "#include <cmath>\n\n#ifdef VITA3K_IOS\nextern \"C\" void ios_mem_status(unsigned *used_mb, unsigned *left_mb);\n#endif\n"),
    ("    if (changed || m_force_repaint) {\n        if (m_graph_enabled && fps_values && fps_values_count > 0) {\n",
     "    const bool ram_changed = refresh_ram();\n    if (changed || ram_changed || m_force_repaint) {\n        if (m_graph_enabled && fps_values && fps_values_count > 0 && (changed || m_force_repaint)) {\n"),
    ("void perf_overlay::update_text() {\n    std::string text;\n",
     "bool perf_overlay::refresh_ram() {\n#ifdef VITA3K_IOS\n"
     "    const auto now = std::chrono::steady_clock::now();\n"
     "    if (now - m_ram_tick < std::chrono::milliseconds(500))\n        return false;\n"
     "    m_ram_tick = now;\n"
     "    unsigned used = 0, left = 0;\n    ios_mem_status(&used, &left);\n"
     "    auto diff = [](uint32_t a, uint32_t b) { return a > b ? a - b : b - a; };\n"
     "    if (diff(used, m_ram_used_mb) < 8 && diff(left, m_ram_left_mb) < 8)\n        return false;\n"
     "    m_ram_used_mb = used;\n    m_ram_left_mb = left;\n    return true;\n"
     "#else\n    return false;\n#endif\n}\n\n"
     "void perf_overlay::update_text() {\n    std::string text;\n"),
    ("    m_body.set_text(text);\n    m_body.auto_resize();\n",
     "#ifdef VITA3K_IOS\n    text += fmt::format(\"\\nRAM: {} MB (left {} MB)\", m_ram_used_mb, m_ram_left_mb);\n#endif\n"
     "    m_body.set_text(text);\n    m_body.auto_resize();\n"),
])

# 15. v0.1.3: guest RAM on iOS. Two behaviours of the desktop code are wrong on Darwin and inflate the jetsam footprint:
#     (a) alloc_inner() memset()s EVERY allocated guest byte to 0, which commits all pages of every block at once, even if the
#         game never touches them. Fresh mmap pages are already zero, so on iOS only the (shared) edge host-pages are cleared.
#     (b) free() releases pages with madvise(MADV_DONTNEED). On Linux that frees + zeroes; on Darwin it is only a hint and the
#         pages stay in the footprint forever. On iOS the range is replaced with fresh anonymous pages (mmap MAP_FIXED) instead,
#         which really releases the memory and guarantees zero-filled pages for the next allocation (what (a) relies on).
#     Plus ios_diag_note() lines (diagnostics.txt) for every guest block >= 2 MB, every free >= 2 MB and every guest thread.
edit("vita3k/mem/src/mem.cpp", [
    ("constexpr bool LOG_PROTECT = false;\n",
     "constexpr bool LOG_PROTECT = false;\n\n"
     "#ifdef VITA3K_IOS\nextern \"C\" void ios_diag_note(const char *what, const char *name, unsigned long long bytes);\n#endif\n\n"
     "static int v3k_release_pages(void *p, size_t n) {\n"
     "#if defined(VITA3K_IOS)\n"
     "    return mmap(p, n, PROT_NONE, MAP_FIXED | MAP_PRIVATE | MAP_ANON, -1, 0) == MAP_FAILED ? -1 : 0;\n"
     "#elif !defined(_WIN32)\n"
     "    return madvise(p, n, MADV_DONTNEED);\n"
     "#else\n    (void)p;\n    (void)n;\n    return 0;\n#endif\n}\n"),
    ("    std::memset(&state.memory[addr], 0, size);\n",
     "#ifdef VITA3K_IOS\n"
     "    {\n"
     "        // pages are fresh zero pages (initial mmap or replaced in free()): only clear the host pages shared with neighbours\n"
     "        const Address hps = static_cast<Address>(state.host_page_size);\n"
     "        const Address a0 = addr, a1 = addr + size;\n"
     "        const Address i0 = align(a0, hps), i1 = align_down(a1, hps);\n"
     "        if (i0 >= i1) {\n"
     "            std::memset(&state.memory[a0], 0, size);\n"
     "        } else {\n"
     "            std::memset(&state.memory[a0], 0, i0 - a0);\n"
     "            std::memset(&state.memory[i1], 0, a1 - i1);\n"
     "        }\n"
     "        if (size >= MiB(2))\n            ios_diag_note(\"guest.alloc\", name, size);\n"
     "    }\n"
     "#else\n    std::memset(&state.memory[addr], 0, size);\n#endif\n"),
    ("madvise(memory, batch_size, MADV_DONTNEED)", "v3k_release_pages(memory, batch_size)"),
    ("    state.allocator.free(page_num, page.size);\n    if (PAGE_NAME_TRACKING) {\n        state.page_name_map.erase(page_num);\n",
     "#ifdef VITA3K_IOS\n    if (static_cast<uint64_t>(page.size) * STANDARD_PAGE_SIZE >= MiB(2))\n"
     "        ios_diag_note(\"guest.free\", \"\", static_cast<uint64_t>(page.size) * STANDARD_PAGE_SIZE);\n#endif\n"
     "    state.allocator.free(page_num, page.size);\n    if (PAGE_NAME_TRACKING) {\n        state.page_name_map.erase(page_num);\n"),
])
edit("vita3k/kernel/src/thread.cpp", [
    ("int ThreadState::init(const char *name,",
     "#ifdef VITA3K_IOS\nextern \"C\" void ios_diag_note(const char *what, const char *name, unsigned long long bytes);\n#endif\n\nint ThreadState::init(const char *name,"),
    ("    stack = alloc_block(mem, stack_size, alloc_name.c_str());\n",
     "    stack = alloc_block(mem, stack_size, alloc_name.c_str());\n#ifdef VITA3K_IOS\n    ios_diag_note(\"guest.thread\", name, stack_size);\n#endif\n"),
])

# 16. v0.1.4: JIT code cache per guest thread. Dynarmic's UserConfig::code_cache_size defaults to 128 MiB and Vita3K builds one A32::Jit
#     for EVERY guest thread (cpu/src/cpu.cpp init_cpu -> DynarmicCPU -> make_jit). diagnostics.txt of GOD EATER 2 shows the footprint
#     jumping ~116 MB for each new thread (EXEC/JIT regions in vm.snapshot, 12 more regions = +1.5 GB in 5 s) until jetsam at ~2.1 GB.
#     The size now comes from ios_jit_cache_mb() in ios_main.mm (first JIT of a session = main game thread, others smaller; both
#     adjustable in Settings > Memory (JIT)). The assignment goes through a template so that a Dynarmic without the field still compiles
#     (it then logs "jit.cache ... NOT-SUPPORTED" instead of failing the build).
edit("vita3k/cpu/src/dynarmic_cpu.cpp", [
    ("#include <bit>\n#include <memory>\n#include <optional>\n#include <string>\n",
     "#include <bit>\n#include <memory>\n#include <optional>\n#include <string>\n\n"
     "#ifdef VITA3K_IOS\n"
     "#include <cstddef>\n#include <type_traits>\n"
     "extern \"C\" unsigned ios_jit_cache_mb(void);\n"
     "extern \"C\" void ios_diag_note(const char *what, const char *name, unsigned long long bytes);\n"
     "template <class Cfg>\n"
     "static bool v3k_set_code_cache(Cfg &cfg, std::size_t bytes) {\n"
     "    if constexpr (requires { cfg.code_cache_size; }) {\n"
     "        cfg.code_cache_size = static_cast<std::remove_cvref_t<decltype(cfg.code_cache_size)>>(bytes);\n"
     "        return true;\n"
     "    } else {\n"
     "        return false;\n"
     "    }\n"
     "}\n"
     "#endif\n"),
    ("    Dynarmic::A32::UserConfig config{};\n    config.arch_version = Dynarmic::A32::ArchVersion::v7;\n",
     "    Dynarmic::A32::UserConfig config{};\n"
     "#ifdef VITA3K_IOS\n"
     "    if (code_cache_bytes == 0)\n"
     "        code_cache_bytes = static_cast<std::size_t>(ios_jit_cache_mb()) << 20;\n"
     "    const bool cache_applied = v3k_set_code_cache(config, code_cache_bytes);\n"
     "    ios_diag_note(\"jit.cache\", cache_applied ? \"applied\" : \"NOT-SUPPORTED(field missing)\", code_cache_bytes);\n"
     "#endif\n"
     "    config.arch_version = Dynarmic::A32::ArchVersion::v7;\n"),
])
edit("vita3k/cpu/include/cpu/impl/dynarmic_cpu.h", [
    ("    bool cpu_opt;\n\n    std::unique_ptr<Dynarmic::A32::Jit> make_jit();\n",
     "    bool cpu_opt;\n\n#ifdef VITA3K_IOS\n    std::size_t code_cache_bytes = 0; // decided once per CPU (kept when the JIT is rebuilt for logging)\n#endif\n\n    std::unique_ptr<Dynarmic::A32::Jit> make_jit();\n"),
])

# 17. v0.1.6: "condition_variable wait failed: Invalid argument" crash on iOS (diagnostics of GOD EATER 2: std::terminate inside
#     start_module -> ThreadState::run_guest_function -> status_cond.wait()). ThreadState::status_cond is a plain std::condition_variable
#     that the emulator waits on with DIFFERENT mutexes (thread->mutex in thread.cpp, the primitive's mutex in sync_primitives.cpp).
#     glibc tolerates that; Darwin's pthread_cond_wait returns EINVAL as soon as two waiters use different mutexes. condition_variable_any
#     keeps its own internal mutex, so any lock type/mutex works. Same call syntax (wait / wait_for / notify_*).
edit("vita3k/kernel/include/kernel/thread/thread_state.h", [
    ("    std::condition_variable status_cond;\n",
     "#ifdef VITA3K_IOS\n    std::condition_variable_any status_cond; // Darwin: plain condition_variable breaks when waited on with different mutexes\n#else\n    std::condition_variable status_cond;\n#endif\n"),
])

# 18. v0.1.7: garbled textures (full-screen coloured blocks, black UI plates in GOD EATER 2). Vita3K only uses the GPU's own PVRTC decoder
#     on PowerVR hardware ("powerVR only" in texture.cpp) and tests that by probing ONE format (PVRTC1 2bpp). MoltenVK reports PVRTC1 on Apple
#     GPUs, so all four Vita PVRT formats were uploaded natively, including PVRTC2 (PVRTII*) which Metal has no format for at all.
#     On iOS PVRT textures now take the software decoder, the same path every non-PowerVR GPU uses.
edit("vita3k/renderer/src/vulkan/texture.cpp", [
    ("#include <util/align.h>\n#include <vkutil/vkutil.h>\n",
     "#include <util/align.h>\n#include <vkutil/vkutil.h>\n\n#ifdef VITA3K_IOS\n#include <cstdio>\nextern \"C\" void ios_diag_note(const char *what, const char *name, unsigned long long bytes);\n#endif\n"),
    ("    support_astc = static_cast<bool>(astc_support.optimalTilingFeatures & vk::FormatFeatureFlagBits::eSampledImage);\n\n    return true;\n}",
     "    support_astc = static_cast<bool>(astc_support.optimalTilingFeatures & vk::FormatFeatureFlagBits::eSampledImage);\n\n"
     "#ifdef VITA3K_IOS\n"
     "    {\n"
     "        char fmts[160];\n"
     "        std::snprintf(fmts, sizeof(fmts), \"pvrt_gpu=%d(forced off) dxt=%d astc=%d e5rgb9=%d a2rgb10=%d x8d24=%d\", support_pvrt ? 1 : 0, support_dxt ? 1 : 0,\n"
     "            support_astc ? 1 : 0, support_e5rgb9 ? 1 : 0, support_a2rgb10 ? 1 : 0, support_x8d24 ? 1 : 0);\n"
     "        ios_diag_note(\"gpu.formats\", fmts, 0);\n"
     "        support_pvrt = false;\n"
     "    }\n"
     "#endif\n\n    return true;\n}"),
])

# 19. text input (SceIme / IME dialog): the IME core of the working Vita3K-iOS fork.
#     Root cause of "Enter is ignored, name stays empty": stock sceImeUpdate never delivered SCE_IME_EVENT_OPEN to the game's handler
#     (it returned early while event_id == OPEN), held Ime::mutex while the guest callback ran, and left sceImeSetText unimplemented.
#     The replacement (vita3k-ime/) delivers OPEN as a real callback, drains the last text update before Enter/Close, releases the
#     mutex during the callback and implements sceImeSetText. ios_main.mm only publishes text and calls Ime::native_input.submit().
_ime_src = os.path.join(port, "vita3k-ime")
for _f in ("event.h", "native_input.h", "text.h", "guest_event.h", "state.h"):
    shutil.copy(os.path.join(_ime_src, _f), os.path.join(root, "vita3k/ime/include/ime", _f))
shutil.copy(os.path.join(_ime_src, "SceIme.cpp"), os.path.join(root, "vita3k/modules/SceIme/SceIme.cpp"))
edit("vita3k/ime/include/ime/types.h", [
    ("#include <mem/ptr.h>\n", "#include <ime/event.h>\n#include <mem/ptr.h>\n"),
    ("enum ImeEvent {\n    SCE_IME_EVENT_OPEN = 0,\n    SCE_IME_EVENT_UPDATE_TEXT = 1,\n    SCE_IME_EVENT_UPDATE_CARET = 2,\n"
     "    SCE_IME_EVENT_CHANGE_SIZE = 3,\n    SCE_IME_EVENT_PRESS_CLOSE = 4,\n    SCE_IME_EVENT_PRESS_ENTER = 5,\n};\n\n", ""),
])
edit("vita3k/modules/SceCommonDialog/SceCommonDialog.cpp", [
    ("#include <ime/state.h>\n", "#include <ime/state.h>\n#include <ime/text.h>\n"),
    ("    // shared ime struct so ime funcs can work for ime_dialog\n    {\n        std::lock_guard lock2(emuenv.ime.mutex);\n        emuenv.ime.str = text;\n",
     "    text.resize(ime::text_length(text, p->maxTextLength));\n"
     "    // shared ime struct so ime funcs can work for ime_dialog\n    {\n        std::lock_guard lock2(emuenv.ime.mutex);\n"
     "        ++emuenv.ime.generation;\n        emuenv.ime.native_input.reset();\n        emuenv.ime.str = text;\n        emuenv.ime.delivered_text = text;\n"
     "        emuenv.ime.param.type = p->type;\n        emuenv.ime.param.option = p->option;\n        emuenv.ime.param.enterLabel = p->enterLabel;\n"),
    ("        std::lock_guard lock2(emuenv.ime.mutex);\n        emuenv.ime.str.clear();\n",
     "        std::lock_guard lock2(emuenv.ime.mutex);\n        emuenv.ime.native_input.reset();\n        emuenv.ime.str.clear();\n        emuenv.ime.delivered_text.clear();\n"),
])

# 20. v0.2.0: compressed shader cache on disk. Every translated shader (.spv) and the Vulkan pipeline-cache blob are stored
#     deflate-compressed ("V3KZ" header, falls back to plain bytes when it would not shrink). Old uncompressed caches are still read.
#     Toggle: Settings > Shaders > "Compress shader cache". The texture cache of Vita3K lives in RAM/GPU only (no disk file), so there is
#     nothing on disk to compress there.
shutil.copy(os.path.join(port, "renderer", "cache_compress.h"), os.path.join(root, "vita3k/renderer/include/renderer/cache_compress.h"))
shutil.copy(os.path.join(port, "renderer", "cache_compress.cpp"), os.path.join(root, "vita3k/renderer/src/cache_compress.cpp"))
edit("vita3k/renderer/CMakeLists.txt", [
    ("\tsrc/shaders.cpp\n", "\tsrc/shaders.cpp\n\tsrc/cache_compress.cpp\n"),
    ("target_link_libraries(renderer PRIVATE dialog ddspp SDL3::SDL3 stb ffmpeg xxHash::xxhash concurrentqueue)",
     "target_link_libraries(renderer PRIVATE dialog ddspp SDL3::SDL3 stb ffmpeg xxHash::xxhash concurrentqueue miniz)"),
])
edit("vita3k/renderer/src/shaders.cpp", [
    ("#include <renderer/shaders.h>\n", "#include <renderer/cache_compress.h>\n#include <renderer/shaders.h>\n"),
    ("static bool load_shader(const fs::path &shader_name,", "[[maybe_unused]] static bool load_shader(const fs::path &shader_name,"),
    ("    std::size_t read_size = 0;\n    R source;\n\n"
     "    if (load_shader(shader_path, nullptr, read_size)) {\n"
     "        source.resize((read_size + sizeof(typename R::value_type) - 1) / sizeof(typename R::value_type));\n\n"
     "        char *dest_pointer = reinterpret_cast<char *>(source.data());\n"
     "        load_shader(shader_path, &dest_pointer, read_size);\n    }\n\n    return source;",
     "    R source;\n    std::vector<uint8_t> bytes;\n"
     "    if (cachez::read_file(shader_path, bytes)) {\n"
     "        source.resize((bytes.size() + sizeof(typename R::value_type) - 1) / sizeof(typename R::value_type));\n"
     "        std::memcpy(source.data(), bytes.data(), bytes.size());\n    }\n\n    return source;"),
    ("        fs_utils::dump_data(out_path, data.c_str(), data.size());\n        return true;",
     "        if (out_path == shader_path)\n            cachez::write_file(out_path, data.c_str(), data.size());\n"
     "        else\n            fs_utils::dump_data(out_path, data.c_str(), data.size());\n        return true;"),
    ("        fs_utils::dump_data(shader_dst_path, source.spirv.data(), sizeof(uint32_t) * source.spirv.size());",
     "        cachez::write_file(shader_dst_path, source.spirv.data(), sizeof(uint32_t) * source.spirv.size());"),
    ("#include <string>\n#include <vector>\n", "#include <cstring>\n#include <string>\n#include <vector>\n"),
])
edit("vita3k/renderer/src/vulkan/pipeline_cache.cpp", [
    ("#include <renderer/shaders.h>\n", "#include <renderer/cache_compress.h>\n#include <renderer/shaders.h>\n#include <sstream>\n"
     "#ifdef VITA3K_IOS\nextern \"C\" void ios_diag_note(const char *what, const char *name, unsigned long long bytes);\n#endif\n"),
    ("constexpr uint32_t pipeline_cache_magic = 0xBEEF4321;\n",
     "constexpr uint32_t pipeline_cache_magic = 0xBEEF4321;\n\n"
     "// in-memory stand-in for the file stream (the cache file may be compressed)\n"
     "struct V3kMemIn : std::istringstream {\n    using std::istringstream::istringstream;\n"
     "    bool is_open() const { return true; }\n    void close() {}\n};\n"),
    ("    fs::ifstream pipeline_cache_file(path, std::ios::in | std::ios::binary);\n    if (!pipeline_cache_file.is_open())\n        return;\n",
     "    std::vector<uint8_t> v3k_file;\n    if (!renderer::cachez::read_file(path, v3k_file))\n        return;\n"
     "    V3kMemIn pipeline_cache_file(std::string(reinterpret_cast<const char *>(v3k_file.data()), v3k_file.size()), std::ios::in | std::ios::binary);\n"
     "    std::vector<uint8_t>().swap(v3k_file);\n"),
    ("    fs::ofstream pipeline_cache_file(path, std::ios::out | std::ios::binary | std::ios::trunc);\n    if (!pipeline_cache_file.is_open())\n        return;\n",
     "    std::ostringstream pipeline_cache_file(std::ios::out | std::ios::binary);\n"),
    ("    pipeline_cache_file.write(reinterpret_cast<const char *>(pipeline_data.data()), pipeline_data.size());\n    pipeline_cache_file.close();\n",
     "    pipeline_cache_file.write(reinterpret_cast<const char *>(pipeline_data.data()), pipeline_data.size());\n"
     "    {\n        const std::string v3k_buf = pipeline_cache_file.str();\n"
     "        if (!renderer::cachez::write_file(path, v3k_buf.data(), v3k_buf.size()))\n            LOG_WARN(\"Could not write the pipeline cache\");\n    }\n"),
])

# 21. v0.2.0: game crash with \"High accuracy\" (diagnostics: std::terminate in PipelineCache::compile_pipeline <- retrieve_pipeline <- draw,
#     i.e. vk::Device::createGraphicsPipeline threw on the render thread and nothing caught it).
#     High accuracy switches Vita3K to the VK_EXT_fragment_shader_interlock path. MoltenVK advertises it, but compiling those shaders
#     (Metal raster-order groups) fails on iOS GPUs. (a) the interlock path now only turns on when the new Settings > Rendering Accuracy >
#     \"Shader interlock\" switch is on (default off); the other parts of High accuracy still apply. (b) pipeline creation errors no longer
#     abort the app: the draw is skipped and the real error text is written to diagnostics.txt (`note pipeline.fail`).
edit("vita3k/renderer/src/vulkan/renderer.cpp", [
    ("extern \"C\" void *ios_get_vk_instance_proc_addr();\n",
     "extern \"C\" void *ios_get_vk_instance_proc_addr();\nextern \"C\" bool ios_allow_shader_interlock(void);\n"),
    ("    if (features.support_shader_interlock && use_high_accuracy) {\n",
     "#ifdef VITA3K_IOS\n    const bool v3k_interlock_ok = ios_allow_shader_interlock();\n#else\n    const bool v3k_interlock_ok = true;\n#endif\n"
     "    if (features.support_shader_interlock && use_high_accuracy && v3k_interlock_ok) {\n"),
])
edit("vita3k/renderer/src/vulkan/pipeline_cache.cpp", [
    ("    const auto result = state.device.createGraphicsPipeline(pipeline_cache, pipeline_info);\n"
     "    if (result.result != vk::Result::eSuccess) {\n        LOG_CRITICAL(\"Failed to create pipeline.\");\n        return nullptr;\n    }\n\n    return result.value;\n}",
     "#ifdef VITA3K_IOS\n"
     "    try {\n"
     "        const auto result = state.device.createGraphicsPipeline(pipeline_cache, pipeline_info);\n"
     "        if (result.result != vk::Result::eSuccess) {\n            LOG_CRITICAL(\"Failed to create pipeline.\");\n            return nullptr;\n        }\n"
     "        return result.value;\n"
     "    } catch (const std::exception &e) {\n"
     "        LOG_CRITICAL(\"Failed to create pipeline: {}\", e.what());\n"
     "        ios_diag_note(\"pipeline.fail\", e.what(), use_shader_interlock ? 1 : 0);\n"
     "        return nullptr;\n    }\n"
     "#else\n"
     "    const auto result = state.device.createGraphicsPipeline(pipeline_cache, pipeline_info);\n"
     "    if (result.result != vk::Result::eSuccess) {\n        LOG_CRITICAL(\"Failed to create pipeline.\");\n        return nullptr;\n    }\n\n    return result.value;\n"
     "#endif\n}"),
])

if failed:
    print("PATCH FAILED:\n  " + "\n  ".join(failed))
    sys.exit(1)
print("all iOS patches applied")
