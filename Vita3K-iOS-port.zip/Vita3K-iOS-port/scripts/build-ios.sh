#!/bin/bash
# usage: build-ios.sh <patched_source_dir>
# v0.2.0: optimisation flags + ThinLTO (automatic fallback to a non-LTO build if the LTO build fails; V3K_LTO=off skips LTO)
set -ex
SRC="$1"
export IOS_DEPS=${IOS_DEPS:-$PWD/ios-deps}
V3K_LTO="${V3K_LTO:-thin}"
cd "$SRC"

# curl's CMake "check_library_exists(socket connect)" passes spuriously on iOS (try_compile builds a static lib, nothing is linked),
# so libcurl's link interface contains -lsocket, which does not exist on iOS (the socket API lives in libSystem).
# Provide an empty stand-in so the final link succeeds.
mkdir -p "$IOS_DEPS/lib"
if [ ! -f "$IOS_DEPS/lib/libsocket.a" ]; then
  printf 'void ios_libsocket_stub(void) {}\n' > /tmp/ios_socket_stub.c
  xcrun --sdk iphoneos clang -arch arm64 -miphoneos-version-min=16.4 -c /tmp/ios_socket_stub.c -o /tmp/ios_socket_stub.o
  ar rcs "$IOS_DEPS/lib/libsocket.a" /tmp/ios_socket_stub.o
fi

# $1 = lto | nolto.  Every step ends with `|| return 1` because errexit is disabled inside functions that run as an `if` condition.
configure_and_build() {
  local mode="$1"
  local opt="-O3 -DNDEBUG -fno-stack-protector"   # Release already means -O3; the stack protector (on by default for iOS) costs a little in hot code
  local lflags="-L$IOS_DEPS/lib"
  if [ "$mode" = lto ]; then
    opt="$opt -flto=thin"
    lflags="$lflags -flto=thin -Wl,-cache_path_lto,$PWD/build-ios-lto-cache"
    mkdir -p "$PWD/build-ios-lto-cache"
  fi
  rm -rf build-ios
  # CMake seeds CMAKE_<LANG>_FLAGS from these on the first configure
  export CFLAGS="$opt" CXXFLAGS="$opt" OBJCFLAGS="$opt" OBJCXXFLAGS="$opt"

  cmake -S . -B build-ios -G Ninja \
    -DCMAKE_EXE_LINKER_FLAGS="$lflags" \
    -DCMAKE_TOOLCHAIN_FILE="$PWD/ios/ios-toolchain.cmake" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=16.4 \
    -DUSE_DISCORD_RICH_PRESENCE=OFF \
    -DOPENSSL_ROOT_DIR="$IOS_DEPS" -DOPENSSL_USE_STATIC_LIBS=TRUE \
    -DBoost_USE_STATIC_LIBS=ON -DBoost_USE_STATIC_RUNTIME=ON -DBoost_NO_WARN_NEW_VERSIONS=1 \
    -DCMAKE_PREFIX_PATH="$IOS_DEPS" \
    -DBUILD_TESTING=OFF -DDYNARMIC_TESTS=OFF \
    -DCMAKE_OSX_ARCHITECTURES=arm64 -DCAPSTONE_BUILD_MACOS_THIN=ON || return 1

  # safety net: fail early (with a clear message) if any target still gets a non-arm64 -arch flag
  if grep -q -- '-arch x86_64' build-ios/build.ninja; then
    echo "ERROR: build.ninja still contains '-arch x86_64' (some CMakeLists overrides CMAKE_OSX_ARCHITECTURES):"
    grep -n -- '-arch x86_64' build-ios/build.ninja | head -5 | cut -c1-200
    return 1
  fi
  cmake --build build-ios --target vita3k -j"$(sysctl -n hw.ncpu)" || return 1
}

BUILD_OK=""
if [ "$V3K_LTO" != "off" ]; then
  echo "=== build attempt 1: ThinLTO ==="
  if configure_and_build lto; then
    BUILD_OK=1
    echo "=== ThinLTO build OK ==="
  else
    echo "=== ThinLTO build FAILED -> retrying without LTO (the first error is in the log above) ==="
  fi
fi
if [ -z "$BUILD_OK" ]; then
  echo "=== build: no LTO ==="
  configure_and_build nolto
fi
