// iOS port: transparent compression for the on-disk shader cache. See cache_compress.h.
#include <renderer/cache_compress.h>

#include <miniz.h>

#include <atomic>
#include <cstring>
#include <fstream>
#include <boost/system/error_code.hpp>

#ifdef VITA3K_IOS
extern "C" bool ios_cache_compress_enabled(void);
#endif

namespace renderer::cachez {

namespace {
constexpr char k_magic[4] = { 'V', '3', 'K', 'Z' };
constexpr size_t k_header = 12; // magic(4) + raw size(4) + adler32(4)
constexpr int k_level = 4; // fast enough for an A11, still ~3-5x on SPIR-V
constexpr size_t k_min_size = 128; // not worth it below this

std::atomic<uint64_t> g_raw{ 0 }, g_stored{ 0 }, g_files_w{ 0 }, g_files_r{ 0 };

bool enabled() {
#ifdef VITA3K_IOS
    return ios_cache_compress_enabled();
#else
    return true;
#endif
}

void put_u32(uint8_t *p, uint32_t v) {
    p[0] = static_cast<uint8_t>(v);
    p[1] = static_cast<uint8_t>(v >> 8);
    p[2] = static_cast<uint8_t>(v >> 16);
    p[3] = static_cast<uint8_t>(v >> 24);
}
uint32_t get_u32(const uint8_t *p) {
    return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) | (static_cast<uint32_t>(p[2]) << 16) | (static_cast<uint32_t>(p[3]) << 24);
}

bool write_raw(const fs::path &path, const void *data, size_t size) {
    fs::path tmp = path;
    tmp += ".tmp";
    {
        fs::ofstream os(tmp, std::ios::out | std::ios::binary | std::ios::trunc);
        if (!os.is_open())
            return false;
        os.write(static_cast<const char *>(data), static_cast<std::streamsize>(size));
        os.flush();
        if (!os.good())
            return false;
    }
    boost::system::error_code ec;
    fs::rename(tmp, path, ec);
    if (ec) {
        // rename can fail if the target is locked / exists on some filesystems: fall back to remove + rename
        fs::remove(path, ec);
        ec.clear();
        fs::rename(tmp, path, ec);
        if (ec) {
            fs::remove(tmp, ec);
            return false;
        }
    }
    return true;
}
} // namespace

bool write_file(const fs::path &path, const void *data, size_t size) {
    if (size == 0)
        return false;

    if (enabled() && size >= k_min_size && size < 0x7fffffffu) {
        mz_ulong bound = mz_compressBound(static_cast<mz_ulong>(size));
        std::vector<uint8_t> buf(k_header + bound);
        mz_ulong out_len = bound;
        const int rc = mz_compress2(buf.data() + k_header, &out_len, static_cast<const unsigned char *>(data), static_cast<mz_ulong>(size), k_level);
        if (rc == MZ_OK && k_header + out_len < size) {
            std::memcpy(buf.data(), k_magic, 4);
            put_u32(buf.data() + 4, static_cast<uint32_t>(size));
            put_u32(buf.data() + 8, static_cast<uint32_t>(mz_adler32(MZ_ADLER32_INIT, static_cast<const unsigned char *>(data), size)));
            if (write_raw(path, buf.data(), k_header + out_len)) {
                g_raw += size;
                g_stored += k_header + out_len;
                ++g_files_w;
                return true;
            }
            return false;
        }
    }

    const bool ok = write_raw(path, data, size);
    if (ok) {
        g_raw += size;
        g_stored += size;
    }
    return ok;
}

bool read_file(const fs::path &path, std::vector<uint8_t> &out) {
    out.clear();
    fs::ifstream is(path, std::ios::in | std::ios::binary);
    if (!is.is_open())
        return false;
    is.seekg(0, std::ios::end);
    const auto end = is.tellg();
    if (end <= 0)
        return false;
    const size_t size = static_cast<size_t>(end);
    is.seekg(0);
    out.resize(size);
    is.read(reinterpret_cast<char *>(out.data()), static_cast<std::streamsize>(size));
    if (!is) {
        out.clear();
        return false;
    }

    // plain file (older cache or compression was off / not worth it)
    if (size < k_header || std::memcmp(out.data(), k_magic, 4) != 0)
        return true;

    const uint32_t raw_size = get_u32(out.data() + 4);
    const uint32_t adler = get_u32(out.data() + 8);
    // sanity limit: a single cache file is never above 1 GiB
    if (raw_size == 0 || raw_size > (1u << 30)) {
        out.clear();
        return false;
    }
    std::vector<uint8_t> raw(raw_size);
    mz_ulong dst_len = raw_size;
    const int rc = mz_uncompress(raw.data(), &dst_len, out.data() + k_header, static_cast<mz_ulong>(size - k_header));
    if (rc != MZ_OK || dst_len != raw_size
        || static_cast<uint32_t>(mz_adler32(MZ_ADLER32_INIT, raw.data(), raw.size())) != adler) {
        out.clear();
        return false; // corrupt: callers treat it like a missing file and regenerate
    }
    ++g_files_r;
    out = std::move(raw);
    return true;
}

void stats(uint64_t &raw_bytes, uint64_t &stored_bytes, uint64_t &files_compressed, uint64_t &files_read_compressed) {
    raw_bytes = g_raw.load();
    stored_bytes = g_stored.load();
    files_compressed = g_files_w.load();
    files_read_compressed = g_files_r.load();
}

} // namespace renderer::cachez
