// iOS port: transparent compression for the on-disk shader cache (SPIR-V / GLSL files + Vulkan pipeline cache blob).
#pragma once

#include <util/fs.h>

#include <cstddef>
#include <cstdint>
#include <vector>

namespace renderer::cachez {

// Writes `data` to `path`. When compression is enabled in Settings and actually makes the file smaller, the file is stored as
// "V3KZ" + raw size + adler32 + zlib stream, otherwise as plain bytes. The write goes through "<path>.tmp" + rename, so a file
// is never left half-written if iOS kills the app.
bool write_file(const fs::path &path, const void *data, size_t size);

// Reads a whole file. Compressed files are inflated (and verified); plain files (older caches) are returned unchanged.
// Returns false if the file is missing, empty or corrupt.
bool read_file(const fs::path &path, std::vector<uint8_t> &out);

// Totals since the app started (for diagnostics.txt).
void stats(uint64_t &raw_bytes, uint64_t &stored_bytes, uint64_t &files_compressed, uint64_t &files_read_compressed);

} // namespace renderer::cachez
