#pragma once
bool ios_jit_available();          // true if RWX/JIT memory can be used right now
bool ios_jit_try_enable();         // try to enable JIT by ourselves (TrollStore / entitled builds); returns ios_jit_available()
extern "C" int ios_jit_use_map_jit(void); // 1: allocate JIT memory with MAP_JIT (entitled), 0: plain RWX (debugger attached)
extern "C" void ios_thread_qos(int role); // see ios_jit.cpp
