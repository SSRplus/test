// iOS replacement for SceNet/macos_net_helper.cpp (SystemConfiguration's SCDynamicStore is unavailable on iOS)
#include "macos_net_helper.h"
#include <cstring>

bool get_primary_interface_name(char *dest, size_t bufferSize) {
    if (!dest || bufferSize < 4)
        return false;
    std::strncpy(dest, "en0", bufferSize - 1);
    dest[bufferSize - 1] = '\0';
    return true;
}

// iOS hides real MAC addresses, so let SceNet fall back to its fake MAC.
bool get_mac_address(const char *, uint8_t[6]) {
    return false;
}
