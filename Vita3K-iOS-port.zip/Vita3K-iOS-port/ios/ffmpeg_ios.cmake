# Replaces external/ffmpeg (ffmpeg-core has no iOS build). Uses static libs built by scripts/deps-ios.sh
set(V3K_FFMPEG_ROOT "$ENV{IOS_DEPS}")
add_library(ffmpeg INTERFACE)
target_include_directories(ffmpeg INTERFACE "${V3K_FFMPEG_ROOT}/include")
foreach(l avformat avcodec swresample swscale avutil)
  target_link_libraries(ffmpeg INTERFACE "${V3K_FFMPEG_ROOT}/lib/lib${l}.a")
endforeach()
target_link_libraries(ffmpeg INTERFACE "-framework CoreFoundation" "-framework CoreVideo" "-framework CoreMedia" "-framework Security" z bz2 iconv)
