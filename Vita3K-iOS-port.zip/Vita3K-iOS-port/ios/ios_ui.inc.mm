// ---------------------------------------------------------------------------------------------
// Vita3K iOS UI (included by ios_main.mm). Layout follows Vita3K Plus (Qt):
//   Games tab    = application list + per-game context menu (Boot / Custom Config / Info / Copy / Delete)
//   Manage tab   = File > Install Firmware / Package / Archive / License
//   Settings tab = Core, CPU, Graphics, Audio, System, Emulator, Debug (+ Presets), Global or Custom Config per game
//   Logs tab     = Diagnostics, Emulator log, Crash report, Previous run (search + level filter + share)
// ---------------------------------------------------------------------------------------------

#define V3K_ACCENT [UIColor colorWithRed:0.16 green:0.49 blue:0.89 alpha:1.0]
static void v3k_reload_games();

// ============================ Settings schema (mirrors Qt settings_dialog.ui tabs / group boxes) ============================
#define ROW_B(k, n) @{ @"k" : k, @"n" : n }
#define ROW_C(k, n, labels, vals) @{ @"k" : k, @"n" : n, @"c" : labels, @"v" : vals }
static NSArray *settings_categories() {
    static NSArray *cats;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        cats = @[
            @{ @"name" : @"Core", @"icon" : @"cube", @"sections" : @[
                @{ @"t" : @"Module Loading Mode", @"f" : @"Automatic uses the built-in (HLE) modules. Manual/Auto & Manual load the game's own system modules (LLE) from the firmware.", @"rows" : @[
                    ROW_C(@"modulesmode", @"Mode", (@[ @"Automatic", @"Auto & Manual", @"Manual" ]), (@[ @0, @1, @2 ])) ] },
            ] },
            @{ @"name" : @"CPU", @"icon" : @"cpu", @"sections" : @[
                @{ @"t" : @"Dynarmic", @"f" : @"Fast floating point skips some NEON/VFP edge-case handling (denormals, NaN payloads, reciprocal-estimate precision). Often a few % faster in NEON-heavy games; if a game shows broken physics / NaN glitches, turn it off. Applies when a game starts.", @"rows" : @[
                    ROW_B(@"cpuopt", @"CPU optimisation"),
                    ROW_B(@"fastfp", @"Fast floating point (unsafe)"),
                    ROW_C(@"cpupool", @"CPU pool size", (@[ @"4", @"6", @"8", @"10 (default)", @"12", @"16" ]), (@[ @4, @6, @8, @10, @12, @16 ])) ] },
                @{ @"t" : @"Memory (JIT)", @"f" : @"Dynarmic reserves a JIT code cache for EVERY guest thread and iOS counts it fully against the jetsam limit. Lower = less RAM; too low = slower (cache flushed often). Applies when a game starts.", @"rows" : @[
                    ROW_C(@"jitmain", @"JIT cache: main game thread", (@[ @"16 MB", @"32 MB (low RAM)", @"64 MB (default)", @"96 MB", @"128 MB" ]), (@[ @16, @32, @64, @96, @128 ])),
                    ROW_C(@"jitthread", @"JIT cache: each other thread", (@[ @"4 MB", @"8 MB (low RAM)", @"16 MB (default)", @"32 MB", @"64 MB" ]), (@[ @4, @8, @16, @32, @64 ])) ] },
            ] },
            @{ @"name" : @"Graphics", @"icon" : @"display", @"sections" : @[
                @{ @"t" : @"Backend Renderer", @"f" : @"OpenGL ES 3.0 is experimental on iOS; if it cannot start, the app falls back to Vulkan (MoltenVK) automatically.", @"rows" : @[
                    ROW_C(@"backend", @"Renderer", (@[ @"Vulkan (MoltenVK)", @"OpenGL ES (experimental)" ]), (@[ @"Vulkan", @"OpenGL" ])),
                    ROW_C(@"filter", @"Screen filter", (@[ @"Nearest", @"Bilinear", @"Bicubic", @"FXAA", @"FSR" ]), (@[ @"Nearest", @"Bilinear", @"Bicubic", @"FXAA", @"FSR" ])) ] },
                @{ @"t" : @"Image Quality", @"rows" : @[
                    ROW_C(@"res", @"Internal resolution", (@[ @"1x (960×544)", @"1.5x", @"2x", @"3x" ]), (@[ @1.0, @1.5, @2.0, @3.0 ])),
                    ROW_C(@"aniso", @"Anisotropic filtering", (@[ @"Off", @"2x", @"4x", @"8x", @"16x" ]), (@[ @1, @2, @4, @8, @16 ])) ] },
                @{ @"t" : @"Rendering Accuracy", @"rows" : @[
                    ROW_B(@"highacc", @"High accuracy"),
                    ROW_B(@"nosurfsync", @"Disable surface sync (faster; off fixes some colours)"),
                    ROW_B(@"vsync", @"V-Sync"),
                    ROW_B(@"asyncpipe", @"Async pipeline compilation (less stutter; off = no missing geometry)"),
                    ROW_C(@"mapping", @"Memory mapping", (@[ @"Disabled (least RAM)", @"Double buffer", @"Page table" ]), (@[ @"disabled", @"double-buffer", @"page-table" ])) ] },
                @{ @"t" : @"Shaders", @"f" : @"“Accurate shader math” turns off Metal fast-math; it is the main fix for stripes / broken geometry from translated shaders.", @"rows" : @[
                    ROW_B(@"accmath", @"Accurate shader math (fixes stripes)"),
                    ROW_B(@"shadercache", @"Shader cache"),
                    ROW_B(@"spirv", @"SPIR-V shader path"),
                    ROW_B(@"showcompile", @"Show “compiling shaders” message"),
                    ROW_B(@"fpshack", @"FPS hack") ] },
                @{ @"t" : @"Textures", @"rows" : @[
                    ROW_B(@"texcache", @"Texture cache (off saves RAM)"),
                    ROW_B(@"hashless", @"Hashless texture cache"),
                    ROW_B(@"importtex", @"Import textures"),
                    ROW_B(@"exporttex", @"Export textures"),
                    ROW_B(@"exportpng", @"Export as PNG") ] },
                @{ @"t" : @"Display", @"rows" : @[
                    ROW_B(@"stretch", @"Stretch the display area"),
                    ROW_B(@"pixelperfect", @"Pixel-perfect full-screen HD") ] },
            ] },
            @{ @"name" : @"Audio", @"icon" : @"speaker.wave.2", @"sections" : @[
                @{ @"t" : @"Volume", @"rows" : @[
                    ROW_C(@"volume", @"Audio volume", (@[ @"0%", @"25%", @"50%", @"75%", @"100%" ]), (@[ @0, @25, @50, @75, @100 ])) ] },
                @{ @"t" : @"Features", @"rows" : @[ ROW_B(@"ngs", @"NGS audio engine") ] },
            ] },
            @{ @"name" : @"System", @"icon" : @"gamecontroller", @"sections" : @[
                @{ @"t" : @"Console Settings", @"rows" : @[
                    ROW_C(@"sysbutton", @"Enter button", (@[ @"Cross (✕)", @"Circle (○)" ]), (@[ @1, @0 ])),
                    ROW_B(@"pstv", @"PS TV mode"),
                    ROW_B(@"showmode", @"Show mode"),
                    ROW_B(@"demomode", @"Demo mode") ] },
                @{ @"t" : @"Region and Language", @"rows" : @[
                    ROW_C(@"syslang", @"System language",
                        (@[ @"日本語", @"English (US)", @"Français", @"Español", @"Deutsch", @"Italiano", @"Nederlands", @"Português (PT)", @"Русский", @"한국어", @"繁體中文", @"简体中文", @"Suomi", @"Svenska", @"Dansk", @"Norsk", @"Polski", @"Português (BR)", @"English (GB)", @"Türkçe" ]),
                        (@[ @0, @1, @2, @3, @4, @5, @6, @7, @8, @9, @10, @11, @12, @13, @14, @15, @16, @17, @18, @19 ])),
                    ROW_C(@"sysdate", @"Date format", (@[ @"YYYY/MM/DD", @"DD/MM/YYYY", @"MM/DD/YYYY" ]), (@[ @0, @1, @2 ])),
                    ROW_C(@"systime", @"Time format", (@[ @"12-hour", @"24-hour" ]), (@[ @0, @1 ])) ] },
            ] },
            @{ @"name" : @"Emulator", @"icon" : @"slider.horizontal.3", @"sections" : @[
                @{ @"t" : @"Performance Overlay", @"rows" : @[
                    ROW_B(@"overlay", @"Show overlay in game"),
                    ROW_C(@"overlaydetail", @"Detail", (@[ @"Minimum", @"Low", @"Medium", @"Maximum" ]), (@[ @0, @1, @2, @3 ])),
                    ROW_C(@"overlaypos", @"Position", (@[ @"Top left", @"Top center", @"Top right", @"Bottom left", @"Bottom center", @"Bottom right" ]), (@[ @0, @1, @2, @3, @4, @5 ])) ] },
                @{ @"t" : @"Logging", @"f" : @"Emulator log level. Lower levels (Trace/Debug) write a lot and use more RAM; Info is recommended.", @"rows" : @[
                    ROW_C(@"loglevel", @"Log level", (@[ @"Trace", @"Debug", @"Info", @"Warning", @"Error", @"Critical", @"Off" ]), (@[ @0, @1, @2, @3, @4, @5, @6 ])),
                    ROW_B(@"logcompat", @"Log compatibility warnings"),
                    ROW_B(@"archivelog", @"Archive log on exit") ] },
                @{ @"t" : @"Storage and Capture", @"rows" : @[
                    ROW_C(@"screenshot", @"Screenshot format", (@[ @"None", @"JPEG", @"PNG" ]), (@[ @0, @1, @2 ])),
                    ROW_C(@"fileloaddelay", @"File loading delay", (@[ @"0 ms", @"50 ms", @"100 ms", @"250 ms", @"500 ms" ]), (@[ @0, @50, @100, @250, @500 ])) ] },
            ] },
            @{ @"name" : @"Debug", @"icon" : @"ant", @"sections" : @[
                @{ @"t" : @"Diagnostics (this app)", @"f" : @"Writes fps, RAM used/left (jetsam watch) and audio state to diagnostics.txt every second for 40 s, then every 5 s.", @"rows" : @[
                    ROW_B(@"perflog", @"Log FPS / RAM / audio") ] },
                @{ @"t" : @"Graphics", @"rows" : @[
                    ROW_B(@"logshaders", @"Log active shaders"),
                    ROW_B(@"loguniforms", @"Log uniforms"),
                    ROW_B(@"colordebug", @"Colour surface debug"),
                    ROW_B(@"validation", @"Vulkan validation layer") ] },
            ] },
        ];
    });
    return cats;
}
static NSDictionary *settings_presets() {
    return @{
        @"Performance" : @{ @"jitmain" : @96, @"jitthread" : @32, @"mapping" : @"disabled", @"asyncpipe" : @YES, @"nosurfsync" : @YES, @"accmath" : @NO, @"texcache" : @YES, @"res" : @1.0, @"aniso" : @1, @"highacc" : @NO, @"fastfp" : @YES, @"hashless" : @YES, @"loglevel" : @3, @"perflog" : @NO },
        @"Balanced (default)" : @{ @"jitmain" : @64, @"jitthread" : @16, @"mapping" : @"disabled", @"asyncpipe" : @YES, @"nosurfsync" : @YES, @"accmath" : @YES, @"texcache" : @YES, @"res" : @1.0, @"aniso" : @1, @"highacc" : @NO, @"fastfp" : @NO, @"hashless" : @NO, @"loglevel" : @2, @"perflog" : @YES },
        @"Compatibility (fix graphics)" : @{ @"jitmain" : @64, @"jitthread" : @16, @"mapping" : @"disabled", @"asyncpipe" : @NO, @"nosurfsync" : @NO, @"accmath" : @YES, @"spirv" : @NO, @"texcache" : @YES, @"res" : @1.0, @"aniso" : @1, @"highacc" : @YES, @"fastfp" : @NO, @"hashless" : @NO },
        @"Low RAM (avoid jetsam)" : @{ @"jitmain" : @32, @"jitthread" : @8, @"mapping" : @"disabled", @"texcache" : @NO, @"res" : @1.0, @"aniso" : @1, @"asyncpipe" : @YES, @"nosurfsync" : @YES, @"accmath" : @YES, @"highacc" : @NO, @"cpupool" : @6, @"loglevel" : @3, @"fastfp" : @NO },
    };
}
static NSString *choice_label(NSDictionary *r) {
    id cur = S(r[@"k"]);
    NSArray *vals = r[@"v"];
    for (NSUInteger i = 0; i < vals.count; i++) {
        id v = vals[i];
        if ([v isEqual:cur] || ([v isKindOfClass:NSNumber.class] && [cur isKindOfClass:NSNumber.class] && fabs([v doubleValue] - [cur doubleValue]) < 1e-6))
            return r[@"c"][i];
    }
    return [NSString stringWithFormat:@"%@", cur];
}

// ============================ Settings: one category page ============================
@interface V3KSettingsPage : UITableViewController
- (instancetype)initWithCategory:(NSDictionary *)cat game:(NSString *)game;
@end
@implementation V3KSettingsPage {
    NSDictionary *_cat;
    NSString *_game;
}
- (instancetype)initWithCategory:(NSDictionary *)cat game:(NSString *)game {
    self = [super initWithStyle:UITableViewStyleInsetGrouped];
    _cat = cat;
    _game = game;
    self.title = cat[@"name"];
    return self;
}
- (void)viewWillAppear:(BOOL)a { [super viewWillAppear:a]; g_edit_game = _game; [self.tableView reloadData]; }
- (NSArray *)secs { return _cat[@"sections"]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv { return (NSInteger)[self secs].count; }
- (NSString *)tableView:(UITableView *)tv titleForHeaderInSection:(NSInteger)s { return [self secs][s][@"t"]; }
- (NSString *)tableView:(UITableView *)tv titleForFooterInSection:(NSInteger)s { return [self secs][s][@"f"]; }
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)s { return (NSInteger)[[self secs][s][@"rows"] count]; }
- (NSDictionary *)rowAt:(NSIndexPath *)ip { return [self secs][ip.section][@"rows"][ip.row]; }
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    NSDictionary *r = [self rowAt:ip];
    cell.textLabel.text = r[@"n"];
    cell.textLabel.numberOfLines = 0;
    if (r[@"c"]) {
        cell.detailTextLabel.text = choice_label(r);
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISwitch *sw = [UISwitch new];
        sw.on = [S(r[@"k"]) boolValue];
        sw.onTintColor = V3K_ACCENT;
        sw.tag = ip.section * 1000 + ip.row;
        [sw addTarget:self action:@selector(toggled:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = sw;
    }
    return cell;
}
- (void)toggled:(UISwitch *)sw {
    g_edit_game = _game;
    S_set([self secs][sw.tag / 1000][@"rows"][sw.tag % 1000][@"k"], @(sw.on));
}
- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [tv deselectRowAtIndexPath:ip animated:YES];
    NSDictionary *r = [self rowAt:ip];
    if (!r[@"c"]) return;
    UIAlertController *a = [UIAlertController alertControllerWithTitle:r[@"n"] message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    NSString *cur = choice_label(r);
    for (NSUInteger i = 0; i < [r[@"c"] count]; i++) {
        id val = r[@"v"][i];
        NSString *lab = r[@"c"][i];
        UIAlertAction *act = [UIAlertAction actionWithTitle:[lab isEqual:cur] ? [@"✓ " stringByAppendingString:lab] : lab style:UIAlertActionStyleDefault handler:^(UIAlertAction *) {
            g_edit_game = self->_game;
            S_set(r[@"k"], val);
            [tv reloadRowsAtIndexPaths:@[ ip ] withRowAnimation:UITableViewRowAnimationNone];
        }];
        [a addAction:act];
    }
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    a.popoverPresentationController.sourceView = tv;
    a.popoverPresentationController.sourceRect = [tv rectForRowAtIndexPath:ip];
    [self presentViewController:a animated:YES completion:nil];
}
@end

// ============================ Settings: root (categories) — global or per game ============================
@interface V3KSettingsRoot : UITableViewController
- (instancetype)initWithGame:(NSString *)game gameTitle:(NSString *)gtitle;
@end
@implementation V3KSettingsRoot {
    NSString *_game, *_gtitle;
}
- (instancetype)initWithGame:(NSString *)game gameTitle:(NSString *)gtitle {
    self = [super initWithStyle:UITableViewStyleInsetGrouped];
    _game = game;
    _gtitle = gtitle;
    self.title = game ? @"Custom Config" : @"Settings";
    return self;
}
- (void)viewWillAppear:(BOOL)a { [super viewWillAppear:a]; g_edit_game = _game; [self.tableView reloadData]; }
// sections: 0 = profile/presets, 1 = categories, 2 = reset
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv { return 3; }
- (NSString *)tableView:(UITableView *)tv titleForHeaderInSection:(NSInteger)s { return s == 0 ? (_game ? @"Game" : @"Presets") : s == 1 ? @"Categories" : nil; }
- (NSString *)tableView:(UITableView *)tv titleForFooterInSection:(NSInteger)s {
    if (s == 0 && _game) return @"Only the options you change here are overridden for this game; everything else follows the global settings.";
    if (s == 2) return [NSString stringWithFormat:@"Vita3K iOS %@ — changes apply when the next game starts.", NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"]];
    return nil;
}
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)s {
    if (s == 0) return _game ? 2 : 1;
    if (s == 1) return (NSInteger)settings_categories().count;
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    if (ip.section == 0) {
        if (_game && ip.row == 0) {
            cell.textLabel.text = _gtitle;
            cell.textLabel.numberOfLines = 0;
            cell.detailTextLabel.text = game_has_custom(_game) ? @"Custom" : @"Global";
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        } else {
            cell.textLabel.text = _game ? @"Apply preset…" : @"Apply preset…";
            cell.textLabel.textColor = V3K_ACCENT;
            cell.imageView.image = [UIImage systemImageNamed:@"wand.and.stars"];
        }
    } else if (ip.section == 1) {
        NSDictionary *c = settings_categories()[ip.row];
        cell.textLabel.text = c[@"name"];
        cell.imageView.image = [UIImage systemImageNamed:c[@"icon"]];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else {
        cell.textLabel.text = _game ? @"Remove custom settings" : @"Reset all settings";
        cell.textLabel.textColor = UIColor.systemRedColor;
    }
    return cell;
}
- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [tv deselectRowAtIndexPath:ip animated:YES];
    g_edit_game = _game;
    if (ip.section == 1) {
        [self.navigationController pushViewController:[[V3KSettingsPage alloc] initWithCategory:settings_categories()[ip.row] game:_game] animated:YES];
    } else if (ip.section == 2) {
        if (_game) game_clear_custom(_game); else S_reset();
        [tv reloadData];
    } else if (ip.section == 0 && (!_game || ip.row == 1)) {
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Preset" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        NSDictionary *presets = settings_presets();
        for (NSString *name in @[ @"Performance", @"Balanced (default)", @"Compatibility (fix graphics)", @"Low RAM (avoid jetsam)" ]) {
            [a addAction:[UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(UIAlertAction *) {
                g_edit_game = self->_game;
                [presets[name] enumerateKeysAndObjectsUsingBlock:^(id k, id v, BOOL *) { S_set(k, v); }];
                [tv reloadData];
            }]];
        }
        [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
        a.popoverPresentationController.sourceView = tv;
        a.popoverPresentationController.sourceRect = [tv rectForRowAtIndexPath:ip];
        [self presentViewController:a animated:YES completion:nil];
    }
}
@end

// ============================ Logs tab ============================
static NSString *v3k_docs_dir() {
    return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"Vita3K"];
}
static NSString *find_emulator_log() {
    NSString *dir = v3k_docs_dir();
    for (NSString *c in @[ @"Vita3K.log", @"vita3k.log", @"log/Vita3K.log", @"logs/Vita3K.log" ]) {
        NSString *p = [dir stringByAppendingPathComponent:c];
        if ([[NSFileManager defaultManager] fileExistsAtPath:p]) return p;
    }
    return nil;
}
static NSString *read_tail(NSString *path, NSUInteger maxBytes) {
    if (!path) return nil;
    NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:path];
    if (!fh) return nil;
    unsigned long long size = [fh seekToEndOfFile];
    unsigned long long from = size > maxBytes ? size - maxBytes : 0;
    [fh seekToFileOffset:from];
    NSData *d = [fh readDataToEndOfFile];
    [fh closeFile];
    NSString *s = [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] ?: @"";
    if (from > 0) {
        NSRange nl = [s rangeOfString:@"\n"];
        if (nl.location != NSNotFound) s = [s substringFromIndex:nl.location + 1];
        s = [@"… (earlier lines cut — use Share for the full file)\n" stringByAppendingString:s];
    }
    return s;
}

@interface V3KLogs : UIViewController <UISearchResultsUpdating>
@end
@implementation V3KLogs {
    UISegmentedControl *_seg;
    UITextView *_tv;
    NSString *_raw;
    NSString *_query;
    int _level; // 0 all, 1 warn+, 2 errors
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Logs";
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    _seg = [[UISegmentedControl alloc] initWithItems:@[ @"Diagnostics", @"Emulator", @"Crash", @"Previous" ]];
    _seg.selectedSegmentIndex = 0;
    [_seg addTarget:self action:@selector(reloadLog) forControlEvents:UIControlEventValueChanged];
    self.navigationItem.titleView = _seg;
    _tv = [[UITextView alloc] initWithFrame:self.view.bounds];
    _tv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _tv.editable = NO;
    _tv.alwaysBounceVertical = YES;
    _tv.backgroundColor = UIColor.systemBackgroundColor;
    _tv.textContainerInset = UIEdgeInsetsMake(8, 6, 8, 6);
    [self.view addSubview:_tv];
    UISearchController *sc = [[UISearchController alloc] initWithSearchResultsController:nil];
    sc.searchResultsUpdater = self;
    sc.obscuresBackgroundDuringPresentation = NO;
    sc.searchBar.placeholder = @"Find in log…";
    self.navigationItem.searchController = sc;
    self.navigationItem.hidesSearchBarWhenScrolling = NO;
    UIMenu *lv = [UIMenu menuWithTitle:@"Level" children:@[
        [UIAction actionWithTitle:@"All" image:nil identifier:nil handler:^(UIAction *) { self->_level = 0; [self render]; }],
        [UIAction actionWithTitle:@"Warnings & errors" image:nil identifier:nil handler:^(UIAction *) { self->_level = 1; [self render]; }],
        [UIAction actionWithTitle:@"Errors only" image:nil identifier:nil handler:^(UIAction *) { self->_level = 2; [self render]; }],
    ]];
    self.navigationItem.rightBarButtonItems = @[
        [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"square.and.arrow.up"] style:UIBarButtonItemStylePlain target:self action:@selector(shareLog)],
        [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"line.3.horizontal.decrease.circle"] menu:lv],
        [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"doc.on.doc"] style:UIBarButtonItemStylePlain target:self action:@selector(copyLog)],
    ];
    self.navigationItem.leftBarButtonItems = @[
        [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"arrow.clockwise"] style:UIBarButtonItemStylePlain target:self action:@selector(reloadLog)],
        [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"arrow.down.to.line"] style:UIBarButtonItemStylePlain target:self action:@selector(toBottom)],
    ];
}
- (void)viewWillAppear:(BOOL)a { [super viewWillAppear:a]; [self reloadLog]; }
- (NSString *)currentPath {
    NSString *d = v3k_docs_dir();
    switch (_seg.selectedSegmentIndex) {
    case 0: return [d stringByAppendingPathComponent:@"diagnostics.txt"];
    case 1: return find_emulator_log();
    case 2: return [d stringByAppendingPathComponent:@"crash_report.txt"];
    default: return [d stringByAppendingPathComponent:@"diagnostics.prev.txt"];
    }
}
- (void)reloadLog {
    NSString *p = [self currentPath];
    _raw = read_tail(p, 400 * 1024);
    if (!_raw) _raw = _seg.selectedSegmentIndex == 2 ? @"No crash report yet.\n\nIf the app crashes or iOS kills it during a game, a report (with the game's title ID) is created here on the next launch." : @"(file not found yet — start a game first)";
    [self render];
    [self toBottom];
}
- (void)updateSearchResultsForSearchController:(UISearchController *)sc { _query = sc.searchBar.text; [self render]; }
- (BOOL)line:(NSString *)l passes:(int)level {
    if (level == 0) return YES;
    if ([l containsString:@"|E|"] || [l containsString:@"|C|"] || [l containsString:@"FAIL"] || [l containsString:@"[CRASH]"]) return YES;
    if (level == 1 && ([l containsString:@"|W|"] || [l containsString:@" WARN "])) return YES;
    return NO;
}
- (void)render {
    UIFont *font = [UIFont monospacedSystemFontOfSize:10.5 weight:UIFontWeightRegular];
    NSMutableAttributedString *out = [NSMutableAttributedString new];
    NSDictionary *base = @{ NSFontAttributeName : font, NSForegroundColorAttributeName : UIColor.labelColor };
    NSArray *lines = [_raw componentsSeparatedByString:@"\n"];
    if (lines.count > 6000) lines = [lines subarrayWithRange:NSMakeRange(lines.count - 6000, 6000)];
    for (NSString *l in lines) {
        if (_query.length && [l rangeOfString:_query options:NSCaseInsensitiveSearch].location == NSNotFound) continue;
        if (![self line:l passes:_level]) continue;
        UIColor *c = UIColor.labelColor;
        if ([l containsString:@"|E|"] || [l containsString:@"|C|"] || [l containsString:@"FAIL"] || [l containsString:@"[CRASH]"]) c = UIColor.systemRedColor;
        else if ([l containsString:@"|W|"] || [l containsString:@" WARN "]) c = UIColor.systemOrangeColor;
        else if ([l containsString:@" OK  "]) c = UIColor.systemGreenColor;
        else if ([l containsString:@"|D|"] || [l hasPrefix:@"#"]) c = UIColor.secondaryLabelColor;
        NSMutableDictionary *at = [base mutableCopy];
        at[NSForegroundColorAttributeName] = c;
        [out appendAttributedString:[[NSAttributedString alloc] initWithString:[l stringByAppendingString:@"\n"] attributes:at]];
    }
    _tv.attributedText = out;
}
- (void)toBottom {
    if (_tv.text.length) [_tv scrollRangeToVisible:NSMakeRange(_tv.text.length - 1, 1)];
}
- (void)copyLog { UIPasteboard.generalPasteboard.string = _raw ?: @""; }
- (void)shareLog {
    NSString *p = [self currentPath];
    if (p && [[NSFileManager defaultManager] fileExistsAtPath:p]) share_file(self, p);
}
@end

// ============================ Install (Manage tab) ============================
static void v3k_install(UIViewController *host, NSURL *url, NSString *mode, void (^done)(void)) {
    UIAlertController *busy = [UIAlertController alertControllerWithTitle:@"Installing…" message:@"Please wait, this can take several minutes." preferredStyle:UIAlertControllerStyleAlert];
    [host presentViewController:busy animated:YES completion:nil];
    std::string path = url.path.UTF8String;
    std::string ext = url.pathExtension.lowercaseString.UTF8String;
    std::string fname = url.lastPathComponent.lowercaseString.UTF8String;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        bool ok = false;
        std::string detail;
        try {
            if ([mode isEqual:@"license"]) {
                NSData *d = [NSData dataWithContentsOfFile:[NSString stringWithUTF8String:path.c_str()]];
                std::vector<uint8_t> bin((const uint8_t *)d.bytes, (const uint8_t *)d.bytes + d.length);
                if (bin.size() >= 0x50) {
                    const std::string tid = install_work_bin(bin, g_emuenv->vita_fs_path);
                    ok = !tid.empty();
                    detail = ok ? "License installed for " + tid + "." : "Not a valid work.bin / .rif.";
                } else {
                    detail = "File is too small to be a work.bin / .rif.";
                }
            } else if (ext == "pup") {
                const std::string ver = install_pup(g_emuenv->vita_fs_path, fs::path(path), [](uint32_t) {});
                ok = !ver.empty();
                detail = ok ? "Firmware " + ver : "";
            } else if (ext == "pkg") {
                std::string zrif = find_pkg_zrif(fs::path(path), g_emuenv->vita_fs_path);
                ok = install_pkg(fs::path(path), *g_emuenv, zrif, [](float) {});
                if (!ok && zrif.empty()) detail = "No license (zRIF) found for this PKG. Install its work.bin first (Manage > Install License).";
            } else {
                ZipScan zs;
                if (ext == "zip") zs = scan_zip(path, NSTemporaryDirectory().UTF8String);
                if (!zs.pkg_path.empty()) {
                    if (zs.has_work_bin) install_work_bin(zs.work_bin, g_emuenv->vita_fs_path);
                    std::string zrif = find_pkg_zrif(fs::path(zs.pkg_path), g_emuenv->vita_fs_path);
                    ok = install_pkg(fs::path(zs.pkg_path), *g_emuenv, zrif, [](float) {});
                    if (!ok && zrif.empty()) detail = "The zip contains a PKG but no usable work.bin.";
                    unlink(zs.pkg_path.c_str());
                } else {
                    const auto result = install_archive(*g_emuenv, fs::path(path), [](ArchiveContents) {},
                        [](const std::string &, const std::string &) -> bool { return true; });
                    ok = !result.empty();
                    if (ok && zs.has_work_bin) {
                        const std::string tid = install_work_bin(zs.work_bin, g_emuenv->vita_fs_path);
                        if (!tid.empty()) detail = "work.bin licence installed for " + tid + ".";
                    }
                }
            }
            if (ok) app::scan_apps(*g_emuenv);
        } catch (const std::exception &e) {
            detail = e.what();
        }
        [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithUTF8String:path.c_str()] error:nil];
        diag(ok ? "OK" : "FAIL", "install", "mode=%s file=%s %s", mode.UTF8String, fname.c_str(), detail.c_str());
        dispatch_async(dispatch_get_main_queue(), ^{
            [busy dismissViewControllerAnimated:YES completion:^{
                if (done) done();
                show_alert(host, ok ? @"Done" : @"Error", [NSString stringWithFormat:@"%@ %s", ok ? @"Installed successfully." : @"Installation failed.", detail.c_str()]);
            }];
        });
    });
}

@interface V3KManage : UITableViewController <UIDocumentPickerDelegate>
@end
@implementation V3KManage {
    NSString *_mode;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Manage";
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv { return 3; }
- (NSString *)tableView:(UITableView *)tv titleForHeaderInSection:(NSInteger)s { return s == 0 ? @"Install" : s == 1 ? @"Library" : @"System"; }
- (NSString *)tableView:(UITableView *)tv titleForFooterInSection:(NSInteger)s {
    if (s == 0) return @"Install the firmware (.PUP) first. Archives (.zip) are scanned for work.bin automatically; a .pkg needs its work.bin (License) installed first, unless it is inside the same zip.";
    return nil;
}
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)s { return s == 0 ? 4 : s == 1 ? 2 : 2; }
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    NSString *t = nil, *icon = nil, *detail = nil;
    if (ip.section == 0) {
        NSArray *n = @[ @"Install Firmware (.PUP)", @"Install Package (.pkg)", @"Install Archive (.zip / .vpk)", @"Install License (.rif / work.bin)" ];
        NSArray *i = @[ @"cpu", @"shippingbox", @"doc.zipper", @"key" ];
        t = n[ip.row]; icon = i[ip.row];
    } else if (ip.section == 1) {
        t = ip.row == 0 ? @"Refresh game list" : @"Delete all shader caches";
        icon = ip.row == 0 ? @"arrow.clockwise" : @"trash";
    } else {
        t = ip.row == 0 ? @"JIT" : @"Version";
        icon = ip.row == 0 ? @"bolt" : @"info.circle";
        detail = ip.row == 0 ? (ios_jit_available() ? @"Enabled ✓" : @"Not enabled ✗") : NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"];
    }
    cell.textLabel.text = t;
    cell.detailTextLabel.text = detail;
    cell.imageView.image = [UIImage systemImageNamed:icon];
    if (ip.section == 1 && ip.row == 1) cell.textLabel.textColor = UIColor.systemRedColor;
    if (ip.section == 0) cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [tv deselectRowAtIndexPath:ip animated:YES];
    if (ip.section == 0) {
        _mode = @[ @"fw", @"pkg", @"archive", @"license" ][ip.row];
        UIDocumentPickerViewController *p = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[ UTTypeItem ] asCopy:YES];
        p.delegate = self;
        p.allowsMultipleSelection = NO;
        [self presentViewController:p animated:YES completion:nil];
    } else if (ip.section == 1) {
        if (ip.row == 0) {
            app::scan_apps(*g_emuenv);
            v3k_reload_games();
        } else {
            try { fs::remove_all(g_emuenv->cache_path / "shaders"); } catch (...) {}
            show_alert(self, @"Shader caches", @"All shader caches were deleted.");
        }
    } else if (ip.row == 0) {
        show_alert(self, @"JIT", ios_jit_available() ? @"JIT is enabled." : @"JIT is NOT enabled.\n\nEnable it with StikDebug / AltJIT / SideJITServer (sideloaded), or install the .tipa with TrollStore, then reopen the app.");
    }
}
- (void)documentPicker:(UIDocumentPickerViewController *)c didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    if (!urls.firstObject) return;
    v3k_install(self, urls.firstObject, _mode, ^{ v3k_reload_games(); });
}
@end

// ============================ Games tab ============================
static NSString *format_play_time(int64_t sec) {
    if (sec <= 0) return nil;
    if (sec < 60) return @"played <1 min";
    if (sec < 3600) return [NSString stringWithFormat:@"played %lld min", sec / 60];
    return [NSString stringWithFormat:@"played %lldh %lldm", sec / 3600, (sec % 3600) / 60];
}
static UIImage *round_icon(UIImage *img) {
    const CGSize sz = CGSizeMake(56, 56);
    UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:sz];
    return [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        [[UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, sz.width, sz.height) cornerRadius:12] addClip];
        if (img) [img drawInRect:CGRectMake(0, 0, sz.width, sz.height)];
        else { [UIColor.tertiarySystemFillColor setFill]; UIRectFill(CGRectMake(0, 0, sz.width, sz.height)); }
    }];
}

@interface V3KGames : UITableViewController <UISearchResultsUpdating>
- (void)reload;
@end
static V3KGames *g_games_vc = nil;
static void v3k_reload_games() { [g_games_vc reload]; }

@implementation V3KGames {
    std::vector<app::AppEntry> _apps, _shown;
    std::map<std::string, app::AppTime> _times;
    NSCache *_icons;
    NSString *_query;
}
- (void)reload {
    _apps = g_emuenv ? app::get_apps(*g_emuenv) : std::vector<app::AppEntry>{};
    std::sort(_apps.begin(), _apps.end(), [](const app::AppEntry &a, const app::AppEntry &b) { return a.title < b.title; });
    if (g_emuenv) {
        try { _times = app::get_user_app_times(*g_emuenv); } catch (...) { _times.clear(); }
    }
    [self applyFilter];
    self.navigationItem.leftBarButtonItem.title = ios_jit_available() ? @"JIT ✓" : @"JIT ✗";
}
- (void)applyFilter {
    _shown.clear();
    for (const auto &a : _apps) {
        if (_query.length) {
            NSString *hay = [NSString stringWithFormat:@"%s %s", a.title.c_str(), a.title_id.c_str()];
            if ([hay rangeOfString:_query options:NSCaseInsensitiveSearch].location == NSNotFound) continue;
        }
        _shown.push_back(a);
    }
    [self.tableView reloadData];
}
- (void)updateSearchResultsForSearchController:(UISearchController *)sc { _query = sc.searchBar.text; [self applyFilter]; }
- (void)viewDidLoad {
    [super viewDidLoad];
    g_games_vc = self;
    _icons = [NSCache new];
    self.title = @"Games";
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.tableView.rowHeight = 72;
    UISearchController *sc = [[UISearchController alloc] initWithSearchResultsController:nil];
    sc.searchResultsUpdater = self;
    sc.obscuresBackgroundDuringPresentation = NO;
    sc.searchBar.placeholder = @"Search games";
    self.navigationItem.searchController = sc;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"JIT" style:UIBarButtonItemStylePlain target:self action:@selector(jitInfo)];
    self.refreshControl = [UIRefreshControl new];
    [self.refreshControl addTarget:self action:@selector(pullRefresh) forControlEvents:UIControlEventValueChanged];
    [self reload];
}
- (void)pullRefresh {
    if (g_emuenv) app::scan_apps(*g_emuenv);
    [self reload];
    [self.refreshControl endRefreshing];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    g_edit_game = nil;
    [self reload];
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    static bool shown = false;
    if (shown || !g_crash_path || self.presentedViewController) return;
    shown = true;
    NSString *msg = [NSString stringWithFormat:@"The last session ended unexpectedly.\n\nGame: %@\n\n%@", g_crash_title, g_crash_summary];
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Crash detected" message:msg preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"Share log" style:UIAlertActionStyleDefault handler:^(UIAlertAction *) { share_file(self, g_crash_path); }]];
    [a addAction:[UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}
- (void)jitInfo {
    show_alert(self, @"JIT", ios_jit_available() ? @"JIT is enabled." : @"JIT is NOT enabled.\n\nEnable it with StikDebug / AltJIT / SideJITServer (sideloaded), or install the .tipa with TrollStore, then reopen the app.");
}
- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)s { return _shown.empty() ? 1 : (NSInteger)_shown.size(); }
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *cell = [tv dequeueReusableCellWithIdentifier:@"g"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"g"];
    if (_shown.empty()) {
        cell.textLabel.text = _apps.empty() ? @"No games installed" : @"No matches";
        cell.detailTextLabel.text = _apps.empty() ? @"Open Manage → install the firmware (.PUP) first, then your .pkg / .vpk / .zip games." : nil;
        cell.detailTextLabel.numberOfLines = 0;
        cell.imageView.image = nil;
        cell.accessoryType = UITableViewCellAccessoryNone;
        return cell;
    }
    const auto &a = _shown[ip.row];
    cell.textLabel.text = [NSString stringWithUTF8String:a.title.c_str()];
    cell.textLabel.numberOfLines = 2;
    NSMutableArray *parts = [NSMutableArray arrayWithObject:[NSString stringWithUTF8String:a.title_id.c_str()]];
    auto it = _times.find(a.path);
    if (it == _times.end()) it = _times.find(a.title_id);
    if (it != _times.end()) { NSString *pt = format_play_time(it->second.time_used); if (pt) [parts addObject:pt]; }
    if (game_has_custom([NSString stringWithUTF8String:a.title_id.c_str()])) [parts addObject:@"custom config"];
    cell.detailTextLabel.text = [parts componentsJoinedByString:@" • "];
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    NSString *key = [NSString stringWithUTF8String:a.title_id.c_str()];
    UIImage *icon = [_icons objectForKey:key];
    if (!icon) {
        UIImage *raw = nil;
        if (!a.icon_path.empty()) {
            fs::path p = fs::path(a.icon_path);
            std::string full = (p.is_absolute() ? p : (g_emuenv->vita_fs_path / p)).generic_string();
            raw = [UIImage imageWithContentsOfFile:[NSString stringWithUTF8String:full.c_str()]];
        }
        icon = round_icon(raw);
        [_icons setObject:icon forKey:key];
    }
    cell.imageView.image = icon;
    cell.accessoryType = UITableViewCellAccessoryDetailButton;
    return cell;
}
- (void)bootTitle:(NSString *)tid {
    if (ios_jit_available()) { g_launch_title = tid; return; }
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"JIT not enabled" message:@"The emulator needs JIT. Enable it (StikDebug / AltJIT / TrollStore) or the game will crash." preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"Launch anyway" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *) { g_launch_title = tid; }]];
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}
- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [tv deselectRowAtIndexPath:ip animated:YES];
    if (_shown.empty()) return;
    [self bootTitle:[NSString stringWithUTF8String:_shown[ip.row].title_id.c_str()]];
}
// the same item list drives the long-press menu and the (i) button sheet
- (NSArray<NSDictionary *> *)itemsFor:(app::AppEntry)a {
    NSString *tid = [NSString stringWithUTF8String:a.title_id.c_str()];
    NSString *title = [NSString stringWithUTF8String:a.title.c_str()];
    std::string path = a.path, stid = a.title_id;
    NSMutableArray *it = [NSMutableArray array];
    void (^add)(NSString *, BOOL, void (^)(void)) = ^(NSString *t, BOOL d, void (^b)(void)) { [it addObject:@{ @"t" : t, @"d" : @(d), @"b" : [b copy] }]; };
    add(@"Boot", NO, ^{ [self bootTitle:tid]; });
    add(game_has_custom(tid) ? @"Custom config — Edit" : @"Custom config — Create", NO, ^{
        [self.navigationController pushViewController:[[V3KSettingsRoot alloc] initWithGame:tid gameTitle:title] animated:YES];
    });
    if (game_has_custom(tid))
        add(@"Custom config — Remove", YES, ^{ game_clear_custom(tid); [self.tableView reloadData]; });
    add(@"Information", NO, ^{
        auto itT = self->_times.find(path);
        NSString *pt = itT != self->_times.end() ? format_play_time(itT->second.time_used) : nil;
        NSString *m = [NSString stringWithFormat:@"Title ID: %@\nVersion: %s\nCategory: %s\nContent ID: %s\nPath: %s%@", tid, a.app_ver.c_str(), a.category.c_str(), a.content_id.c_str(), path.c_str(), pt ? [@"\n" stringByAppendingString:pt] : @""];
        show_alert(self, title, m);
    });
    add(@"Copy name and serial", NO, ^{ UIPasteboard.generalPasteboard.string = [NSString stringWithFormat:@"%@ [%@]", title, tid]; });
    add(@"Delete shader cache", NO, ^{ try { fs::remove_all(g_emuenv->cache_path / "shaders" / stid); } catch (...) {} });
    add(@"Delete save data", YES, ^{
        UIAlertController *c = [UIAlertController alertControllerWithTitle:@"Delete save data?" message:title preferredStyle:UIAlertControllerStyleAlert];
        [c addAction:[UIAlertAction actionWithTitle:@"Delete" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *) {
            try { fs::remove_all(g_emuenv->vita_fs_path / "ux0/user/00/savedata" / stid); } catch (...) {}
        }]];
        [c addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:c animated:YES completion:nil];
    });
    add(@"Delete application", YES, ^{
        UIAlertController *c = [UIAlertController alertControllerWithTitle:@"Delete application?" message:[NSString stringWithFormat:@"%@ [%@]", title, tid] preferredStyle:UIAlertControllerStyleAlert];
        [c addAction:[UIAlertAction actionWithTitle:@"Delete" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *) {
            app::delete_app(*g_emuenv, path);
            app::scan_apps(*g_emuenv);
            [self reload];
        }]];
        [c addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:c animated:YES completion:nil];
    });
    return it;
}
- (void)tableView:(UITableView *)tv accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)ip {
    if (_shown.empty()) return;
    UIAlertController *a = [UIAlertController alertControllerWithTitle:[NSString stringWithUTF8String:_shown[ip.row].title.c_str()] message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSDictionary *d in [self itemsFor:_shown[ip.row]]) {
        void (^b)(void) = d[@"b"];
        [a addAction:[UIAlertAction actionWithTitle:d[@"t"] style:[d[@"d"] boolValue] ? UIAlertActionStyleDestructive : UIAlertActionStyleDefault handler:^(UIAlertAction *) { b(); }]];
    }
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    a.popoverPresentationController.sourceView = tv;
    a.popoverPresentationController.sourceRect = [tv rectForRowAtIndexPath:ip];
    [self presentViewController:a animated:YES completion:nil];
}
- (UIContextMenuConfiguration *)tableView:(UITableView *)tv contextMenuConfigurationForRowAtIndexPath:(NSIndexPath *)ip point:(CGPoint)pt {
    if (_shown.empty()) return nil;
    app::AppEntry ent = _shown[ip.row];
    return [UIContextMenuConfiguration configurationWithIdentifier:nil previewProvider:nil actionProvider:^UIMenu *(NSArray<UIMenuElement *> *) {
        NSMutableArray *acts = [NSMutableArray array];
        for (NSDictionary *d in [self itemsFor:ent]) {
            void (^b)(void) = d[@"b"];
            UIAction *ac = [UIAction actionWithTitle:d[@"t"] image:nil identifier:nil handler:^(UIAction *) { b(); }];
            if ([d[@"d"] boolValue]) ac.attributes = UIMenuElementAttributesDestructive;
            [acts addObject:ac];
        }
        return [UIMenu menuWithTitle:@"" children:acts];
    }];
}
@end

// ============================ Root: tab bar ============================
static UIViewController *v3k_make_root() {
    UITabBarController *tab = [UITabBarController new];
    tab.view.tintColor = V3K_ACCENT;
    auto nav = ^UINavigationController *(UIViewController *vc, NSString *title, NSString *icon) {
        UINavigationController *n = [[UINavigationController alloc] initWithRootViewController:vc];
        n.tabBarItem = [[UITabBarItem alloc] initWithTitle:title image:[UIImage systemImageNamed:icon] tag:0];
        return n;
    };
    V3KGames *games = [[V3KGames alloc] initWithStyle:UITableViewStyleInsetGrouped];
    tab.viewControllers = @[
        nav(games, @"Games", @"gamecontroller"),
        nav([[V3KManage alloc] initWithStyle:UITableViewStyleInsetGrouped], @"Manage", @"square.and.arrow.down"),
        nav([[V3KSettingsRoot alloc] initWithGame:nil gameTitle:nil], @"Settings", @"gearshape"),
        nav([V3KLogs new], @"Logs", @"doc.text.magnifyingglass"),
    ];
    return tab;
}
