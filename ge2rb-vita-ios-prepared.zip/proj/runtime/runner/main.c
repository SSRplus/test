/* vita_run: PC runner. usage: vita_run APPDIR PATCHDIR
   loads every module listed in the generated modules_table.c (first entry = main executable), links them, starts the
   system modules (sce_module/*), then runs the main module's module_start on a guest "main thread". */
#include "vita_link.h"
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { const char *path; uint32_t *seg; void (*reg)(void); } gen_module;
extern const gen_module gen_modules[];
extern int hle_module_started[];       /* see hle_boot.c */

static const char *g_app, *g_patch;

static void on_crash(int sig, siginfo_t *si, void *uc) {
    (void)uc;
    uint8_t *mem = vrt_mem;
    fprintf(stderr, "\n[crash] signal %d", sig);
    if (si && (sig == SIGSEGV || sig == SIGBUS)) {
        uintptr_t fa = (uintptr_t)si->si_addr;
        if (fa >= (uintptr_t)mem && fa < (uintptr_t)mem + (1ull << 32)) fprintf(stderr, "  guest fault address 0x%08x", (uint32_t)(fa - (uintptr_t)mem));
        else fprintf(stderr, "  host fault address %p (not guest memory)", si->si_addr);
    }
    vrt_ctx *ctx = vrt_current_ctx;
    fprintf(stderr, "\n[crash] last_call=%08x  r0=%08x r1=%08x r2=%08x r3=%08x sp=%08x lr=%08x\n", ctx ? ctx->last_call : 0,
            ctx ? ctx->r[0] : 0, ctx ? ctx->r[1] : 0, ctx ? ctx->r[2] : 0, ctx ? ctx->r[3] : 0, ctx ? ctx->r[13] : 0, ctx ? ctx->r[14] : 0);
    if (ctx) { const char *d = vrt_stub_describe(ctx->last_call); if (d) fprintf(stderr, "[crash] last import called: %s\n", d); }
    uint32_t bt[64]; int n = vrt_backtrace(bt, 64); char nm[200];
    fprintf(stderr, "[crash] guest call chain (outermost first, %d deep):\n", n);
    for (int i = 0; i < n; i++) { const char *d = vrt_describe_addr(bt[i], nm, sizeof nm); fprintf(stderr, "[bt] #%d %s\n", i, d ? d : "?"); }
    uint32_t rc[48]; int nr = vrt_recent_calls(rc, 48);
    fprintf(stderr, "[crash] last %d calls made by the crashing thread (oldest first):\n", nr);
    for (int i = 0; i < nr; i++) { const char *d = vrt_describe_addr(rc[i], nm, sizeof nm); fprintf(stderr, "[call] #%d %s\n", i, d ? d : "?"); }
    fflush(stderr); _exit(139);
}

static int exists(const char *p) { struct stat st; return stat(p, &st) == 0; }

int hle_start_module(vrt_ctx *x, int idx, uint32_t args, uint32_t argp);   /* hle_boot.c */

static void *guest_main(void *arg) {
    (void)arg;
    vrt_ctx *x = calloc(1, sizeof *x);
    uint32_t stack = vrt_alloc(1u << 20, 0x1000);
    x->r[13] = stack + (1u << 20) - 16;
    x->tls = vrt_alloc(0x1000, 0x1000);              /* TPIDRURO: per-thread block, 4 bytes per TLS key */
    fprintf(stderr, "[run] starting system modules (sce_module/*) ...\n");
    int n = vrt_link_module_count();
    for (int i = 1; i < n; i++)
        if (strstr(vrt_link_module_name(i), "sce_module/")) hle_start_module(x, i, 0, 0);
    fprintf(stderr, "[run] module_start of %s\n", vrt_link_module_name(0));
    hle_start_module(x, 0, 0, 0);
    fprintf(stderr, "[run] module_start returned r0=%08x\n", x->r[0]);
    return NULL;
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: %s APPDIR PATCHDIR\n", argv[0]); return 2; }
    g_app = argv[1]; g_patch = argv[2];
    vrt_lenient = getenv("VRT_STRICT") ? 0 : 1;
    struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_sigaction = on_crash; sa.sa_flags = SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL); sigaction(SIGBUS, &sa, NULL); sigaction(SIGABRT, &sa, NULL); sigaction(SIGILL, &sa, NULL);
    if (vrt_init(0)) { fprintf(stderr, "cannot reserve guest address space\n"); return 3; }
    for (const gen_module *g = gen_modules; g->path; g++) {
        char p[1100]; snprintf(p, sizeof p, "%s/%s", g_patch, g->path);
        if (!exists(p)) snprintf(p, sizeof p, "%s/%s", g_app, g->path);
        vrt_module m;
        if (vrt_load_self(p, &m)) { fprintf(stderr, "cannot load %s\n", p); return 4; }
        for (int i = 0; i < m.nseg && i < 4; i++) g->seg[i] = m.base[i];
        vrt_link_add_module(&m, g->path);
        g->reg();
    }
    vrt_link_stats st; vrt_link_resolve(&st);
    int unbound = vrt_bind_redirects();
    fprintf(stderr, "[link] modules=%d game_func=%d game_var=%d system_func(HLE bound %d / missing %d) system_var=%d unbound_redirects=%d\n",
            st.modules, st.game_func, st.game_var, st.hle_func_bound, st.hle_func_missing, st.hle_var, unbound);
    pthread_attr_t at; pthread_attr_init(&at); pthread_attr_setstacksize(&at, 512u << 20);   /* guest calls nest on the host stack */
    pthread_t th; pthread_create(&th, &at, guest_main, NULL); pthread_join(th, NULL);
    return 0;
}
