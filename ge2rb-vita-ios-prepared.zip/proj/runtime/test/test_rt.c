#include "vita_rt.h"
#include <assert.h>
#include <stdio.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>
static void add(vrt_ctx *c) { assert(vrt_current_ctx == c); c->r[0] = c->r[0] + c->r[1]; }
enum { ALLOC_THREADS = 8, ALLOCS_PER_THREAD = 128 };
static uint32_t allocs[ALLOC_THREADS][ALLOCS_PER_THREAD];
static void *alloc_worker(void *arg) {
    uintptr_t id = (uintptr_t)arg;
    for (int i = 0; i < ALLOCS_PER_THREAD; i++) {
        allocs[id][i] = vrt_alloc(64, 64);
        memset(VRT_G2H(allocs[id][i]), (int)(id + 1), 64);
    }
    return NULL;
}
int main(void) {
    assert(vrt_init(0) == 0);
    uint32_t g = vrt_alloc(4096, 4096);
    *(uint32_t *)VRT_G2H(g) = 0xdeadbeef;
    assert(*(uint32_t *)VRT_G2H(g) == 0xdeadbeef);
    /* Concurrent HLE/game threads must never receive overlapping guest allocations. */
    pthread_t workers[ALLOC_THREADS];
    for (uintptr_t i = 0; i < ALLOC_THREADS; i++) assert(pthread_create(&workers[i], NULL, alloc_worker, (void *)i) == 0);
    for (int i = 0; i < ALLOC_THREADS; i++) assert(pthread_join(workers[i], NULL) == 0);
    for (int a = 0; a < ALLOC_THREADS * ALLOCS_PER_THREAD; a++) {
        uint32_t va = allocs[a / ALLOCS_PER_THREAD][a % ALLOCS_PER_THREAD];
        assert((va & 63u) == 0);
        for (int b = a + 1; b < ALLOC_THREADS * ALLOCS_PER_THREAD; b++) {
            uint32_t vb = allocs[b / ALLOCS_PER_THREAD][b % ALLOCS_PER_THREAD];
            assert(va != vb);
        }
    }
    vrt_register(0x81000001, add);
    vrt_register_hle(0xC5C11EE7, add, "sceKernelCreateThread");
    for (uint32_t i = 0; i < 5000; i++) vrt_register(0x81100000 + i * 2 + 1, add);   /* force table growth */
    vrt_ctx c = {0}; c.r[0] = 2; c.r[1] = 3;
    vrt_call(&c, 0x81000001); assert(c.r[0] == 5 && vrt_current_ctx == NULL);
    vrt_call(&c, 0x81100000 + 4999 * 2 + 1); assert(c.r[0] == 8 && vrt_current_ctx == NULL);
    assert(vrt_lookup_hle(0xC5C11EE7) && !vrt_lookup_hle(1));
    /* input */
    vrt_input_set_buttons(VRT_CROSS | VRT_L1);
    assert(vrt_input_get_buttons() == 0x4400);
    uint8_t st[4]; vrt_input_get_sticks(st); assert(st[0] == 128 && st[3] == 128);
    vrt_input_set_sticks(1, 2, 3, 4); vrt_input_get_sticks(st); assert(st[0]==1 && st[1]==2 && st[2]==3 && st[3]==4);
    uint8_t ids[6]; uint16_t xs[6], ys[6];
    vrt_input_touch(0, 7, 1, 100, 200); vrt_input_touch(0, 8, 1, 300, 400); vrt_input_touch(0, 7, 1, 110, 210);
    assert(vrt_input_get_touches(0, ids, xs, ys, 6) == 2 && xs[0] == 110 && ys[0] == 210);
    vrt_input_touch(0, 7, 0, 0, 0); assert(vrt_input_get_touches(0, ids, xs, ys, 6) == 1 && ids[0] == 8);
    assert(vrt_input_get_touches(1, ids, xs, ys, 6) == 0);
    puts("runtime ok"); vrt_shutdown(); return 0;
}
